function validateContact()
{
    let name=document.getElementById('name').value;
    let mobile=document.getElementById('mobile').value;	
    let message=document.getElementById('message1').value;
if((!isNaN(name)) || (name.length<=1) || name.includes(0) || name.includes(1) || name.includes(2) || name.includes(3) || name.includes(4) || name.includes(5) || name.includes(6) || name.includes(7) || name.includes(8) || name.includes(9)  )
	{
		alertify.alert("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid <i class='fa fa-user'></i> Name</div>");
		alertify.log("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid <i class='fa fa-user'></i> Name</div>");
	    return false;
	}
	else if((isNaN(mobile)) || (mobile.length<10) || (mobile.length>=11))
	{
		alertify.alert("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Mobile <i class='fa fa-mobile'></i> Number</div>");
		alertify.log("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Mobile <i class='fa fa-mobile'></i> Number</div>");
	    return false;
	}
	else if((message.length<=1))
	{
       alertify.alert("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please Write Some Message<i class='fa fa-envelope'></i> </div>");
       alertify.log("<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please Write Some Message<i class='fa fa-envelope'></i> </div>");
	   return false;
	}
	else
	{
		document.getElementById("contactForm").submit();
	}
	
}
