<?php 
$page_id=5;
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg"> 
    <title>Admission - Digital Seva Kendra</title>	
  </head>
  <body>
        <?php include 'header.php'; ?>
        <?php include 'includeFunctions.php'; ?>
      	<br>
      	<br>
      	<br>
      	<br>
        <div class="container-fluid">
		   <div class="card">
		         <div class="card-header w3-win8-teal">
				 <center>   <b><i class="fa fa-mortar-board"></i> Admission Form</b></center>
				 </div>
		        <div class="card-body">
				    <b><i class="fa fa-hand-o-right text-warning"></i> <mark>Note:</mark></b>
					 <ol>
					   <li><i class="fa fa-check-circle text-success"></i><b class="w3-win8-orange">&nbsp; Fill All Required Fields <i class="fa fa-asterisk"></i> &nbsp;</b></li>
					   <li><i class="fa fa-check-circle text-success"></i><b class="w3-win8-orange">&nbsp; Fill Correct & Complete Information <i class="fa fa-asterisk"></i>&nbsp;</b></li>
					 </ol>
					 <!------------------------>
				     <div class="">
					      <form action="admission.php" method="post" id="admissionForm">
						        <div class="form-group form-inline">
								   <label><b><i class="fa fa-book"></i> Select Course:<i class="fa fa-asterisk text-danger"></i> &nbsp;</b></label>
								   <select name="course" id="course" class="form-control" autofocus required>
								       <option value="">Select Course</option>
									    <?php get_course_name(); ?>
								   </select>&nbsp;&nbsp;&nbsp;
								    <label><b><i class="fa fa-user"></i> Name:<i class="fa fa-asterisk text-danger"></i> &nbsp;</b></label>
									<input type="text" name="name" id="name" class="form-control" placeholder="Full Name" required>&nbsp;&nbsp;&nbsp;
									<label><b><i class="fa fa-user"></i> Father Name:<i class="fa fa-asterisk text-danger"></i>  &nbsp;</b></label>
									<input type="text" name="fname" id="fname" class="form-control" placeholder="Father Name" required>&nbsp;&nbsp;&nbsp;
								</div>
								<!----------------------->
								<b>
								        <i class="fa fa-hand-o-right text-warning"></i>
								        <mark>
										   Note: <i class="fa fa-warning text-danger"></i>
								</b>
								            <b class="w3-win8-red">&nbsp; Use Date Format: Month/Date/Year &nbsp;</b>
										</mark>
								   
								<div class="form-group form-inline">								   
								   <label><b><i class="fa fa-calendar"></i> DOB:<i class="fa fa-asterisk text-danger"></i>  &nbsp;</b></label>
								   <input type="date" name="dob" id="dob" class="form-control" placeholder="Date of Birth" required>&nbsp;&nbsp;&nbsp;
								   <label><b><i class="fa fa-mobile"></i> Mobile No.:<i class="fa fa-asterisk text-danger"></i>  &nbsp;</b></label>
								   <input type="number" name="mobile" id="mobile" class="form-control" placeholder="Mobile Number" required>&nbsp;&nbsp;&nbsp;								   
								    <label><b><i class="fa fa-map-marker"></i> Address:<i class="fa fa-asterisk text-danger"></i>  &nbsp;</b></label>
								   <textarea name="address" id="address" class="form-control" placeholder="Permanent Address OF Student" required></textarea>&nbsp;&nbsp;&nbsp;								    
								</div>
								<center>
					<i class="fa fa-hand-o-right text-success" style="font-size:50px;"></i>
					<button type="button" name="Get Admission" class="btn btn-success" onclick="validateAdmission()"><i class="fa fa-thumbs-o-up"></i> Get Admission</button>
								</center>
						  </form>
					 </div>
				</div>
				<div class="card-footer bg-dark" style="">
				</div>
		   </div>
		</div>
        <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
    function validateAdmission()
	{
	   let course=document.getElementById('course').value;	
	   let name=document.getElementById('name').value;	
	   let fname=document.getElementById('fname').value;	
	   let dob=document.getElementById('dob').value;	
	   let mobile=document.getElementById('mobile').value;	
	   let address=document.getElementById('address').value;
	   let msg1="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please	 Select a Course</div>";
	   let msg2="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Not a Valid Name Please Enter a Valid Name</div>";
	   let msg3="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Not a Valid Father Name Please Enter a Valid Father Name</div>";
	   let msg4="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please Select DOB</div>";
	   let msg5="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please Enter Valid Mobile Number</div>";
	   let msg6="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Please Enter Permanent Address</div>";
        if(course.length<1)
		{
			alertify.alert(msg1);
			alertify.log(msg1);
			return false;
		}
        else if((!isNaN(name)) || (name.length<=1) || name.includes(0) || name.includes(1) || name.includes(2) || name.includes(3) || name.includes(4) || name.includes(5) || name.includes(6) || name.includes(7) || name.includes(8) || name.includes(9)  )
	    {
		    alertify.alert(msg2);
			alertify.log(msg2);
			return false;
     	}
        else if((!isNaN(fname)) || (fname.length<=1) || fname.includes(0) || fname.includes(1) || fname.includes(2) || fname.includes(3) || fname.includes(4) || fname.includes(5) || fname.includes(6) || fname.includes(7) || fname.includes(8) || fname.includes(9)  )
	    {
		    alertify.alert(msg3);
			alertify.log(msg3);
			return false;
     	}
		else if(dob.length<1)
		{
			alertify.alert(msg4);
			alertify.log(msg4);
			return false;
		}
		else  if((isNaN(mobile)) || (mobile.length<10) || (mobile.length>=11))
		{
			alertify.alert(msg5);
			alertify.log(msg5);
			return false;
		}
		else if(address.length<1)
		{
			alertify.alert(msg6);
			alertify.log(msg6);
			return false;
		}
		else
		{
			document.getElementById('admissionForm').submit();
		}
	}
</script>

<?php 
if((isset($_POST["name"])) && (isset($_POST["fname"])) && (isset($_POST["dob"])) && (isset($_POST["mobile"])) && isset($_POST["address"]) && (isset($_POST["course"])) )
{
	$name=$_POST["name"];
	$fname=$_POST["fname"];
	$dob=$_POST["dob"];
	$mobile=$_POST["mobile"];
	$address=$_POST["address"];
	$course=$_POST["course"];
	$sql="SELECT * FROM admission WHERE name='$name' AND fname='$fname' AND dob='$dob' AND course='$course'";
	include 'db.php';
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		?>
		<script>
		    let msg1="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Dear, <i class='text-success'><?php echo $row['name'];?></i> You Are Already Apply For Admission in <mark><?php echo get_course_name_from_id($row['course']);?></mark> Course On <mark><?php echo date("d-m-y h:i:s A",strtotime($row['c_id']));?></mark></div>";
		    alertify.alert(msg1);
		    alertify.log(msg1);			
		</script>
		<?php
	}
	else
	{
		 $sql1="INSERT INTO admission(name,fname,dob,mobile,address,course)VALUES('$name','$fname','$dob','$mobile','$address','$course')";
		 $result1=$conn->query($sql1);
		 if($result==TRUE)
		 {
			 ?>
		   <script>
	let msg1="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:50px;'></i></center>Thank You!!!<br>Dear, <?php echo $name;?> You Successfully Got Admission in <?php echo get_course_name_from_id($course);?> Course!!!<br><p class='text-info'> Your Class Timing Related information Send to On Your Registered Mobile Number</p></div>";
            alertify.alert(msg1);
		    alertify.log(msg1);		  
		  </script>
		<?php 
		 }
		 else
		 {
			 ?>
		   <script>
		    let msg1="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Error... Try again!!! </div>";
		    alertify.alert(msg1);
		    alertify.log(msg1);
		   </script>
		<?php
		 }
	}
}
?>