<?php 
$page_id=7;
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg"> 
    <title>Download - Digital Seva Kendra</title>	
  </head>
  <body>
        <?php include 'header.php'; ?>
        <?php include 'includeFunctions.php'; ?>
      	<br>
      	<br>
      	<br>
        <div class="container mb-4">
		   <div class="card">
		         <div class="card-header w3-win8-indigo">
				    <b><i class="fa fa-download"></i> Download</b>
				 </div>
		        <div class="card-body">
				  <div class="row">
				     <div class="card-deck col-sm-4 p-2">
					     <div class="card" style="box-shadow:4px 4px 6px; #999;">
						    <div class="card-body">
							      <center>
								     <b><i class="fa fa-file-pdf-o text-danger"></i> Basic Computer Notes</b>
									      <br>
										  <i class="fa fa-hand-o-down text-primary" style="font-size:50px;"></i>
								  </center>
                                <div class="card-text">
								  <ul class="list-group" style="margin-top:2px;">
								     <?php 
									    include "db.php";
										$sql="SELECT * FROM download WHERE downloadGroup='Basic Computer Notes'";
										$result=$conn->query($sql);
										while($row=$result->fetch_assoc()){
										   ?>
								     <li class="list-group-item">
									        <b><i class="fa fa-file-pdf-o text-danger"></i> <?php echo $row["title"]; ?></b> 
									        <a href="admin/download/<?php echo $row["fileName"];?>" class='btn btn-dark' data-toggle="tooltip" title="Click On Me To Download <?php echo $row['title'];?>" data-placement="right">
									          <i class="fa fa-download"></i> <span class="badge badge-danger"><?php getFileSize($row["fileSize"]);?></span>
											 </a>
									 </li>
										   <?php
										}					
									 ?>
								     
								  </ul>
								</div>								  
						    </div>
					     </div>
				     </div>	 
					 <!------------------------>
					 <div class="card-deck col-sm-4 p-2">
					     <div class="card" style="box-shadow:4px 4px 6px; #999;">
						    <div class="card-body">
							      <center>
								     <b><i class="fa fa-file-pdf-o text-danger"></i> PDF E-Book's</b>
									      <br>
										  <i class="fa fa-hand-o-down text-primary" style="font-size:50px;"></i>
								  </center>
                                <div class="card-text">
								  <ul class="list-group" style="margin-top:2px;">
								      <?php 
									    include "db.php";
										$sql="SELECT * FROM download WHERE downloadGroup='PDF E-Books'";
										$result=$conn->query($sql);
										while($row=$result->fetch_assoc()){
										   ?>
								     <li class="list-group-item">
									        <b><i class="fa fa-file-pdf-o text-danger"></i> <?php echo $row["title"]; ?></b> 
									        <a href="admin/download/<?php echo $row["fileName"];?>" class='btn btn-dark' data-toggle="tooltip" title="Click On Me To Download <?php echo $row['title'];?>" data-placement="right">
									          <i class="fa fa-download"></i> <span class="badge badge-danger"><?php getFileSize($row["fileSize"]);?></span>
											 </a>
									 </li>
										   <?php
										}					
									 ?>
								  </ul>
								</div>								  
						    </div>
					     </div>
				     </div>	 
					 
					  <!------------------------>
					 <div class="card-deck col-sm-4 p-2">
					     <div class="card" style="box-shadow:4px 4px 6px; #999;">
						    <div class="card-body">
							      <center>
								     <b><i class="fa fa-file-pdf-o text-danger"></i> Other Course Notes</b>
									      <br>
										  <i class="fa fa-hand-o-down text-primary" style="font-size:50px;"></i>
								  </center>
                                <div class="card-text">
								  <ul class="list-group" style="margin-top:2px;">
								     <?php 
									    include "db.php";
										$sql="SELECT * FROM download WHERE downloadGroup='Other Course Notes'";
										$result=$conn->query($sql);
										while($row=$result->fetch_assoc()){
										   ?>
								     <li class="list-group-item">
									        <b><i class="fa fa-file-pdf-o text-danger"></i> <?php echo $row["title"]; ?></b> 
									        <a href="admin/download/<?php echo $row["fileName"];?>" class='btn btn-dark' data-toggle="tooltip" title="Click On Me To Download <?php echo $row['title'];?>" data-placement="right">
									          <i class="fa fa-download"></i> <span class="badge badge-danger"><?php getFileSize($row["fileSize"]);?></span>
											 </a>
									 </li>
										   <?php
										}					
									 ?>
								  </ul>
								</div>								  
						    </div>
					     </div>
				     </div>	 
					 
				  </div>
			    </div>		
		   </div>
		</div>
        <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
   
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<?php

function getFileSize($fileSize){
											
									 if($fileSize<=1023){
										   echo round($fileSize,2)."bytes";
									 }else if($fileSize>=1024){
										         $fileSizeAfterDivide=$fileSize/1024;
														 if($fileSizeAfterDivide<1023){
															     echo round($fileSizeAfterDivide,2)."KB";
														 }else{
															        $fileSizeAfterDivide=$fileSize/(1024*1024);
																			 echo round($fileSizeAfterDivide,2)."MB";
														 }
									 }
											
							} 
?>