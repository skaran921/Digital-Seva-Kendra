<nav class="navbar navbar-expand-lg navbar-dark fixed-top  fixed-top" style="background-color:black;box-shadow:1px 1px 1px #999;">
    <a href="index.php" class="text-warning navbar-brand" style="font-family:Comic Sans MS">
	   <i class="fa fa-laptop"></i> Digital Seva Kendra
	</a>
	<button type="butoon" class="card navbar-toggler" style="background-color:black;color:white" aria-expanded="true" data-toggle="collapse" data-target="#navb">
	   <span class="navbar-toggler-icon">
	</button>	
	
	<div class="navbar-collapse collapse hide" id="navb">
	    <ul class="navbar-nav mr-auto">
		 <li class="nav-item">
			   <a href="index.php" class="nav-link <?php if($page_id==1){echo "active";}else{}?>" data-toggle="tooltip" title="Go To Home Page">
			      <i class="fa fa-home"></i> Home
			   </a>
		 </li>	
		 <li class="nav-item">
			   <a href="about.php" class="nav-link <?php if($page_id==2){echo "active";}else{}?>" data-toggle="tooltip" title="About Us"><i class="fa fa-info-circle"></i> About</a>
		 </li>	
		 
            <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-smile-o"></i> Services</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="add room.php" class="dropdown-item"><i class="fa fa-smile-o"></i> Xerox(Photocopy)</a>				    
				     <a href="add room.php" class="dropdown-item"><i class="fa fa-print"></i> Print Out</a>				    
				     <a href="add room.php" class="dropdown-item"><i class="fa fa-list"></i> Online Form</a>     			    
				 </div>
			</li>    

            <li class="nav-item dropdown">
			      <a href="#" class="nav-link dropdown-toggle <?php if($page_id==4){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-list-alt"></i> Notification</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="job notification.php" class="dropdown-item <?php if($notification_page_id==1){echo "active";}else{}?>"><i class="fa fa-laptop"></i> Job Notification</a>				    
				     <a href="general notification.php" class="dropdown-item <?php if($notification_page_id==2){echo "active";}else{}?>"><i class="fa fa-laptop"></i> General Notification</a>				     	    
				 </div>
			</li>			
         
			  <li class="nav-item">
			   <a href="admission.php" class="nav-link <?php if($page_id==5){echo "active";}else{}?>" data-toggle="tooltip" title="Get Admission Online in Various Course's">
			        <i class="fa fa-mortar-board"></i>Admission
			   </a>
		     </li> 
			 
			 <li class="nav-item">
			   <a href="#" class="nav-link" data-toggle="modal" data-target="#loginModal" title="Click Me For Login in Your Account"><i class="fa fa-sign-in"></i> Login</a>
		     </li> 			 
			  <li class="nav-item">
			   <a href="download.php" class="nav-link <?php if($page_id==7	){echo "active";}else{}?>" data-toggle="tooltip" title="Download Notes of Various Subject">
			          <i class="fa fa-download"></i> Download
			   </a>
		     </li> 			 
               
          &nbsp;&nbsp;&nbsp;
			<li class="nav-item form-inline">
			   <a href="#" class="nav-link"><i class="fa fa-facebook text-light"></i></a>&nbsp;&nbsp;&nbsp;		
			   <a href="#" class="nav-link"><i class="fa fa-twitter text-light"></i></a>&nbsp;&nbsp;&nbsp;	
			   <a href="#" class="nav-link"><i class="fa fa-instagram text-light"></i></a>&nbsp;&nbsp;&nbsp;			   				   
			   <a href="#" class="nav-link"><i class="fa fa-linkedin text-light" style="overflow:hidden"></i></a>&nbsp;&nbsp;&nbsp;					   
		     </li>  
		</ul>             	
	</div>
       
</nav>	

			    <!---------------------loginModal-------------->
				  <div class="modal" id="loginModal">
				     <div class="modal-dialog modal-sm">
					   <div class="modal-content">
					        <div class="modal-header text-primary">
							    <h5 class="modal-title"><i class="fa fa-sign-in"></i> Student Login</h5>
								  <button type="button" data-dismiss="modal" class="close"><i class="fa fa-times-circle text-danger"></i></button>
							</div>
							<div class="modal-body">
							    <form action="" method="post" id="studentLoginForm"  name="studentLoginForm">
								     <div class="form-group">
									      <label><b><i class="fa fa-user"></i> User Name:</b></label>
										    <input type="email" name="email" id="email" class="form-control" placeholder="User Name" required autofocus>
									      <label><b><i class="fa fa-lock"></i> Password:</b></label>
										   <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
									 </div>
									 <center>
									    <button type="button" class="btn btn-primary" onclick="validateStudentLogin()"><i class="fa fa-sign-in"></i> Login</button>
									    <button type="reset" class="btn btn-info"><i class="fa fa-refresh"></i> Reset</button>
										<div id="error" class="card" style="background-color:red;color:white;margin-top:10px;display:none;"></div>
									 </center>
								</form>
							</div>
							<div class="modal-footer">
							     <button type="button" data-dismiss="modal" class="btn btn-danger">Close</button>
							</div>
					   </div>
					 </div>
				  </div>				        
			    <!--------------------------------------------->
<script>
function validateStudentLogin()
{
	let email=document.getElementById('email').value;
	let pass=document.getElementById('password').value;
   	if(!(email.includes('.com')) || (!email.includes('@')) || (email.length<1))
	{    
		let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Username</div>";
		document.getElementById('error').innerHTML=msg;
		document.getElementById("error").style.display="block";
	}
   else if(pass.length<1)
   {
	   let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Password</div>";
		document.getElementById('error').innerHTML=msg;
		document.getElementById("error").style.display="block";
   }
   else
   {
	    document.getElementById('studentLoginForm').submit();
   }	   
}
</script>

<?php
 
if((isset($_POST["email"])) && (isset($_POST["password"])))
{
    $email=$_POST["email"];
    $password=$_POST["password"];   
}	
?>				