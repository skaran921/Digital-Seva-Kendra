<?php 
$page_id=4;
$notification_page_id=1;
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg"> 
    <title>job Notification - Digital Seva Kendra</title>	
	<style>
	   #sub-card{
		     border-radius:15px;
			 box-shadow:0px 10px 15px; 
		     transition:5s;
	   }
	   .col-sm-4:nth-child(even) #sub-card,.col-sm-4:nth-child(even) #notify-icon{
	           background:linear-gradient(-45deg,#f403d1,#64b5f6);
	   }	   
	   
	   .col-sm-4:nth-child(odd) #sub-card,.col-sm-4:nth-child(odd) #notify-icon{
	           background:linear-gradient(-45deg,#24ff72,#9a4eff);
	   }
	   
	   #sub-card:before{
		   content:'';
		   position:absolute;
		   bottom:0;
		   left:0;
		   width:100%;
		   height:40%;
		   background:rgba(255,255,255,0.1);
		   z-index:1;
		   transform:skewY(-5deg) scale(1);
	   }
	   
	   #notify-icon{
	        color:#fff; 
			font-size:60px;
			width:100px;
			height:100px;
			border-radius:50%;
			line-height:100px;
			box-shadow:0 10px 10px rgba(0,0,0,.3); 
	   }
	   #title{
		    position:relative;
			margin: 20px 0 0;
			padding:0;
			color:#fff;
			font-size:28px;
	   }
	</style>
  </head>
  <body>
        <?php include 'header.php'; ?>
        <?php include 'includeFunctions.php'; ?>
      	<br>
      	<br>
      	<br>
        <div class="container-fluid">
		   <div class="card">
		         <div class="card-header bg-dark text-light">
				    <b><i class="fa fa-check-square text-success"></i> Job Notification</b>
				 </div>
		        <div class="card-body row">
				  <?php 
				      include "db.php";
					  $sql="SELECT name FROM jobgroup";
					  $result=$conn->query($sql);
					  while($row=$result->fetch_assoc()){
				  ?>
				    <div class="card-deck col-sm-4">
					   <div class="card" id="sub-card">
					       <div class="card-body">
						      <center>
							      <span class="fa fa-newspaper-o" id="notify-icon"></i>
							  </center>
						       <h3 class="text-center" id="title"><?php echo $row["name"];?></h3>							       
						       <div class="card-text">
							   <div style="overflow-x:auto;overflow-y:auto;">
											    <table class="table table-striped mt-1">
												   <thead>
												     <tr class="thead-dark" align="center">
													     <th>Sr. No.</th>
													     <th>Date</th>
													     <th>Notification</th>
													 </tr>
												   </thead>
												   <tbody>
							          <?php 
									     $jobGroup=$row["name"];
									     $sql1="SELECT * FROM jobnotification WHERE jobGroup='$jobGroup' ORDER BY u_id DESC";
                                         $result1=$conn->query($sql1);
										 $sr=1;
                                         while($row1=$result1->fetch_assoc()){
											   ?>											   
												        <tr align="center">
														    <td class="font-weight-bold bg-dark text-light"><?php echo $sr;?></td>
														    <td class="font-weight-bold"><?php echo date("d-m-y",strtotime($row1["u_id"]));?></td>
														    <td><?php echo addslashes($row1["notification"]);?></td>
														</tr>												   
											   <?php 
											   $sr++;
										 }											 
									  ?>
									  </tbody>
									 </table>
								    </div>	
							   </div>
						   </div>					   
					   </div>
					</div>
					<?php 
					  }
					?>
					<!-------------------------col1------------------>
					
				</div>
				<div class="card-footer" style="background-color:black;">
				</div>
		   </div>
		</div>
        <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
   
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

