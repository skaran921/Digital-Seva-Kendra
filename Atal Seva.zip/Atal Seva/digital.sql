-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2019 at 08:10 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digital`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(60) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `c_id`, `u_id`) VALUES
(1, 'Karan', 'skaran921@gmail.com', 'skaran921', '2018-07-03 15:56:30', '2018-07-14 14:23:32');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `course` varchar(80) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `name`, `fname`, `dob`, `mobile`, `address`, `course`, `c_id`, `u_id`, `status`) VALUES
(6, 'Karan Soni', 'Brij Lal', '2018-06-30', '9466067763', 'Boys Hostel 2 CDLU Sirsa', '1', '2018-06-30 17:41:05', '2018-08-02 12:17:15', 1),
(7, 'Karan Soni', 'Brij Lal', '1997-08-13', '9466067763', 'Boys Hostel 2 CDLU Sirsa', '14', '2018-08-01 14:11:28', '2018-08-02 12:17:15', 1),
(8, 'Karan Soni', 'Brij Lal', '2018-08-13', '9466067763', 'CDLU Sirsa', '11', '2018-08-01 14:16:03', '2018-08-02 12:17:15', 1),
(9, 'Karan Soni', 'Brij Lal', '1997-08-13', '9466067763', 'Boys Hostel 2 CDLU Sirsa', '13', '2018-08-01 14:23:01', '2018-08-02 12:17:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `id` int(11) NOT NULL,
  `color` varchar(80) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`id`, `color`, `c_id`, `u_id`) VALUES
(1, 'RED', '2018-08-02 16:35:24', '2018-08-02 16:35:24'),
(2, 'BLUE', '2018-08-02 16:35:24', '2018-08-02 16:35:24'),
(3, 'BLACK', '2018-08-02 16:35:38', '2018-08-02 16:35:38'),
(4, 'GREEN', '2018-08-02 16:35:38', '2018-08-02 16:35:38'),
(5, 'LIME', '2018-08-02 16:35:55', '2018-08-02 16:35:55'),
(6, 'INDIGO', '2018-08-02 16:35:55', '2018-08-02 16:35:55'),
(7, 'GOLD', '2018-08-02 16:36:11', '2018-08-02 16:36:11'),
(8, 'SILVER', '2018-08-02 16:36:11', '2018-08-02 16:36:11'),
(9, 'skyblue', '2018-08-02 16:36:54', '2018-08-02 16:36:54'),
(10, 'purple', '2018-08-02 16:36:54', '2018-08-02 16:36:54'),
(11, 'PINK', '2018-08-02 16:37:27', '2018-08-02 16:37:27'),
(12, '#FF0095', '2018-08-02 16:37:27', '2018-08-02 16:37:27'),
(13, 'YELLOW', '2018-08-02 16:37:39', '2018-08-02 16:37:39'),
(14, 'NAVY', '2018-08-02 16:37:39', '2018-08-02 16:37:39'),
(15, 'ORANGE', '2018-08-02 16:39:02', '2018-08-02 16:39:02'),
(16, 'CYAN', '2018-08-02 16:39:02', '2018-08-02 16:39:02');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `mobile`, `message`, `c_id`, `status`) VALUES
(5, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:12:46', 1),
(6, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:12:51', 1),
(7, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:13:03', 1),
(8, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:13:40', 1),
(9, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:13:50', 1),
(10, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:13:59', 1),
(11, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:14:20', 1),
(12, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:17:29', 1),
(13, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:18:48', 1),
(14, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:21:28', 1),
(15, 'Karan Soni', '9466067763', 'hii', '2018-06-29 14:22:09', 1),
(16, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:22:19', 1),
(17, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:23:04', 1),
(18, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:23:25', 1),
(19, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:23:44', 1),
(20, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:23:57', 1),
(21, 'Karan Soni', '9466067763', 'hiii', '2018-06-29 14:24:09', 1),
(22, 'Karan Soni', '9466067763', 'Message', '2018-06-29 18:24:08', 1),
(23, 'Karan Soni', '9466067763', 'Hello Message', '2018-06-29 18:24:34', 1),
(24, 'Karan Soni', '9466067763', 'Hello Message', '2018-06-29 18:25:54', 1),
(25, 'Monu Soni', '9068348663', 'I am intrest computr class', '2018-07-08 07:51:31', 1),
(26, 'Monu', '9068342663', 'Hello', '2018-08-02 10:29:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `color` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  `duration` varchar(30) NOT NULL,
  `fee` int(11) NOT NULL,
  `syllabus` text NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`color`, `id`, `title`, `duration`, `fee`, `syllabus`, `admin`, `c_id`, `u_id`) VALUES
('#3838cf', 9, 'Basic Computer Course', '3 Month', 3000, '<ol><li><b>MS OFFICE&nbsp;</b></li><li><b>INTERNET</b></li><li><b>TYPING</b></li></ol>', 1, '2018-07-18 14:06:23', '2018-07-18 14:06:23'),
('#000000', 10, 'Tally', '3 Month', 5000, '<ol><li><b>Journal Entry</b></li><li><b>GST</b></li><li><b>Cash Book</b></li></ol>', 1, '2018-07-18 14:35:04', '2018-07-18 14:35:04'),
('#ff0000', 11, 'BASIC HTML', '1 Month', 1500, '<ol><li><b>Basic HTML TAGS</b></li><li><b>HOW TO USE IMAGES IN HTML</b></li><li><b>CREATE HYPERLINK IN HTML</b></li><li><b>CREATE TABEL IN HTML</b></li><li><b>A SMALL PROJECT IN HTML</b></li></ol>', 1, '2018-07-18 14:38:02', '2018-07-18 14:38:02'),
('#ff0080', 12, 'TYPING COURSE', '1 Month', 1000, '<ol><li><b>ENGLISH TYPING</b></li><li><b>HINDI TYPING</b></li><li><b>PUNJABI TYPING</b></li></ol>', 1, '2018-07-18 14:40:52', '2018-07-18 14:42:31'),
('#fc381d', 13, 'JAVA SCRIPT', '1 Month', 2000, '<ol><li><b>BASICS OF JAVASCRIPT</b></li><li><b>VALIDATE FORM USING JS</b></li><li><b>DESIGN TIMER IN JAVASCRIPT</b></li></ol>', 1, '2018-07-18 14:44:14', '2018-07-18 14:45:18'),
('#004080', 14, 'C++', '3 Month', 3000, '<ol><li><b>CLASS AND OBJECT</b></li><li><b>FUNCTION OVERLOADING</b></li><li><b>OPERATOR OVERLOADING</b></li><li><b>INHERITENCE</b></li><li><b>POLYMORPHISAM</b></li><li><b>FILE MANAGEMENT</b></li></ol>', 1, '2018-07-18 16:04:10', '2018-07-18 16:23:49');

-- --------------------------------------------------------

--
-- Table structure for table `current_session`
--

CREATE TABLE `current_session` (
  `id` int(11) NOT NULL,
  `current_session` varchar(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `current_session`
--

INSERT INTO `current_session` (`id`, `current_session`, `c_id`, `u_id`) VALUES
(1, '2018-19', '2018-08-08 03:00:53', '2018-08-18 02:50:35');

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE `download` (
  `id` int(11) NOT NULL,
  `downloadGroup` varchar(100) NOT NULL,
  `title` text NOT NULL,
  `fileName` text NOT NULL,
  `fileSize` int(11) NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `download`
--

INSERT INTO `download` (`id`, `downloadGroup`, `title`, `fileName`, `fileSize`, `admin`, `c_id`, `u_id`) VALUES
(1, 'Basic Computer Notes', 'ffggf', 'Basic Computer NotesffggfMCA-1st and 2nd sem-CBCS.pdf', 369883, 1, '2018-08-01 03:49:23', '2018-08-01 03:49:23'),
(2, 'Basic Computer Notes', 'HTML', 'Basic Computer NotesHTMLThe Good Parts (2).pdf', 6689447, 1, '2018-08-01 03:51:59', '2018-08-01 03:51:59'),
(11, 'PDF E-Books', 'HTML Book', 'PDF E-BooksHTML Bookhtml_tutorial.pdf', 6086157, 1, '2018-08-02 13:01:54', '2018-08-02 13:01:54'),
(12, 'Other Course Notes', 'English Notes', 'Other Course NotesEnglish Notes15-Toughest-Interview-Questions-and-Answers.pdf', 402810, 1, '2018-08-02 13:02:45', '2018-08-02 13:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE `fee` (
  `id` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `feeReceived` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `session` varchar(20) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`id`, `studentId`, `feeReceived`, `discount`, `session`, `c_id`, `u_id`) VALUES
(4, 25, 1000, 0, '2018-19', '2018-08-17 06:07:52', '2018-08-17 06:07:52'),
(5, 27, 1300, 200, '2018-19', '2018-08-17 06:21:39', '2018-08-21 10:36:28'),
(6, 25, 350, 50, '2018-19', '2018-08-17 06:21:49', '2018-08-21 10:35:50'),
(7, 26, 100, 0, '2019-20', '2018-08-18 02:50:18', '2018-08-18 02:50:18'),
(8, 27, 1, 200, '2018-19', '2018-08-21 06:07:01', '2018-08-23 10:27:24');

-- --------------------------------------------------------

--
-- Table structure for table `generalnotification`
--

CREATE TABLE `generalnotification` (
  `id` int(11) NOT NULL,
  `notification` text NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generalnotification`
--

INSERT INTO `generalnotification` (`id`, `notification`, `admin`, `c_id`, `u_id`) VALUES
(2, '<b>General Notification 1</b>', 1, '2018-07-30 13:59:43', '2018-07-30 13:59:43'),
(3, '<b>General Notification 2</b>', 1, '2018-07-30 13:59:57', '2018-07-30 13:59:57'),
(4, '<b>General Notification 3...</b>', 1, '2018-07-30 14:00:06', '2018-07-30 14:00:18'),
(5, '<b>Here We Can Put General Notification...&nbsp;</b>', 1, '2018-08-03 03:24:39', '2018-08-03 03:24:39');

-- --------------------------------------------------------

--
-- Table structure for table `jobgroup`
--

CREATE TABLE `jobgroup` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobgroup`
--

INSERT INTO `jobgroup` (`id`, `name`, `admin`, `c_id`, `u_id`) VALUES
(4, 'HSSC', 1, '2018-07-27 03:04:11', '2018-07-27 03:04:11'),
(5, 'SSC', 1, '2018-07-27 03:04:16', '2018-07-27 03:04:16'),
(6, 'Railway', 1, '2018-07-27 03:04:37', '2018-07-27 03:04:37');

-- --------------------------------------------------------

--
-- Table structure for table `jobnotification`
--

CREATE TABLE `jobnotification` (
  `id` int(11) NOT NULL,
  `jobGroup` varchar(100) NOT NULL,
  `notification` text NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobnotification`
--

INSERT INTO `jobnotification` (`id`, `jobGroup`, `notification`, `admin`, `c_id`, `u_id`) VALUES
(4, 'HSSC', '<b>Job Notification 1</b>', 1, '2018-07-29 12:19:17', '2018-07-29 12:19:17'),
(5, 'HSSC', 'HSSC Police Job:-<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Total Post:12000</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Last Date:07-08-2018</div>', 1, '2018-08-03 02:40:45', '2018-08-03 02:40:45'),
(6, 'SSC', '<b>This Is Our SSC(Staff Selection Commision Notification Panel)</b>', 1, '2018-08-03 02:46:07', '2018-08-03 02:46:07');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `news` text NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `news`, `admin`, `c_id`, `u_id`) VALUES
(4, '<b>This Is Our News And Update Section Here We Put Daily News And Updates Regarding Our Courses ... So Stay Tuned......</b>', 1, '2018-07-26 07:33:14', '2018-07-26 07:41:35');

-- --------------------------------------------------------

--
-- Table structure for table `questionpaper`
--

CREATE TABLE `questionpaper` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `totalQuestions` int(11) NOT NULL,
  `totalMarks` int(11) NOT NULL,
  `totalTime` int(11) NOT NULL,
  `marksPerQuestion` float NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questionpaper`
--

INSERT INTO `questionpaper` (`id`, `title`, `totalQuestions`, `totalMarks`, `totalTime`, `marksPerQuestion`, `c_id`, `u_id`) VALUES
(8, 'HTML Quiz', 30, 30, 10, 1, '2018-08-10 04:35:08', '2018-08-10 04:35:19'),
(9, 'JS Quiz', 100, 100, 5, 1, '2018-08-10 10:33:28', '2018-08-10 10:33:28');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `questionPaperId` int(11) NOT NULL,
  `question` text NOT NULL,
  `option1` text NOT NULL,
  `option2` text NOT NULL,
  `option3` text NOT NULL,
  `option4` text NOT NULL,
  `answer` varchar(30) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `questionPaperId`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`, `c_id`, `u_id`) VALUES
(5, 8, 'what is HTML', 'hyper text modern language', 'hight text modern language', 'high text markup language', 'hyper text markup Language', 'Option4', '2018-08-10 09:37:49', '2018-08-11 03:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `id` int(11) NOT NULL,
  `session` varchar(20) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `session`, `c_id`, `u_id`) VALUES
(1, '2018-19', '2018-08-04 04:32:59', '2018-08-04 04:32:59'),
(2, '2019-20', '2018-08-07 13:06:44', '2018-08-07 13:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `fname` varchar(80) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `city` varchar(80) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `course` varchar(90) NOT NULL,
  `session` int(11) NOT NULL,
  `image` text NOT NULL,
  `studentEmail` varchar(80) NOT NULL,
  `password` varchar(60) NOT NULL,
  `ci_d` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `fname`, `dob`, `gender`, `city`, `address`, `mobile`, `course`, `session`, `image`, `studentEmail`, `password`, `ci_d`, `u_id`) VALUES
(25, 'Karan Soni', 'Brij Lal', '1997-08-13', 'Male', 'Sirsa', 'Boys Hostel 2 CDLU Sirsa', '9466067763', 'Basic Computer Course', 1, 'Karan SoniBrij Lal1997-08-13IMG_20161118_210109~3.jpg', '13081997@Basic Computer Course1.com', '13/08/1997', '2018-08-08 07:29:45', '2018-08-08 07:34:57'),
(26, 'Karan Soni', 'Brij Lal', '1997-08-13', 'Male', 'Sirsa', 'Boys Hostel 2 CDLU Sirsa', '9466067763', 'BASIC HTML', 2, 'Karan SoniBrij Lal1997-08-13IMG_20170225_090443_341.jpg', '13081997@BASIC HTML2.com', '13/08/1997', '2018-08-08 07:30:38', '2018-08-08 07:30:38'),
(27, 'XYZ', 'PQR', '1996-12-01', 'Male', 'Ellenabad', 'Ward No. Hanumangarh Road Ellenabad', '9068348663', 'Basic Computer Course', 1, 'XYZPQR1996-12-0110002081.jpg', '01121996@Basic Computer Course1.com', '01/12/1996', '2018-08-12 02:09:41', '2018-08-12 02:09:41');

-- --------------------------------------------------------

--
-- Table structure for table `superuser`
--

CREATE TABLE `superuser` (
  `id` int(11) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `superuser`
--

INSERT INTO `superuser` (`id`, `email`, `password`, `c_id`, `u_id`) VALUES
(1, 'skaran921@gmail.com', 'skaran921', '2018-08-03 12:46:04', '2018-08-03 12:46:04');

-- --------------------------------------------------------

--
-- Table structure for table `thought`
--

CREATE TABLE `thought` (
  `id` int(11) NOT NULL,
  `thought` text NOT NULL,
  `author` varchar(80) NOT NULL,
  `admin` int(11) NOT NULL,
  `c_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thought`
--

INSERT INTO `thought` (`id`, `thought`, `author`, `admin`, `c_id`, `u_id`) VALUES
(1, '<b>Success Comes From Experiance end Experiance Comes From Bad Experiance</b>', 'Sandeep Meheshwari...', 1, '2018-07-19 08:04:07', '2018-07-22 10:30:42'),
(3, 'You can never understand everything. But, you should push yourself to understand the system', 'Unknown', 1, '2018-07-22 11:40:44', '2018-07-24 07:40:12'),
(4, 'Failure is the part of the success<span style=\"white-space:pre\">			</span>', 'Unknown', 1, '2018-07-24 07:29:36', '2018-07-28 03:29:23');

-- --------------------------------------------------------

--
-- Table structure for table `today_thought`
--

CREATE TABLE `today_thought` (
  `id` int(11) NOT NULL,
  `thought` int(11) NOT NULL,
  `u_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `today_thought`
--

INSERT INTO `today_thought` (`id`, `thought`, `u_id`) VALUES
(2, 1, '2018-07-24 09:57:39');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_counter`
--

CREATE TABLE `visitor_counter` (
  `id` int(11) NOT NULL,
  `total_visitors` int(50) NOT NULL,
  `u_id` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor_counter`
--

INSERT INTO `visitor_counter` (`id`, `total_visitors`, `u_id`) VALUES
(1, 668, '2019-02-13 16:39:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_session`
--
ALTER TABLE `current_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `download`
--
ALTER TABLE `download`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generalnotification`
--
ALTER TABLE `generalnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobgroup`
--
ALTER TABLE `jobgroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobnotification`
--
ALTER TABLE `jobnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionpaper`
--
ALTER TABLE `questionpaper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `superuser`
--
ALTER TABLE `superuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thought`
--
ALTER TABLE `thought`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `today_thought`
--
ALTER TABLE `today_thought`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitor_counter`
--
ALTER TABLE `visitor_counter`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `current_session`
--
ALTER TABLE `current_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `download`
--
ALTER TABLE `download`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `fee`
--
ALTER TABLE `fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `generalnotification`
--
ALTER TABLE `generalnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `jobgroup`
--
ALTER TABLE `jobgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `jobnotification`
--
ALTER TABLE `jobnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `questionpaper`
--
ALTER TABLE `questionpaper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `superuser`
--
ALTER TABLE `superuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `thought`
--
ALTER TABLE `thought`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `today_thought`
--
ALTER TABLE `today_thought`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `visitor_counter`
--
ALTER TABLE `visitor_counter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
