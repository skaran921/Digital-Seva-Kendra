<?php 
$page_id=4;
$notification_page_id=2;
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg"> 
    <title>General Notification - Digital Seva Kendra</title>	
  </head>
  <body>
        <?php include 'header.php'; ?>
        <?php include 'includeFunctions.php'; ?>
      	<br>
      	<br>
      	<br>
        <div class="container-fluid">
		   <div class="card">
		         <div class="card-header w3-win8-green  text-light">
				    <b><i class="fa fa-check-square"></i> General Notification</b>
				 </div>
		       <div class="card-body">
			         <div class="table-responsive">
					      <table class="table table-bordered">
						      <tr class="thead-dark text-center">
							     <th>Sr. No.</th>
								 <th>Notification Date</th>
							     <th>Notification Name</th>							     
							  </tr>
							    <?php   
								    include "db.php";
									$sql="SELECT notification,c_id FROM generalnotification ORDER BY u_id DESC";
									$result=$conn->query($sql);
									$sr=1;
									while($row=$result->fetch_assoc()){
									      ?>
										<tr align="center">
										   <td class="text-light bg-dark font-weight-bold"><?php echo $sr; ?></td>
										   <td class="font-weight-bold"><?php echo date("d-m-y",strtotime($row["c_id"])); ?></td>
										   <td><?php echo $row["notification"];?></td>
										</tr>
										  <?php
                                         $sr++;										  
									}
								?>
						  </table>
					 </div>
			   </div>
				<div class="card-footer w3-win8-emerald">
				</div>
		   </div>
		</div>
        <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
   
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>
