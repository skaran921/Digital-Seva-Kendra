<?php 
$page_id=1;
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg"> 
    <title>Home - Digital Seva Kendra</title>	
	<style>	
   @keyframes btn {
     0% {
          box-shadow: 0 0 12px rgba(51, 204, 255, 0.2);
          color:rgba(51, 204, 255, 0.2);
        }
    25% {
          box-shadow: 0 0 12px rgba(51, 204, 255, 0.4);
          color:rgba(51, 204, 255, 0.4);
        }
    50% {
          box-shadow: 0 0 12px rgba(51, 204, 255, 0.9);
          color:rgba(51, 204, 255, 0.9);
        }
   100% {
          box-shadow: 0 0 12px rgba(51, 204, 255, 0.2);
          color:rgba(51, 204, 255, 0.2);
        }
    }
	.fa-angle-right{   
       animation-name:btn;
       animation-duration: 1.5s;
       animation-iteration-count: infinite;
       animation-timing-function: ease-in-out;
	}
	/* Blockquote*/
	blockquote{
	   border-left:none;
	}
	.quote-badge{
	   background-color:rgba(0,0,0,0.2);
	}
	.quote-box{
	   overflow:hidden;
	   background-color:#f9f9f9;
	   color:black;
	   padding:10px;
	   border-radius:17px;
	   box-shadow:2px 2px 2px 2px #e0e0e0;
	   cursor:pointer;
	}
	
	.quote-mark:before{
		   content:open-quote;
		  font-weight:bold;
		  font-size:100px;
		  color:black;
		  font-family:"times new roman",georgia,serif;
	}
	
	.quote-text{
		font-size:19px;
		margin-top:-60px;
	}
	
	
</style>
  </head>
  <body>
        <?php include 'header.php'; ?>
        <?php
      		include 'includeFunctions.php';
			update_visitors();
		?>
		<br>
		<br>
		<br>
		  <div class="container-fluid">
		  <center>
		      <div class="row">
			     <div class="col-sm-12">
				       <div id="my-slider" class="carousel slide" data-ride="carousel">
					      
						  <!-------indicators dot --------------->
						       <ol class="carousel-indicators">
							      <li class="active" data-target="#my-slider" data-slide-to="0"></li>
								  <li data-target="#my-slider" data-slide-to="1"></li>
								  <li data-target="#my-slider" data-slide-to="2"></li>
								  <li data-target="#my-slider" data-slide-to="3"></li>
								  <li data-target="#my-slider" data-slide-to="4"></li>
							   </ol>
						  <!-----------Slides-------------------->
						        <div class="carousel-inner" role="listbox">
								  <div class="carousel-item active">
									       <img src="image/11.jpg" class="img-fluid" style="width:1300px;max-height:500px"  alt="Digital India" >
										     <div class="carousel-caption">											    
											 </div>
									   </div>
								       <div class="carousel-item">
									      <img src="image/4.jpg" class="img-fluid" style="width:1300px;max-height:500px" alt="Digital India" >
										    <div class="carousel-caption">
											     <h1><i class="fa fa-laptop"></i>Digital Seva Kendra, Ellenabad</h1>
												  <a href="admission.php" data-toggle="tooltip" title="click me to get Admission Online" data-placement="right">
												     <button class="btn btn-success"><i class="fa fa-mortar-board"></i> Get Admission Now</button>
												  </a>
											 </div>
									   </div>
									   <div class="carousel-item">
									       <img src="image/5.jpg" class="img-fluid" style="width:1300px;max-height:500px" alt="Digital India" >
										     <div class="carousel-caption">
											     <h1>Learn <i class="fa fa-code"></i> Programming With Us.</h1>
										       <a href="#course" data-toggle="tooltip" title="click me to see various course detail" data-placement="right">
										              <button class="btn btn-info" onclick="window.location.href='#course'"><i class="fa fa-book"></i> See Course's</button>
										           </a>	
											 </div>
									   </div>
									   
									    <div class="carousel-item">
									       <img src="image/6.jpg" class="img-fluid" style="width:1300px;max-height:500px"  alt="Digital India" >
										     <div class="carousel-caption">
											     <h1 class="bg-warning text-light">Learn With Digital Seva Kendra</h1>
								                 	<a href="#message" data-toggle="tooltip" title="any doubt/query? ask question" data-placement="right">
									                   <button class="btn btn-danger" onclick="window.location.href='#message'">any question? ask</button>
												   </a>
											 </div>
									   </div>
									   
									    <div class="carousel-item">
									       <img src="image/3.jpg" class="img-fluid" style="width:1300px;max-height:500px"  alt="Digital India" >
										     <div class="carousel-caption">
											     <h1 class="text-light bg-dark">Founder Of Digital Seva Kendra, Ellenabad</h1>
									                <a href="#contact" data-toggle="tooltip" title="Send Message Us." data-placement="right">
									                   <button class="btn btn-primary"><i class="fa fa-map-marker"></i> Contact us</button>
													</a>
											 </div>
									   </div>
									   
									   <div class="item">
									   </div>
								  </div>
				</center>				  
						  <!---------------left right button---------------->
						  
						  <a href="#my-slider" class="carousel-control-prev" data-slide="prev">
						     <span class="carousel-control-prev-icon text-dark"></span>
						  </a>
						  
						  <a href="#my-slider" class="carousel-control-next" data-slide="next">
						     <span class="carousel-control-next-icon"></span>
						  </a>
						  
						  
						  
					   </div>
				 </div>
			  </div>
		  </div>
		  
		 <div class="container" style="margin-top:6px;margin-bottom:6px;" id="course">
		      <div class="card">
			         <div class="card-header text-light" style="background-color:red;">
					    <b>Course's</b>
					 </div>
					   <div class="card-body"><!--------main body--------->
					      <div class="row"><!-------row inside card-body ---------> 						    	
                                    <?php get_last_added_three_course(); ?>						
					     </div>	
					      <center>
						   <a href="all course.php" data-toggle="tooltip" title="don't interested in these course's? don't worry!!! click me to see more course" data-placement="right">
						     <button type="button" class="btn btn-primary" style="margin-top:10px"><i class="fa fa-hand-o-right"></i> More Course's
            							 <i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i>
							</button>
						   </a>	
						  </center>
				   </div>
			  </div>
         </div>		 
		  
  <div class="container" style="margin-top:6px;margin-bottom:6px;">		  
    <div class="row"> <!------row ---------->
	             
	             <div class="card-deck col-sm-4">
      				 <div class="card">
					    <div class="card-header" style="background-color:#003366;color:white;">
						   <b><i class="fa fa-lightbulb-o text-warning"></i> Today's Thought</b>						     
						</div>
						<div class="card-body">
						   <center>    <i class="fa fa-hand-o-down" style="font-size:50px;"></i></center>
						   							      
							     <?php echo get_today_thought()?>
							
						</div>
					 </div>
				 </div>
		     <!---------Col--------->
	               <div class="card-deck col-sm-4">				     
				     <div class="card">
					    <div class="card-header" style="background-color:green;color:white;">
						   <b><i class="fa fa-newspaper-o"></i> News & Updates</b>
						</div>
						<div class="card-body">
						    <marquee direction="up" onmouseover="stop()" scrollamount="3" onmouseout="start()";>
							     <ul class="list-group">
								    <?php get_news(); ?>								   
								 </ul>
							</marquee>
						</div>
					 </div>
				 </div>
		     <!---------Col--------->			 	      
		 <div class="card-deck col-sm-4" id="message">
		     <div class="card">
			    <div class="card-header bg-danger text-light">
				    <b><i class="fa fa-envelope-square"></i> Contact Us.</b>
				</div>
			      <div class="card-body">				       
				     <p class="card-text">
					     <form action="index.php" id="contactForm" name="contactForm" method="post">
						     <div class="form-group">
							     <label class="form-check-label"><b><i class="fa fa-user"></i> Name:<i class="fa fa-asterisk text-danger"></i></b></label>
								 <input type="text" name="name" id="name" class="form-control" placeholder="Your Name" required>
								 <label class="form-check-label"><b><i class="fa fa-mobile"></i> Mobile:<i class="fa fa-asterisk text-danger"></i></b></label>
								 <input type="number" name="mobile" id="mobile" class="form-control" placeholder="Your Mobile No." required>
								 <label class="form-check-label"><b><i class="fa fa-envelope"></i> Message:<i class="fa fa-asterisk text-danger"></i></b></label>
								 <textarea  id="message1" name="message" class="form-control" placeholder="Your Message..." required></textarea><br>
								   <button type="button" class="btn btn-block btn-success" name="send" onclick="validateContact()"><i class="fa fa-send"> Send Message</i></button>
							 </div>
						 </form>
					 </p>
				  </div>
			 </div>
		 </div>
	  <!---------Col--------->	         
		  
    </div>
	   
</div>	

        <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="jsFunction.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>


<?php
  if((isset($_POST["name"])) && (isset($_POST["mobile"])) && (isset($_POST["message"])))
  {
	 $name=$_POST["name"];
	 $mobile=$_POST["mobile"];
	 $message=$_POST["message"];	
	 include 'db.php';
	 $sql="INSERT INTO contact(name,mobile,message)VALUES('$name','$mobile','$message')";
	 $result=$conn->query($sql);
	 if($result==TRUE)
	 {
		 ?>
		    <script>
			let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Message Send!!!</div>";
            alertify.alert(msg);
            alertify.log(msg);		
			</script>
		 <?php
	 }
	 else
	 {
		  ?>
		    <script>
			let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>Error!!! Message Not Send!!!</div>";
            alertify.alert(msg);
            alertify.log(msg);		
			</script>
		 <?php
	 }
  }
?>