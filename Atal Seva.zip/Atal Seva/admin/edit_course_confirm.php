<?php
session_start();
$page_id=3;
$course_page_sub_id=2;
if(isset($_SESSION["admin_id"]))
{

}
else
{
	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit Course - Digital Seva Kendra</title>
	<style>
	    button{box-shadow:4px 4px 8px #999;}
			td{box-shadow:1px 2px 2px blue;font-family: cursive;}
			body{
				   background: linear-gradient(45deg,blue,red);
			}
	</style>
  </head>
  <body class="text-dark">

        <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
<?php
  if(isset($_GET["course_id"]))
  {
		include 'db.php';
		$course_id=$_GET["course_id"];
		$sql="SELECT * FROM course WHERE id='$course_id'";
		$result=$conn->query($sql);
		if($row=$result->fetch_assoc()){
		?>
		<center>
		   <div  style="max-width:500px;" align="left">
		       <div class="card">
			     <div class="card-header w3-win8-blue">
				    <b><i class="fa fa-edit"></i> Edit Course</b>
				 </div>
			     <div class="card-body">
				      <form action="" method="post" id="addCourseForm"  name="addCourseForm">
								    <input type="hidden" name="course_id" id="course_id" value="<?php echo $row['id'];?>" required>
					      <div class="form-group">
									<label><b><i class="fa fa-contact"></i>Select Box Color:<i class="fa fa-asterisk text-danger"></i></b></label>
									<input type="color" name="color" id="color" class="form-control" value="<?php echo $row["color"];?>" title="Select Course Box Colour Here" data-toggle="tooltip" data-placement="left" tabindex="1" accesskey="c" required autofocus>


						      <label><b><i class="fa fa-contact"></i> Course Title:<i class="fa fa-asterisk text-danger"></i></b></label>
			<input type="text" name="title" id="title" class="form-control" value="<?php echo $row["title"];?>" placeholder="Course Title eg. Typing Course" title="New Course Title Write Here eg. HTML" data-toggle="tooltip" data-placement="left" tabindex="2" accesskey="t" x-webkit-speech required>

							  <label><b><i class="fa fa-money"></i> Course Fee:<i class="fa fa-asterisk text-danger"></i></b></label>
							  <input type="number" name="fee" id="fee" class="form-control" value="<?php echo $row["fee"];?>" placeholder="Course Fee in Rs." title="New Course Fee Comes Here" data-toggle="tooltip" data-placement="left" tabindex="3" accesskey="c" required>

		<label><b><i class="fa fa-calendar"></i> Select Course Duration:<i class="fa fa-asterisk text-danger"></i></b></label>
			<select class="form-control" name="duration" id="duration" data-toggle="tooltip" data-placement="left" title="Select Course Duration Here"  tabindex="4" accesskey="c"required>
		      <option><?php echo $row["duration"]; ?></option>
		      <option value="">Select Course Duration</option>
				  <option>15 Days</option>
				  <option>1 Month</option>
				  <option>2 Month</option>
				  <option>3 Month</option>
				  <option>4 Month</option>
				  <option>5 Month</option>
					<option>6 Month</option>
					<option>7 Month</option>
					<option>8 Month</option>
					<option>9 Month</option>
					<option>10 Month</option>
					<option>11 Month</option>
					<option>1 Year</option>
					<option>2 Year</option>
		  </select><br>
			<label for="syllabus"><i class="fa fa-book"></i><b> Syllabus <i class="fa fa-asterisk text-danger"></i> </b></label>
		<textarea name="syllabus" id="syllabus" placeholder="Write Course syllabus Here" class="form-control" required style="display:none;"><?php echo $row["syllabus"];?></textarea>
			<div class="container text-center">
				    <ul class="list-inline">
				    	<li class="list-inline-item">
								   <button type="button" class='card btn' onclick="textBold()"><i class="fa fa-bold"></i></button>
							</li>
							<li class="list-inline-item">
								   <button type="button" class='card btn' onclick="textItalic()"><i class="fa fa-italic"></i></button>
							</li>
							<li class="list-inline-item">
								   <button type="button" class='card btn'onclick="textUnderline()"><i class="fa fa-underline"></i></button>
							</li>
							<li class="list-inline-item">
								   <button type="button" class='card btn' onclick="textUorederedList()"><i class="fa fa-list-ul"></i></button>
							</li>

							<li class="list-inline-item">
								   <button type="button" class='card btn' onclick="textOrederedList()"><i class="fa fa-list-ol"></i></button>
							</li>

							<li class="list-inline-item">
								   <button type="button" class='card btn' onclick="textLink()"><i class="fa fa-link"></i></button>
							</li>
				    </ul>
			</div><center>
			<iframe class="Form-control" name="editor" style="max-width:90%;box-shadow:4px 8px 8px #666;border-radius:12px;" accesskey="s" tabindex="5"></iframe>
		</center>
					<br>

			<center class="m-4">
				 <button type="button" name="update_course" onclick="validate()" title="Heyy!!! Click On Me To Update This Course" data-toggle="tooltip" data-placement="left" class="btn w3-win8-green">
				   <i class="fa fa-check"></i> Update Course
				 </button>

				  <button type="reset" title="Hey!!! Click On Me To Reset Form" data-toggle="tooltip" data-placement="right" class="btn w3-win8-red">
				    <i class="fa fa-refresh"></i> Reset
				 </button>
		    </center>
						  </div>
					  </form>
				 </div>
				 <div class="card-footer w3-win8-green">
				 </div>
			   </div>
		   </div>
		</center>
		           <script>
		                  window.frames["editor"].document.body.innerHTML="<?php echo $row['syllabus']; ?>";
		           </script>
<?php
}#if close
else {
	// code...
}
}#isset
?>
				<?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
editor.document.designMode="on";
   function validate()
	 {

		 document.getElementById('syllabus').value=window.frames['editor'].document.body.innerHTML;;
		 let color = document.getElementById('color').value;
		 let title = document.getElementById('title').value;
		 let fee = document.getElementById('fee').value;
	   let duration = document.getElementById('duration').value;
	   let syllabus = document.getElementById('syllabus').value;
		 if (color=="") {
			    let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Please Select a Colour!!!</div>";
          alertify.alert(msg);
          alertify.error(msg);
		 } else if(title.length<1){
			 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Please Write Course Title!!!</div>";
			 alertify.alert(msg);
			 alertify.error(msg);

		 }else if((fee.length<1) || (isNaN(fee)))
		 {
			 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Course Fee is Not Valid!!!</div>";
			 alertify.alert(msg);
			 alertify.error(msg);
		 }else if(duration.length<1)
		 {
			 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Please Select Course Duration!!!</div>";
			 alertify.alert(msg);
			 alertify.error(msg);
		 }else if(syllabus.length<1)
		 {
			 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Syllabus field Blank!!!</div>";
			 alertify.alert(msg);
			 alertify.error(msg);
		 }else {
          document.getElementById("addCourseForm").submit();
		 }
	 }
</script>

<?php
if((isset($_POST["color"])) && (isset($_POST["title"])) && (isset($_POST["fee"])) && (isset($_POST["duration"])) && (isset($_POST["syllabus"])))
{
			include 'db.php';
			$course_id=$_POST["course_id"];
			$color=addslashes($_POST["color"]);
			$title=$_POST["title"];
			$fee=$_POST["fee"];
			$duration=$_POST["duration"];
			$syllabus=addslashes($_POST["syllabus"]);
			$admin_id=$_SESSION["admin_id"];
			$sql="UPDATE course SET color='$color',title='$title',fee='$fee',duration='$duration',syllabus='$syllabus',admin='$admin_id' WHERE id='$course_id'";
			$result=$conn->query($sql);
			if($result==TRUE){
				?>
				 <script>
						let msg="<div class='card text-primary p-4 font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Course Updated!!!</div>";
              window.opener.location.reload(true);
						  alertify.alert(msg,function(){window.close();});
					    alertify.error(msg);
				 </script>
			 <?php
			}else {
				?>
					<script>
						 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>oops!!! error!!! Course Not Updated!!!</div>";
						 alertify.alert(msg);
						 alertify.error(msg);
					</script>
				<?php
			}
}
?>
