<?php
session_start();
$super_user_page_id=3;
$setting1_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Add Session - Digital Seva Kendra</title>
    <style>
        form{
            position :relative;
            top:-40px;
            color: #fff;
            max-width:400px;
            box-shadow: 10px 10px 10px rgba(0,0,0,0.3);
            padding: 20px;
            border-radius: 20px;
        }
        form .btn{
               position: relative;
               left:40px;
               font-size:18px;
               border-radius:20px;
               box-shadow:0 10px 10px rgba(0,0,100,0.7);
        }

        form .btn:hover{
               transition: 2s;
               background:rgba(0,0,10,0.7);
        }

        #card-icon{
                font-size:50px;
                position: relative;
                width: 100px;
                height: 100px;
                line-height: 100px;
                color:#fff;
                background:linear-gradient(-45deg,indigo,purple,blue);
                box-shadow: 0 10px 10px rgba(0,0,0,0.3);
                border-radius: 50%;
                top:-60px;
        }
        #main-card{
              background:linear-gradient(-45deg,indigo,purple,blue);
        }

    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
           <div class="container">
                <div class="card" id="main-card">
                     <div class="card-body">
                             <center>
                                  <i class="fa fa-calendar-plus-o" id="card-icon"></i>
                                    <h4 class="text-light" style="position:relative;top:-50px;"><i class="fa fa-calendar-plus-o"></i> Add Session</h4>
                             </center>
                             <center>
                             <form action="add session.php" method="post" id="sessionForm">
                                 <div class="form-group form-inline">
                                    <label><b><i class="fa fa-asterisk text-danger"></i>Enter Session:&nbsp;&nbsp;&nbsp;</b></label>
                                    <input type="text" name="session" id="session" class="form-control" data-toggle="tooltip" placeholder="Session For eg. 2018-19" title="Enter Me New Session for eg. 2018-19" required autofocus>

                                               <button type="button" onclick="validate()" name="add" class="btn mt-4 w3-win8-teal"><i class="fa fa-calendar-plus-o"></i> Add</button>&nbsp;
                                               <button type="reset" class="btn mt-4 w3-win8-red"><i class="fa fa-refresh"></i>  Reset</button>

                                 </div>
                             </form>
                           </center>
                     </div>
                      <div class="card-footer">

                      </div>
                </div>
           </div>
    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>

<script>
  function validate(){
    let session=document.getElementById("session").value;
    let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center>Please Enter Valid Session!!!</div>";
    sessionLength=session.length;
    if(sessionLength==7 && session.includes("-")){
           document.getElementById("sessionForm").submit();
           return true;
    }else {
        alertify.alert(msg);
        return false;
    }
  }
</script>


<?php
  if (isset($_POST["session"])) {
      $session=$_POST["session"];
      include "db.php";
      $sql1="SELECT * FROM session WHERE session='$session'";
      $result1=$conn->query($sql1);
      if($row1=$result1->fetch_assoc()){
           ?>
        <script>
            let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>This Session Already Exist!!!</div>";
            alertify.alert(msg);
            alertify.log(msg);
       </script>
           <?php
      }else {
             $sql2="INSERT INTO session(session)VALUES('$session')";
             $result2=$conn->query($sql2);
             if($result2==TRUE){
               ?>
            <script>
                let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>New Session Added!!!</div>";
                alertify.alert(msg);
                alertify.log(msg);
           </script>
               <?php
             }else {
               ?>
            <script>
                let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>error... Session Not Added!!!</div>";
                alertify.alert(msg);
                alertify.log(msg);
           </script>
               <?php
             }
      }
  }
 ?>
