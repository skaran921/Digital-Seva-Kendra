<?php
session_start();
$page_id=5;
$news_page_sub_id=5;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Add Job Notification - Digital Seva Kendra</title>
	<style>
	</style>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
          <div class="container">
              <div class="card">
                 <div class="card-header" style="background:linear-gradient(45deg,purple,white,purple);color:#fff;">
                     <b> <i class="fa fa-plus"></i> Add Job Notification</b>
                 </div>
                 <div class="card-body" style="background:linear-gradient(4deg,purple,blue,purple);color:#fff">
                         <form action="addJobNotification.php" method="post" id="addJobNotification">
                             <div class="form-group">
                                <label><b>Select Job Group:<i class="fa fa-asterisk text-danger"></i></b></label>
                                <select class="form-control" name="jobGroup" id="jobGroup" tabindex="1" data-toggle="tooltip" title="Select A Job Group" required autofocus style="max-width:400px;">
                                       <option value="">Select A Job Group</option>
                                       <?php
                                               include "db.php";
                                               $sql="SELECT name FROM jobGroup";
                                               $result=$conn->query($sql);
                                               while($row=$result->fetch_assoc()){
                                                           ?>
                                                             <option><?php echo $row["name"]; ?></option>
                                                           <?php
                                               }
                                        ?>
                                </select>
                               <label><i class="fa fa-newspaper-o"></i><b> New Job Notification:<i class="fa fa-asterisk text-danger"></i> </b></label>
                            <textarea name="notification" id="notification" placeholder="" class="form-control" required style="display:none;"></textarea>
                              <div class="container text-center">
                                    <ul class="list-inline">
                                      <li class="list-inline-item">
                                           <button type="button" class='card btn' onclick="textBold()"><i class="fa fa-bold"></i></button>
                                      </li>
                                      <li class="list-inline-item">
                                           <button type="button" class='card btn' onclick="textItalic()"><i class="fa fa-italic"></i></button>
                                      </li>
                                      <li class="list-inline-item">
                                           <button type="button" class='card btn'onclick="textUnderline()"><i class="fa fa-underline"></i></button>
                                      </li>
                                      <li class="list-inline-item">
                                           <button type="button" class='card btn' onclick="textUorederedList()"><i class="fa fa-list-ul"></i></button>
                                      </li>

                                      <li class="list-inline-item">
                                           <button type="button" class='card btn' onclick="textOrederedList()"><i class="fa fa-list-ol"></i></button>
                                      </li>

                                      <li class="list-inline-item">
                                           <button type="button" class='card btn' onclick="textLink()"><i class="fa fa-link"></i></button>
                                      </li>
                                    </ul>
                              </div><center>
                              <iframe class="Form-control" name="editor" style="max-width:90%;box-shadow:4px 8px 8px #666;border-radius:12px;background-color:#fff;" accesskey="N" tabindex="2"></iframe>
                             </div>
                             <center>
                                   <button type="button" class="btn btn-success" name="add" accesskey="A" onclick="validate()"><i class="fa fa-check-circle"></i> Add</button>
                                   <button type="reset" class="btn btn-danger" onclick="resetForm()"><i class="fa fa-refresh"></i> Reset</button>
                             </center>
                         </form>
                 </div>
                 <div class="card-footer" style="background:linear-gradient(45deg,purple,white,purple);color:#fff;">

                 </div>
              </div>

          </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
  editor.document.designMode="on";
  function validate(){
    document.getElementById('notification').value=window.frames['editor'].document.body.innerHTML;
    let jobGroup=document.getElementById("jobGroup").value;
    let notification=document.getElementById("notification").value;
    if(jobGroup.length<=1){
              alertify.alert("<div class='card'><b><center><i class='fa fa-times-circle text-danger' style='font-size:100px;'></i></center>Please Select Job Group!!!</b></div>");
    }else if(notification.length<=1){
          alertify.alert("<div class='card'><b><center><i class='fa fa-times-circle text-danger' style='font-size:100px;'></i></center>Please Enter Some Notification In Box!!!</b></div>");
    }
    else {
               document.getElementById("addJobNotification").submit();
    }
  }
//validate() end;

function resetForm(){
   window.frames["editor"].document.body.innerHTML="";
}
</script>

<?php
   if((isset($_POST["jobGroup"])) && isset($_POST["notification"])){
         include 'db.php';
         $jobGroup=$_POST["jobGroup"];
         $notification=addslashes($_POST["notification"]);
         $admin_id=$_SESSION["admin_id"];
         $sql="SELECT * From jobnotification WHERE notification='$notification'";
         $result=$conn->query($sql);
         if($row=$result->fetch_assoc()){
               ?>
                  <script>
                      let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>Sorry!!! This Notification Already Added!!!</div>";
                      alertify.alert(msg);
                      alertify.error(msg);
                  </script>
               <?php
         }else {
                 $sql1="INSERT INTO jobnotification(jobGroup,notification,admin)VALUES('$jobGroup','$notification','$admin_id')";
                 $result1=$conn->query($sql1);
                 if($result1==TRUE){
                   ?>
                      <script>
                          let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Notification Added!!!</div>";
                          alertify.alert(msg);
                          alertify.error(msg);
                      </script>
                   <?php
                 }else{
                   ?>
                      <script>
                          let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>Sorry!!! error!!! This Notification Not Added!!!</div>";
                          alertify.alert(msg);
                          alertify.error(msg);
                      </script>
                   <?php
                 }
         }
   }
?>
