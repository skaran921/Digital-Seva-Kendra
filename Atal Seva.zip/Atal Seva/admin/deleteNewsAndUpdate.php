<?php
session_start();
$page_id=5;
$news_page_sub_id=4;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit News And Update - Digital Seva Kendra</title>
	<style>
	</style>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
          <div class="container">
              <div class="card">
                 <div class="card-header" style="background:linear-gradient(10deg,purple,indigo,blue,purple);color:#fff;">
                     <b> <i class="fa fa-trash"></i> Delete News And Update</b>
                 </div>
                 <div class="card-body">
                      <div class="table-responsive table-bordered">
                        <table class="table" id="myTable">
                                    <tr class="thead-dark" align="center">
                                        <th>Sr. No.</th>
                                        <th>News & Update</th>
                                        <th><i class="fa fa-trash"></i></th>
                                    </tr>
                                    <?php
                                        getNewsForDeleteTable();
                                    ?>
                        </table>
                      </div>
                 </div>
                 <div class="card-footer" style="background:linear-gradient(10deg,purple,indigo,blue,purple);color:#fff;">
                 </div>
              </div>

          </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
function deleteNews(news_id){
             let msg="<b class='text-danger'><i class='fa fa-question' style='font-size:70px;'></i>are you Sure?</b>";
            alertify.confirm(msg,function(){ window.open("deleteNewsConfirm.php?news_id="+news_id,"_blank");});
}
</script>
