<?php
session_start();
$page_id=2;
$setting_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Add Job Notification Group - Digital Seva Kendra</title>
	   <script>
        window.onload=function(){
              jobGroup.document.focuse();
        };
     </script>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
            <div class="container" style="max-width:600px;">
                <div class="card">
                    <div class="card-header w3-win8-teal">
                        <b><i class="fa fa-plus"></i> Add Job Group</b>
                    </div>
                        <div class="card-body">
                          <p>
                              <i class="fa fa-hand-o-right text-primary"></i><b> Use <kbd>Alt+S</kbd> For Save</b><br>
                              <i class="fa fa-hand-o-right text-primary"></i><b> Use <kbd>Alt+R</kbd> For Reset</b>
                          </p>
                             <center>
                                 <form action="addJobGroup.php" method="post" align="left" id="jobGroupForm">
                                         <div class="form-group">
                                                  <label><b>Add New Job Group:<i class="fa fa-asterisk text-danger"></i></b></label>
                                                  <input type="text" name="jobGroup" id="jobGroup" class="form-control" data-toggle="tooltip" title="Here Write New Job Notification Group Name eg. HSSC,SSC" placeholder="New Job Notification Group Name" autofocus required>
                                                <center>
                                                  <button type="button" accesskey="S" onclick="validate()" class="btn w3-win8-indigo mt-2" data-toggle="tooltip" title="Click On Me Save This New Job Group" data-placement="left">
                                                    <i class="fa fa-save"></i> Save
                                                  </button>
                                                  <button type="reset" accesskey="R" class="btn w3-win8-red mt-2" data-toggle="tooltip" title="Click On Me Reset" data-placement="right">
                                                    <i class="fa fa-refresh"></i> Reset
                                                  </button>
                                                </center>
                                         </div>
                                 </form>
                             </center>
                        </div>
                        <div class="card-footer w3-win8-teal">

                        </div>

                </div>
            </div>
                <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
  function validate(){
    let jobGroup=document.getElementById("jobGroup").value;
    if(jobGroup.length<1){
            let msg="<div class='card'><center><i class='fa fa-times-circle text-danger' style='font-size:100px'></i></center><b>Sorry Group Name Field Are Blank !!!</b></div>";
            alertify.alert(msg);
            alertify.error(msg);
    }else {
          document.getElementById('jobGroupForm').submit();
    }
  }
</script>

<?php
   if(isset($_POST["jobGroup"])){
         $admin_id=$_SESSION["admin_id"];
         $jobGroup=$_POST["jobGroup"];
         include 'db.php';
     $sql1="SELECT name FROM jobGroup WHERE name='$jobGroup'";
    $result1=$conn->query($sql1);
    if($row1=$result1->fetch_assoc()){
             ?>
             <script>
               let msg="<div class='card'><center><i class='fa fa-warning text-danger' style='font-size:100px'></i></center><b>Sorry This Job Group Already Added!!! </b></div>";
               alertify.alert(msg);
               alertify.error(msg);
             </script>
      <?php
    } else {

         $sql="INSERT INTO jobGroup(name,admin)VALUES('$jobGroup','$admin_id')";
         $result=$conn->query($sql);
         if($result==TRUE){
           ?>
             <script>
                 let msg="<div class='card'><center><i class='fa fa-check-circle text-success' style='font-size:100px'></i></center><b>New Job Group Added!!!</b></div>";
                 alertify.alert(msg);
                 alertify.error(msg);
             </script>
           <?php
         }else {
           ?>
             <script>
                 let msg="<div class='card'><center><i class='fa fa-times-circle text-danger' style='font-size:100px'></i></center><b>error!!! </b></div>";
                 alertify.alert(msg);
                 alertify.error(msg);
             </script>
           <?php
         }
     }#else part of fetch_assoc;
   }#isset
 ?>
