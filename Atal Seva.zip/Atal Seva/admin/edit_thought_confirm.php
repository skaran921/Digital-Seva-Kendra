<?php
session_start();
$page_id=4;
$thought_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
}else{
	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit Thought - Digital Seva Kendra</title>
	<style>
	    button{box-shadow:4px 4px 8px #999;}
			td{box-shadow:1px 2px 2px blue;font-family: cursive;}
			body{
				   background: linear-gradient(45deg,blue,red);
			}

	</style>
  </head>
  <body class="text-dark">

        <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
<?php
  if(isset($_GET["thought_id"]))
  {
		include 'db.php';
		$thought_id=$_GET["thought_id"];
		$sql="SELECT * FROM thought WHERE id='$thought_id'";
		$result=$conn->query($sql);
		if($row=$result->fetch_assoc()){
		?>
		<center>
		   <div  style="max-width:500px;" align="left">
		       <div class="card">
			     <div class="card-header w3-win8-crimson">
				    <b><i class="fa fa-edit"></i> Edit Course</b>
				 </div>
			     <div class="card-body">
						 <form action="edit_thought_confirm.php" method="post" id="UpdateThoughtForm">
                 <input type="hidden" name="thought_id" id="thought_id" value="<?php echo $row['id'];?>" required>
							 <label for="thought"><i class="fa fa-lightbulb"></i><b> Thought:<i class="fa fa-asterisk text-danger"></i> </b></label>
						 <textarea name="thought" id="thought" placeholder="Write Thought Here" class="form-control" required style="display:none;"></textarea>
							 <div class="container text-center">
										 <ul class="list-inline">
											 <li class="list-inline-item">
														<button type="button" class='card btn' onclick="textBold()"><i class="fa fa-bold"></i></button>
											 </li>
											 <li class="list-inline-item">
														<button type="button" class='card btn' onclick="textItalic()"><i class="fa fa-italic"></i></button>
											 </li>
											 <li class="list-inline-item">
														<button type="button" class='card btn'onclick="textUnderline()"><i class="fa fa-underline"></i></button>
											 </li>
											 <li class="list-inline-item">
														<button type="button" class='card btn' onclick="textUorederedList()"><i class="fa fa-list-ul"></i></button>
											 </li>

											 <li class="list-inline-item">
														<button type="button" class='card btn' onclick="textOrederedList()"><i class="fa fa-list-ol"></i></button>
											 </li>

											 <li class="list-inline-item">
														<button type="button" class='card btn' onclick="textLink()"><i class="fa fa-link"></i></button>
											 </li>
										 </ul>
							 </div><center>
							 <iframe class="Form-control" name="editor" style="max-width:90%;box-shadow:4px 8px 8px #666;border-radius:12px;" accesskey="s" tabindex="5"></iframe>

												 <script>
																window.frames["editor"].document.body.innerHTML="<?php echo addslashes($row['thought']);?>";
												 </script>
						 </center>
										<label for=""><b><i class="fa fa-pencil"></i>Author:<i class="fa fa-asterisk text-danger"></i></b></label>
												 <input type="text" name="author" id="author"  class="form-control" placeholder="Author of Above Thought" value="<?php echo $row["author"]; ?>" data-toggle="tooltip" title="Here Come Writer Name of Above Thought">
									 <br>

							 <center class="m-4">
									<button type="button" name="add_thought" onclick="validate()" title="Click Me To Add New Thought" data-toggle="tooltip" data-placement="left" class="btn w3-win8-green">
										<i class="fa fa-check-square"></i> Update Course
									</button>

									 <button type="reset" title="Click Me To Reset Form" data-toggle="tooltip" data-placement="right" class="btn w3-win8-red">
										 <i class="fa fa-refresh"></i> Reset
									</button>
								 </center>
						 </form>
				 </div>
				 <div class="card-footer w3-win8-crimson">
				 </div>
			   </div>
		   </div>
		</center>

<?php
}#if close
else {
	// code...
}
}#isset
?>
				<?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
editor.document.designMode="on";
   function validate()
	 {

		 document.getElementById('thought').value=window.frames['editor'].document.body.innerHTML;
	   let thought = document.getElementById('thought').value;
	   let author = document.getElementById('author').value;
		 if(thought.length<1)
		 {
			 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Thought Field Blank!!!</div>";
			 alertify.alert(msg);
			 alertify.error(msg);
		 }else if(author.length<1){
			  let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Author Field Blank!!!</div>";
		   	alertify.alert(msg);
			  alertify.error(msg);
		 }else {
          document.getElementById("UpdateThoughtForm").submit();
		 }
	 }
</script>

<?php
  if((isset($_POST["thought"])) && (isset($_POST["author"]))){
		include 'db.php';
			$thought=$_POST["thought"];
			$thought_id=$_POST["thought_id"];
			$author=$_POST["author"];
			$admin_id=$_SESSION["admin_id"];
			$sql="UPDATE thought SET thought='$thought',author='$author' WHERE id='$thought_id'";
			$result=$conn->query($sql);
			if($result==TRUE){
				?>
				<script>
					 let msg="<div class='card text-primary p-4 font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Thought Updated!!!</div>";
							window.opener.location.reload(true);
						 alertify.alert(msg,function(){window.close();});
						 alertify.error(msg);
				</script>
			<?php
			}else {
				?>
					<script>
						 let msg="<div class='card text-danger p-4 font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>oops!!! error!!! Course Not Updated!!!</div>";
						 alertify.alert(msg);
						 alertify.error(msg);
					</script>
				<?php
			}
		}
?>
