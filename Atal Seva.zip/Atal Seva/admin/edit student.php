<?php
session_start();
$super_user_page_id=2;
$student_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Edit Student- Digital Seva Kendra</title>
    <style>
        tr:nth-child(odd){
          font-family: cursive;
          background-color:whitesmoke;
             box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        tr:nth-child(even){
          font-family: cursive;
          background-color:snow;
             box-shadow: 0 7px 8px rgba(0,0,0,0.3);
        }

        #card-icon{
                font-size:50px;
                position: relative;
                width: 100px;
                height: 100px;
                line-height: 100px;
                color:#fff;
                background:linear-gradient(-45deg,#ffec61,#f321d7);
                box-shadow: 0 10px 10px rgba(0,0,0,0.3);
                border-radius: 50%;
                top:-60px;
        }
        #main-card{
             background:linear-gradient(-45deg,#ffec61,#f321d7);
        }
        #table{
            position: relative;
            top:-50px;
        }
    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
      <div class="container-fluid">
           <div class="card" id="main-card">
              <div class="card-body">
                          <center>
                            <b><i class="fa fa-edit" id="card-icon"></i></b>
                           </center>
                  <div id="table" style="overflow-x:auto">
                      <input type="text" id="myInput" class="form-control" placeholder="Search Student..." data-toggle="tooltip" title="Enter Student Name/Father Name/DOB/Session/Course For Search Student">
                     <table class="table font-weight-bold">
                        <thead>
                            <tr class="thead-dark" align="center">
                               <th>Sr. No.</th>
                               <th>Image</th>
                               <th>Name</th>
                               <th>Father Name</th>
                               <th>DOB</th>
                               <th>Gender</th>
                               <th>Course</th>
                               <th>Session</th>
                               <th><i class="fa fa-edit"></i></th>
                            </tr>
                        </thead>
                        <tbody id="myTable">
                          <?php getEditStudentInfo();?>
                        </tbody>
                     </table>
                  </div>
              </div>
              <div class="card-footer">
              </div>
           </div>
      </div>
    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());

$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>
