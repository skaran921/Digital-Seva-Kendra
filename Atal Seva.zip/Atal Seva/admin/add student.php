<?php
session_start();
$super_user_page_id=2;
$student_page_sub_id=1;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Add Student- Digital Seva Kendra</title>
    <style>
         #form-card{
              background:linear-gradient(-45deg,#24ff72,#9a4eff);
              transition: 5s;
              color: #fff;
         }
         #card-logo{
              position: relative;
              color: #fff;
              font-size:30px;
              width:100px;
              height: 100px;
              line-height: 100px;
              background:linear-gradient(-45deg,#24ff72,#9a4eff);
              border-radius: 50px;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              top:-60px;
              padding: 20px;
         }
         label{
              width:200px;
              text-align: justify;
         }

         input{
              text-transform: capitalize;
         }

         .form-control{
               box-shadow: 0 10px 10px rgba(0,0,0,0.3);
               border-color: indigo;
               border-width:0px;
         }
         input[type="date"]{
             text-transform: uppercase;
         }

         .btn{
             font-size: 20px;
             box-shadow: 0 10px 10px rgba(0,0,0,.3);
             border-radius: 20px;
         }

         .btn:hover{
               background: rgba(0,0,0,.3);
               transition: 1s;
         }
    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
        <center>
            <div class="container" style="max-width:700px;margin-bottom:2px;">
                 <div class="card" id="form-card">
                      <div class="card-body">
                           <span id="card-logo"><i class="fa fa-user"></i> Add Student Record</span>
                             <form action="" method="post" align="left" style="position: relative;top:-30px;" id="studentForm" enctype="multipart/form-data">

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Student Name:&nbsp;</b></label>
                                         <input type="text" id="name" name="name" class="form-control" placeholder="Student Full Name" data-toggle="tooltip" title="Here Come Student Full Name" data-placement="right" autofocus required>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Father Name:&nbsp;</b></label>
                                         <input type="text" id="fname" name="fname" class="form-control" placeholder="Student Father Name" data-toggle="tooltip" title="Here Come Student Father Name" data-placement="right" required>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>DOB:&nbsp;</b></label>
                                         <input type="date" id="dob" name="dob" class="form-control" placeholder="Student Date OF Birth" data-toggle="tooltip" title="Here Come Student DOB(Date Of Birth)" data-placement="right" required>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Select Gender:&nbsp;</b></label>
                                         <select id="gender" name="gender" class="form-control"  data-toggle="tooltip" title="Select Gender" data-placement="right" required>
                                                   <option value="">Select Gender</option>
                                                   <option>Male</option>
                                                   <option>Female</option>
                                                   <option>Other</option>
                                         </select>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>City/Village:&nbsp;</b></label>
                                         <input type="text" id="city" name="city" class="form-control" placeholder="City/Village Name " data-toggle="tooltip" title="Here Come City/Village Name OF Student" data-placement="right" required>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Address:&nbsp;</b></label>
                                         <textarea id="address" name="address" class="form-control" placeholder="Full Address of Student" data-toggle="tooltip" title="Here Come Full Address OF Student eg. house no,ward No/colony,city/village,District,pin" data-placement="right" rows="3" cols="30" required></textarea>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Mobile No.:&nbsp;</b></label>
                                         <input type="number" id="mobile" name="mobile" class="form-control" placeholder="Mobile No." data-toggle="tooltip" title="Here Come 10 Digit Mobile No. OF Student" data-placement="right" required>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Select Course:&nbsp;</b></label>
                                         <select id="course" name="course" class="form-control"  data-toggle="tooltip" title="Select Course in Which Student Take Admission" data-placement="right" required>
                                                   <option value="">Select Course</option>
                                                   <?php
                                                      include "db.php";
                                                      $sql="SELECT title FROM course ORDER BY title";
                                                      $result=$conn->query($sql);
                                                      while ($row=$result->fetch_assoc()) {
                                                          ?>
                                                            <option><?php echo $row["title"];?></option>
                                                          <?php
                                                      }
                                                   ?>
                                         </select>
                                     </div>

                                     <div class="form-inline form-group">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Session:&nbsp;</b></label>
                                         <select id="session" name="session" class="form-control"  data-toggle="tooltip" title="Select Session in Which Student Take Admission" data-placement="right" required>
                                                   <?php
                                                   if(isset($_SESSION["current_session"])){
                                                         ?>
                                                          <option value="<?php echo current_session_selected_id($_SESSION["current_session"])?>">
                                                              <?php echo $_SESSION["current_session"]?>
                                                          </option>
                                                          <?php
                                                      }
                                                   ?>
                                                   <option value="">Select Session</option>
                                                   <?php
                                                      include "db.php";
                                                      $sql="SELECT session,id FROM session ORDER BY session";
                                                      $result=$conn->query($sql);
                                                      while ($row=$result->fetch_assoc()) {
                                                          ?>
                                                            <option value="<?php echo $row['id'];?>"><?php echo $row["session"];?></option>
                                                          <?php
                                                      }
                                                   ?>
                                         </select>
                                     </div>

                                     <div class="form-group form-inline">
                                         <label><b><i class="fa fa-asterisk text-danger"></i>Image:&nbsp;</b></label>
                                       <input type="file" id="image" name="image" class="form-control" accept="image/*" data-toggle="tooltip" title="Select Student Image" data-placement="right" required>
                                     </div>

                                  <center>
                                       <button type="submit" name="save" onclick="validate()" class="btn w3-win8-indigo" data-toggle="tooltip" data-placement="left" title="Click On Me To Save This Student Info">
                                         <i class="fa fa-save"></i> Save
                                       </button>

                                       <button type="reset" name="reset" class="btn w3-win8-red" data-toggle="tooltip" data-placement="right" title="Click On Me To Reset Form">
                                         <i class="fa fa-refresh"></i> Reset
                                       </button>
                                  </center>


                             </form>
                              </div>
                      </div>
                    <div class="card-footer">
                  </div>
                 </div>
            </div>
        </center>
    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<!-- <script src="js/jquery.min.js"></script> -->
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- <script src="js/jquery.form.min.js"></script> -->
<script src="alertify/js/alertify.js"></script>
<!-- <script src="js/textEditor.js"></script> -->
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());

$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>

<script>

 function validate(){
   let name=document.getElementById("name").value;
   let fname=document.getElementById("fname").value;
   let dob=document.getElementById("dob").value;
   let gender=document.getElementById("gender").value;
   let city=document.getElementById("city").value;
   let address=document.getElementById("address").value;
   let mobile=document.getElementById("mobile").value;
   let course=document.getElementById("course").value;
   let session=document.getElementById("session").value;
   let image=document.getElementById("image").value;
   let msg1="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Not a Valid Student Name<br>Please Enter Valid Student Name</div>";
   let msg2="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Enter Student Father Name</div>";
   let msg3="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Select Student DOB</div>";
   let msg4="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Select Student Gender</div>";
   let msg5="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Enter Student City/Village Name</div>";
   let msg6="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Enter Student Full Address</div>";
   let msg7="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Enter Valid Student Mobile No.</div>";
   let msg8="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Select Course Name In Which Student Take Admission</div>";
   let msg9="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Select Session In Which Student Take Admission</div>";
   let msg10="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> Please Select Student Image</div>";
   if((name.length<=1) || name.includes(0) || name.includes(1) || name.includes(2) || name.includes(3) || name.includes(4) || name.includes(5) || name.includes(6) || name.includes(7) || name.includes(8) || name.includes(9) ){
       alertify.alert(msg1);
       alertify.error(msg1);
   }else if((fname.length<=1) || fname.includes(0) || fname.includes(1) || fname.includes(2) || fname.includes(3) || fname.includes(4) || fname.includes(5) || fname.includes(6) || fname.includes(7) || fname.includes(8) || fname.includes(9) ){
       alertify.alert(msg2);
       alertify.error(msg2);
   }else if(dob.length<10){
       alertify.alert(msg3);
       alertify.error(msg3);
   }else if(gender.length<1){
       alertify.alert(msg4);
       alertify.error(msg4);
   }else if(city.length<1){
       alertify.alert(msg5);
       alertify.error(msg5);
   }else if(address.length<1){
       alertify.alert(msg6);
       alertify.error(msg6);
   }else if((mobile.length<10) || isNaN(mobile)){
       alertify.alert(msg7);
       alertify.error(msg7);
   }else if(course.length<1){
       alertify.alert(msg8);
       alertify.error(msg8);
   }else if(session.length<1){
       alertify.alert(msg9);
       alertify.error(msg9);
   }else if(image.length<1){
       alertify.alert(msg10);
       alertify.error(msg10);
   }
 }
</script>

<?php
  if( (isset($_POST["name"])) && (isset($_POST["fname"])) && (isset($_POST["dob"])) && (isset($_POST["gender"])) && (isset($_POST["city"])) && (isset($_POST["address"])) && (isset($_POST["mobile"])) && (isset($_POST["course"])) ){
    include 'db.php';
    $name=$_POST["name"];
    $fname=$_POST["fname"];
    $dob=$_POST["dob"];
    $gender=$_POST["gender"];
    $city=$_POST["city"];
    $address=$_POST["address"];
    $mobile=$_POST["mobile"];
    $course=$_POST["course"];
    $session=$_POST["session"];
    $image=$_FILES["image"]["name"];
    $imageName=$name.$fname.$dob.$image;
    $date=date("d",strtotime($dob));
    $month=date("m",strtotime($dob));
    $year=date("Y",strtotime($dob));
    $studentEmail=$date.$month.$year."@".$course.$session.".com";
    $password=date("d/m/Y",strtotime($dob));
    $file_dir="students/".$session."/".$course;
    if(!file_exists($file_dir)){
         mkdir($file_dir,0777,true);
    }
  $sql1="SELECT * FROM student WHERE name='$name' AND fname='$fname' AND dob='$dob' AND course='$course'";
  $result1=$conn->query($sql1);
  if($row1=$result1->fetch_assoc()){
                  ?>
          <script>
              let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> This Student Record Already Added!!!</div>";
              alertify.alert(msg);
              alertify.error(msg);
          </script>
                  <?php
  }else{
        $sql="INSERT INTO student(name,fname,dob,gender,city,address,mobile,course,session,image,studentEmail,password)VALUES('$name','$fname','$dob','$gender','$city','$address','$mobile','$course','$session','$imageName','$studentEmail','$password')";
        if(move_uploaded_file($_FILES["image"]["tmp_name"],$file_dir."/".$imageName)){
               $result=$conn->query($sql);
               if($result==TRUE){
                        ?>
                        <script>
  let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:200px;'></i><br>Saved!!!</center></div>";
                             alertify.alert(msg);
                             alertify.error(msg);
                        </script>
                        <?php
               }else{
                 ?>
         <script>
             let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center>error..Student Record Not Saved!!!</div>";
             alertify.alert(msg);
             alertify.error(msg);
         </script>
         <?php
               }
        }else{
          ?>
  <script>
      let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center>Image Not Uploaded!!!</div>";
      alertify.alert(msg);
      alertify.error(msg);
  </script>
          <?php
        }#fileupload
  }#else part of fetch_assoc
}#if isset
?>
