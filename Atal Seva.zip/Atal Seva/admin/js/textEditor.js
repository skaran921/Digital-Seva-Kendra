function textBold()
{
  editor.document.execCommand('bold');
}

function textItalic()
{
   editor.document.execCommand('italic');
}

function textUnderline()
{
   editor.document.execCommand('underline');
}

function textUorederedList()
{
   editor.document.execCommand('insertUnorderedList');
}

function textOrederedList()
{
   editor.document.execCommand('insertOrderedList');
}

function textLink()
{
  let address=prompt("Paste Your Link Here");
  if(address.includes('http'))
  {
    editor.document.execCommand('CreateLink',false,address);
  }
  else
  {
    alertify.alert("<div class='text-danger font-weight-bold card'><center><i class='fa fa-warning' style='font-size:50px;'></i></center> oops.....not a valid Link</div>");
  }
}
