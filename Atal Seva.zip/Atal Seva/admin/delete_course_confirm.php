<?php
session_start();
$page_id=3;
$course_page_sub_id=2;
if(isset($_SESSION["admin_id"]))
{

}
else
{
	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit Course - Digital Seva Kendra</title>
	<style>
	    button{box-shadow:4px 4px 8px #999;}
			td{box-shadow:1px 2px 2px blue;font-family: cursive;}
			body{
				   background: linear-gradient(45deg,blue,red);
			}
	</style>
  </head>
  <body class="text-dark">

        <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
      <script src="alertify/js/alertify.js"></script>
     <?php
         if(isset($_GET["course_id"])){
                $course_id=$_GET["course_id"];
                include 'db.php';
                $sql="DELETE FROM course WHERE id='$course_id'";
                $result=$conn->query($sql);
                if($result==TRUE){
                       ?>
                       <script>
                         let msg="<div class='card bg-success text-light'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Course Deleted!!!</div>";
                          window.opener.location.reload(true);
                        alertify.alert(msg,function(){window.close();});
                          alertify.success(msg);
                      </script>
                       <?php
                }else {
                  ?>
                  <script>
                    let msg="<div class='card w3-win8-red'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>error!!! Course Not Deleted!!!</div>";

                     alertify.alert(msg,function(){window.close();});
                     alertify.error(msg);
                 </script>
                  <?php
                }

         }
     ?>
				<?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>
