<style>
    ::-webkit-scrollbar{
          width:10px;
    }
    ::-webkit-scrollbar-track{
          box-shadow: inset 0 0 5px grey;
          border-radius:10px;
    }
    ::-webkit-scrollbar-thumb{
      background:rgba(0,0,0,.3);
          border-radius:10px;
    }
    ::-webkit-scrollbar-thumb:hover{
                background:rgba(0,55,0,.3);
    }
</style>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top  fixed-top" style="background-color:navy;box-shadow:1px 1px 1px #999;">
    <a href="index.php" class="text-warning navbar-brand" style="font-family:Comic Sans MS">
	   <i class="fa fa-laptop"></i> Digital Seva Kendra
	</a>
	<button type="butoon" class="card navbar-toggler" style="background-color:black;color:white" aria-expanded="true" data-toggle="collapse" data-target="#navb">
	   <span class="navbar-toggler-icon">
	</button>

	<div class="navbar-collapse collapse hide" id="navb">
	   <ul class="navbar-nav mr-auto">
		 <li class="nav-item">
			   <a href="superUserMain.php" class="nav-link <?php if($super_user_page_id==1){echo "active";}else{}?>" data-toggle="tooltip" title="Go To Home Page">
			      <i class="fa fa-cogs"></i> Dashboard
			   </a>
		 </li>

       <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle <?php if($super_user_page_id==2){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-user"></i> Student's</a>
			   <div class="dropdown-menu" id="navdrop1">
				     <a href="add student.php" class="dropdown-item <?php if($student_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Student</a>
				     <a href="edit student.php" class="dropdown-item <?php if($student_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Student</a>
				     <a href="view student.php" class="dropdown-item <?php if($student_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View All Student</a>
				     <a href="delete student.php" class="dropdown-item <?php if($student_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete Student</a>
				 </div>
			</li><!--------------->



			<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle <?php if($super_user_page_id==3){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-wrench"></i> Settings</a>
			     <div class="dropdown-menu" id="navdrop1">
				   <a href="change password.php" class="dropdown-item w3-win8-red <?php if($setting1_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-lock"></i> Change Password</a>
            <hr>
           <a href="add session.php" class="dropdown-item bg-dark text-light <?php if($setting1_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-calendar-plus-o"></i> Add Session</a>
           <a href="select current session.php" class="dropdown-item bg-dark text-light <?php if($setting1_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-calendar-check-o"></i> Select Current Session</a>

				 </div>
			</li>

      <li class="nav-item dropdown">
         <a href="#" class="nav-link dropdown-toggle <?php if($super_user_page_id==4){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-graduation-cap"></i> Exam's</a>
        <div class="dropdown-menu" id="navdrop1">
           <a href="add question paper.php" class="dropdown-item <?php if($exam_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Question Paper</a>
           <a href="edit question paper.php" class="dropdown-item <?php if($exam_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Question Paper</a>
           <a href="view question paper.php" class="dropdown-item <?php if($exam_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View Question Paper</a>
           <a href="delete question paper.php" class="dropdown-item <?php if($exam_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete Question Paper</a>
               <hr>
               <a href="add question.php" class="dropdown-item <?php if($exam_page_sub_id==5){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Question</a>
               <a href="edit question.php" class="dropdown-item <?php if($exam_page_sub_id==6){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Question</a>
             <a href="view question.php" class="dropdown-item <?php if($exam_page_sub_id==7){echo "active";}else{}?>"><i class="fa fa-eye"></i> View Question</a>
         </div>
      </li>

      <li class="nav-item dropdown">
         <a href="#" class="nav-link dropdown-toggle <?php if($super_user_page_id==5){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-money"></i> Fee Management</a>
        <div class="dropdown-menu" id="navdrop1">
           <a href="fee received.php" class="dropdown-item <?php if($fee_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-money"></i> Fee Received</a>
           <a href="edit fee.php" class="dropdown-item <?php if($fee_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Fee</a>
           <a href="view fee.php" class="dropdown-item <?php if($fee_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View Fee</a>
           <a href="view fee by student.php" class="dropdown-item <?php if($fee_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-book"></i> Ledger</a>
       </div>
      </li>

      <li class="nav-item">
			   <a href="logout.php" class="nav-link" data-toggle="tooltip" title="Hey!!! Click On me to Logout From Admin Account">
			      <i class="fa fa-sign-out"></i> Logout
			   </a>
		  </li>
      <li class="nav-item">
			   <a href="help.php" class="nav-link" data-toggle="tooltip" title="Hey!!! Click On me to see Help">
			      <i class="fa fa-question-circle"></i> Help
			   </a>
		  </li>
		</ul>
	</div>
</nav>

<?php
#Current session......
include "db.php";
$sql="SELECT current_session FROM current_session";
$result=$conn->query($sql);
  if($row=$result->fetch_assoc()){
     $_SESSION["current_session"]=$row["current_session"];
  }
?>
