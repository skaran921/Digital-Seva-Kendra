<?php
session_start();
$page_id=4;
$thought_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit Thought - Digital Seva Kendra</title>
	<style>
	    .card-body table{
				   background: linear-gradient(45deg,yellow,red,rgb(125,0,255));
					 font-family: cursive;
					 font-weight: 100;
					 font-weight: bold;
					 color:white;
			}

			td{
				   box-shadow:
			}

			td button{
				       box-shadow: 1px 2px 2px #999;
			}
			td:hover{
				background-color: rgba(255,255,255,0.3);
				color:#fff;
				cursor: pointer;
			}
	</style>
  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
       <div class="container">
				 <div class="card" style="box-shadow:4px 4px 4px #666;">
					   <div class="card-header w3-win8-crimson">
					   	     <b><i class="fa fa-edit"></i> Edit Thought</b>
					   </div>
						 <div class="card-body">
               <div style="overflow-x:auto">
								 <center>
                       <input type="search" id="myInput" class="form-control" placeholder="Search......." style="margin-bottom:2px;" data-toggle="tooltip" title="Enter Value On Me For Search Course" autofocus>
								 </center>
							   <table id="courseTable" name="courseTable" class="table table-bordered responsive text-center">
                      <tr class="thead-dark ">
                          <th>Sr. No.</th>
                          <th>Thought</th>
                          <th><i class="fa fa-edit"></i></th>
                      </tr>
											<tbody id="myTable">
												  <?php edit_thought_detail_in_row();?>
											</tbody>

							   </table>
						 </div>
					 </div>
						 <div class="card-footer w3-win8-blue">
						 </div>
				 </div>
			 </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
   function editThought(thought_id)
	 {
		  window.open("edit_thought_confirm.php?thought_id="+thought_id,"_blank");
	 }

	 $(document).ready(function(){
		    $("#myInput").on("keyup",function(){
					let value=$(this).val().toLowerCase();
	 			 $("#myTable tr").filter(function(){
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	 			 });
			});
	 });
</script>
