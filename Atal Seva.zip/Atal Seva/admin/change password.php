<?php 
session_start();
$page_id=2;
$setting_page_sub_id=1;
if(isset($_SESSION["admin_id"]))
{
 	
}
else
{
	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">	
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">	
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg"> 
    <title>Change Password - Digital Seva Kendra</title>		
	<style>
	    button{box-shadow:4px 4px 8px #999;}
	</style>
  </head>
  <body>
 
	   
	   
        <?php
      		include 'headerAdmin.php';			
      		include 'includeFunctionsAdmin.php';			
		?>
		<br>
		<br>
		<br>
<center>		
   <div  style="max-width:400px;" align="left">
       <div class="card">
	     <div class="card-header w3-win8-red">
		    <b><i class="fa fa-lock"></i> Change Password</b>
		 </div>
	     <div class="card-body">
		      <form action="change password.php" method="post" id="changePassForm"  name="changePassForm">
			      <div class="form-group">
				      <label><b><i class="fa fa-unlock"></i> Old Password:<i class="fa fa-asterisk text-danger"></i></b></label>
	<input type="password" name="old_password" id="old_password" class="form-control" placeholder="Old Password" title="Your Current Password Comes Here" data-toggle="tooltip" data-placement="left" required autofocus>
					  <label><b><i class="fa fa-lock"></i> New Password:<i class="fa fa-asterisk text-danger"></i></b></label>
					  <input type="password" name="new_password" id="new_password" class="form-control" placeholder="New Password" title="Your New Password Comes Here" data-toggle="tooltip" data-placement="left" required>

<label><b><i class="fa fa-lock"></i> Confirm Password:<i class="fa fa-asterisk text-danger"></i></b></label>
<input type="password" name="Confirm_password" id="confirm_password" class="form-control" onkeyup="matchPassword()" placeholder="Retype New Password" title="Confirm Your New Password" data-toggle="tooltip" data-placement="left" required autofocus>
					 					  
			<br>
<div id="error" class="card font-weight-bold w3-win8-red" style="display:none;"></div>			
<div id="msg" class="card font-weight-bold w3-win8-green" style="display:none;"></div>			
				
	<center class="m-4">
		 <button type="submit" name="change_password" onclick="validate()" title="Click Me To Change Your Password" data-toggle="tooltip" data-placement="left" class="btn w3-win8-green">
		   <i class="fa fa-check"></i> Change Password
		 </button>
		 
		  <button type="reset" title="Click Me To Reset Form" data-toggle="tooltip" data-placement="right" class="btn w3-win8-red">
		    <i class="fa fa-refresh"></i> Reset
		 </button>
    </center>
				  </div>
			  </form>
		 </div>
		 <div class="card-footer w3-win8-red">
		 </div>
	   </div>
   </div>
</center>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
   
    
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
function matchPassword()
{
  let new_password=document.getElementById("new_password").value;
  let confirm_password=document.getElementById("confirm_password").value;
  if(new_password != confirm_password)
  {
    document.getElementById('error').innerHTML="<center><i class='fa fa-times-circle' style='font-size:50px;'></i> Password Not Same!!!!</center>";
    document.getElementById('error').style.display="block";
    document.getElementById('msg').style.display="none";
	return false;
  }
  else if(new_password.length<1)
  {
	document.getElementById('error').innerHTML="<center><i class='fa fa-warning' style='font-size:50px;'></i> Please Enter New Password !!!!</center>";
    document.getElementById('error').style.display="block";
    document.getElementById('msg').style.display="none";  
  }
  else
  {
	document.getElementById('msg').innerHTML="<center><i class='fa fa-check-circle' style='font-size:50px;'></i> Password Matched!!!!</center>";
    document.getElementById('error').style.display="none";
    document.getElementById('msg').style.display="block";
	return false;
  }
}

</script>

<script>
function validate()
{
	let old_password=document.getElementById('old_password').value;	
    let new_password=document.getElementById("new_password").value;
	let confirm_password=document.getElementById("confirm_password").value;
	let msg1="<div class='card font-weight-bold text-dark'><center><i class='fa fa-times-circle text-danger' style='font-size:50px;'></i></center>Please Enter Your Old Password!!!!</div>";
	let msg2="<div class='card font-weight-bold text-dark'><center><i class='fa fa-times-circle text-danger' style='font-size:50px;'></i></center>Please Enter New Password!!!!</div>";
	let msg3="<div class='card font-weight-bold text-dark'><center><i class='fa fa-times-circle text-danger' style='font-size:50px;'></i></center>Please Enter Confirm Password!!!!</div>";
    
	if(old_password.length<1)
	{
		alertify.alert(msg1);
		alertify.error(msg1);
		return false;
	}
	else if(new_password.length<1)
	{
		alertify.alert(msg2);
		alertify.error(msg2);
		return false;
	}
	else if(new_password != confirm_password)
    {
     document.getElementById('error').innerHTML="<center><i class='fa fa-times-circle' style='font-size:50px;'></i> Password Not Same!!!!</center>";
     document.getElementById('error').style.display="block";
     document.getElementById('msg').style.display="none";
	 return false;
    } 
   else if(new_password === confirm_password)
   {
	 document.getElementById('msg').innerHTML="<center><i class='fa fa-check-circle' style='font-size:50px;'></i> Password Matched!!!!</center>";
     document.getElementById('error').style.display="none";
     document.getElementById('msg').style.display="block";
	 return false;
   }      
}
</script>


<?php
    if(isset($_POST["change_password"]))
	{
		$old_password=$_POST["old_password"];
		$new_password=$_POST["new_password"];
		$admin_id=$_SESSION['admin_id'];
		include 'db.php';
		$sql1="SELECT * FROM admin WHERE id='$admin_id' AND password='$old_password'";
		$result1=$conn->query($sql1);
	     	if($row1=$result1->fetch_assoc())
			{
				$sql2="UPDATE admin SET password='$new_password' WHERE id='$admin_id'";
				$result2=$conn->query($sql2);
				if($result2==TRUE)
				{
					?>
				<script>
let msg="<div class='card font-weight-bold text-light bg-success p-4'><center><i class='fa fa-check-circle text-light' style='font-size:50px;'></i></center>Old Password Changed!!!</div>";
    			    alertify.alert(msg);
		            alertify.success(msg);
				</script>
				<?php 
				}
				else
				{
				?>
				<script>
let msg="<div class='card font-weight-bold text-light bg-danger p-4'><center><i class='fa fa-times-circle text-light' style='font-size:50px;'></i></center>error!!! Password Not Changed!!!</div>";
    			    alertify.alert(msg);
		            alertify.error(msg);
				</script>
				<?php 	
				}
			}
			else
			{
				?>
				<script>
let msg="<div class='card font-weight-bold text-light bg-danger p-4'><center><i class='fa fa-times-circle text-light' style='font-size:50px;'></i></center>Old Password Not Matched!!!<br> Please Enter Valid Password!!!</div>";
    			    alertify.alert(msg);
		            alertify.error(msg);
				</script>
				<?php 
			}
	}
?>