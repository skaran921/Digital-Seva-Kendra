<?php
session_start();
$page_id=5;
$news_page_sub_id=3;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>View News And Update - Digital Seva Kendra</title>
    <style media="screen">
         td{
             box-shadow: 2px 2px 2px 2px #f9f9f9;
         }
    </style>
  </head>
  <body class="text-dark">
    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
          <div class="container">
              <div class="card">
                 <div class="card-header" style="background:linear-gradient(45deg,purple,red,indigo);color:#fff;">
                     <b> <i class="fa fa-eye"></i> View News And Update</b>
                 </div>
                 <div class="card-body">
                      <div class="table-responsive table-bordered">
                        <center>
                              <input type="search" id="myInput" class="form-control" placeholder="Search......." style="margin-bottom:2px;" data-toggle="tooltip" title="Enter Value On Me For Search News And Update" autofocus>
                        </center>
                        <table class="table table-striped" id="myTable">
                                    <tr class="thead-dark" align="center">
                                        <th>Sr. No.</th>
                                        <th>News & Update</th>
                                        <th>Added By</i></th>
                                        <th>Added On</i></th>
                                        <th>Added On</i></th>
                                    </tr>
                                    <?php
                                        viewNewsForUpdateTable();
                                    ?>
                        </table>
                      </div>
                 </div>
                 <div class="card-footer" style="background:linear-gradient(45deg,indigo,purple,indigo);color:#fff;">
                 </div>
              </div>

          </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
<script>
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});

    $(document).ready(function(){
        $("#myInput").on("keyup",function(){
              let value=$(this).val().toLowerCase();
              $("#myTable tr").filter(function(){
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
              });
        });
    });
</script>
  </body>
</html>
