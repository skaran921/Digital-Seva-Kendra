<?php
session_start();
$super_user_page_id=4;
$exam_page_sub_id=6;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>View Question - Digital Seva Kendra</title>
    <style>
        #main-card{
              background: linear-gradient(-45deg,mediumslateblue,cyan,darkmagenta,#ff0095);
              color:#fff;
              border-radius: 10px;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        #card-icon{
             position: relative;
             font-size: 100px;
             line-height: 80px;
             top:-60px;
             background: linear-gradient(-45deg,mediumslateblue,cyan,darkmagenta,#ff0095);
             padding: 16px;
             border-radius: 50%;
             box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        h4{
           position: relative;
           top:-60px;
        }

        .btn{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background: linear-gradient(-45deg,magenta,cyan);
              margin-top:4px;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }
        .btn:hover{
                 transition: 2s;
                 background: green;
        }

        .btn1{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background: linear-gradient(-45deg,orange,red,#ff0095);
              margin-top:4px;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }
        .btn1:hover{
                 transition: 2s;
                 background: red;
        }

        #tableDiv{
           position: relative;
           box-shadow: 0 10px 10px rgba(0,0,0,0.3);
           padding:20px;
           top:-50px;
           overflow-x:auto;
        }
        table{
            width:100%;
            text-align: center;
            font-weight: bold;
        }
        thead{
             background:mediumblue;
             font-size: 18px;
             font-family: cursive;
             line-height: 30px;
        }
        tr{
            box-shadow: 0 10px 10px rgba(0,0,0,0.3);
            padding: 4px;
        }
        tbody tr:nth-child(odd){
             background:whitesmoke;
             color:#000;
        }

        tbody tr:nth-child(even){
             background: #e9e9e9;
             color:#000;
        }
        td{
          padding:4px;
        }

    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
           <div class="container-fluid mb-4">
                <div class="card" id="main-card">
                    <div class="card-body">
                      <center>
                           <i class="fa fa-question-circle" id="card-icon"></i><br>
                            <h4><i class="fa fa-eye"></i> View Question</h4>
                      </center>

                          <div id="tableDiv">
                                 <input type="search" id="myInput" placeholder="Search Question..." class="form-control" autofocus>
                                 <table>
                                     <thead>
                                        <tr>
                                               <th>Sr. No.</th>
                                               <th>Question Paper</th>
                                               <th>Question</th>
                                               <th>Option1</th>
                                               <th>Option2</th>
                                               <th>Option3</th>
                                               <th>Option4</th>
                                               <th>Answer</th>
                                               <th>Added On</th>
                                               <th>Updated On</th>

                                        </tr>
                                     </thead>
                                     <tbody id="myTable">
                                      <?php getQuestionsDetailForView();?>
                                     </tbody>
                                 </table>
                          </div>

                    </div>
                  </div>
           </div>


    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>
