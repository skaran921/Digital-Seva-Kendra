<?php
session_start();
$page_id=7;
$download_page_sub_id=1;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Add in Download - Digital Seva Kendra</title>
	<style>
	</style>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
          <div class="container">
              <div class="card">
                 <div class="card-header" style="background:linear-gradient(45deg,purple,black);color:#fff;">
                     <b> <i class="fa fa-plus"></i> Add in Download <i class="fa fa-download"></i></b>
                 </div>
                 <div class="card-body" style="background:linear-gradient(45deg,#ff0099,blue,#ff0099);color:#fff">
                   <p>
                      <b><mark>Note:-</mark><br></b>
                     <i class="fa fa-hand-o-right"></i> <b> Press <kbd>Alt+A</kbd> For Add Download</b><br>
                     <i class="fa fa-hand-o-right"></i> <b> Press <kbd>Alt+R</kbd> For Reset Form</b>
                   </p>
                         <form action="add download.php" method="post" id="addInDownload" enctype="multipart/form-data">
                             <div class="form-group">
                                <label><b>Select Download Group:<i class="fa fa-asterisk text-danger"></i></b></label>
                                <select class="form-control" name="downloadGroup" id="downloadGroup" tabindex="1" data-toggle="tooltip" title="Select A Download Group" required autofocus style="max-width:400px;">
                                       <option value="">Select A Download Group</option>
                                       <option>Basic Computer Notes</option>
                                       <option>PDF E-Books</option>
                                       <option>Other Course Notes</option>

                                </select>
                                <label><b>Title OF File:<i class="fa fa-asterisk text-danger"></i></b></label>
                                 <input type="text" name="title" id="title" class="form-control" placeholder="Write Title OF PDF File eg. Typing Notes, Html Notes etc." data-toggle="tooltip" title="This Title Show To User/Student as a File Name" required>
                               <label><i class="fa fa-file-pdf-o"></i><b> Select PDF File:<i class="fa fa-asterisk text-danger"></i> </b></label>
                                  <input type="file" name="downloadFile" id="downloadFile" class="form-control" tabindex="2" accept="application/pdf">
                            </div>
                             <center>
                                   <button type="button" class="btn btn-success" name="add" accesskey="A" onclick="validate()"><i class="fa fa-check-circle"></i> Add Download</button>
                                   <button type="reset" accesskey="R" class="btn btn-danger"><i class="fa fa-refresh"></i> Reset Form</button>
                             </center>
                         </form>
                 </div>
                 <div class="card-footer" style="background:linear-gradient(45deg,purple,black);color:#fff;">
                 </div>
              </div>

          </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
   function validate(){
     let downloadGroup=document.getElementById('downloadGroup').value;
     let title=document.getElementById('title').value;
     let downloadFile=document.getElementById('downloadFile').value;
     if(downloadGroup.length<=1){
            let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center> Please Select Download Group!!!</div>";
            alertify.alert(msg);
            alertify.error(msg);
     }else if(title.length<=1){
            let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center> Please Enter Title OF PDF File!!!</div>";
            alertify.alert(msg);
            alertify.error(msg);
     }else if(downloadFile.length<=1){
            let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center> Please Select A PDF File!!!</div>";
            alertify.alert(msg);
            alertify.error(msg);
     }else{
             document.getElementById("addInDownload").submit();
     }
   }
</script>
 <?php
    if((isset($_POST["downloadGroup"])) && (isset($_POST["title"])) && (isset($_FILES["downloadFile"]))){
          include "db.php";
          $downloadGroup=$_POST["downloadGroup"];
          $title=$_POST["title"];
          $downloadFile=basename($_FILES["downloadFile"]["name"]);
          $fileName=$downloadGroup.$title.$downloadFile;
          $fileSize=round($_FILES["downloadFile"]["size"]);
          $admin_id=$_SESSION["admin_id"];
          $target_dir="download/";
          $target_file=$target_dir.$fileName;
          $sql1="SELECT * FROM download WHERE fileName='$fileName'";
          $result1=$conn->query($sql1);
          if($row1=$result1->fetch_assoc()){
                     ?>
                    <script>
                       let msg="<div class='card text-primary font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:200px;'></i></center> Sorry!!!... File Already Exist!!!</div>";
                       alertify.alert(msg);
                       alertify.error(msg);
                    </script>
                     <?php
          }else{
                 if(move_uploaded_file($_FILES["downloadFile"]["tmp_name"],$target_file)){
                          $sql="INSERT INTO download(downloadGroup,title,fileName,fileSize,admin)VALUES('$downloadGroup','$title','$fileName','$fileSize','$admin_id')";
                          $result=$conn->query($sql);
                          if($result==TRUE){
                            ?>
                           <script>
                              let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:200px;'></i></center> File Saved!!!</div>";
                              alertify.alert(msg);
                              alertify.error(msg);
                           </script>
                            <?php

                          }else {
                            ?>
                           <script>
                              let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:200px;'></i></center>error!!!...Sorry!!!... File Not Save!!!</div>";
                              alertify.alert(msg);
                              alertify.error(msg);
                           </script>
                            <?php
                          }
                 }
                 else{
                   ?>
                  <script>
                     let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:200px;'></i></center> Sorry!!!... File Not Uploaded!!!</div>";
                     alertify.alert(msg);
                     alertify.error(msg);
                  </script>
                   <?php
                 }
          }


    }
  ?>
