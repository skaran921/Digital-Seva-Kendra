<?php
session_start();
$super_user_page_id=3;
$setting1_page_sub_id=3;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Select Current Session- Digital Seva Kendra</title>
    <style>
        tr:nth-child(odd){
          font-family: cursive;
          background-color:whitesmoke;
          box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        tr:nth-child(even){
          font-family: cursive;
          background-color:snow;
          box-shadow: 0 7px 8px rgba(0,0,0,0.3);
        }

        #card-icon{
                font-size:50px;
                position: relative;
                width: 100px;
                height: 100px;
                line-height: 100px;
                color:#fff;
                background:linear-gradient(-45deg,#ffec61,red,blue);
                box-shadow: 0 10px 10px rgba(0,0,0,0.3);
                border-radius: 50%;
                top:-60px;
        }
        #main-card{
              background:linear-gradient(-45deg,#ffec61,red,blue);
        }
        #table{
            position: relative;
            top:-50px;
        }
    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>

<?php
   if(isset($_GET["session"])){
       $session=$_GET["session"];
       include "db.php";
       $sql="UPDATE current_session SET current_session='$session'";
       $result=$conn->query($sql);
       if($result==TRUE){
              ?>
                <script>
                    let msg="<div class='card font-weight-bold text-success'><center><i class='fa fa-check-circle' style='font-size:100px;'></i><br> Session <?php echo $session;?> Selected!!!</center></div>";
                    alertify.alert(msg,function(){window.close();});
                    alertify.log(msg);
                </script>
              <?php
       }else {
             ?>
             <script>
                 let msg="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-size:100px;'></i><br> error Session Not Selected!!!</center></div>";
                 alertify.alert(msg,function(){window.close();});
                 alertify.log(msg);
             </script>
             <?php
       }
   }
 ?>
