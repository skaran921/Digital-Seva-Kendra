<?php
session_start();
$page_id=5;
$news_page_sub_id=2;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Edit News And Update - Digital Seva Kendra</title>
	<style>
	</style>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
<?php
if(isset($_GET["news_id"])){
     include 'db.php';
     $news_id=$_GET["news_id"];
     $sql="SELECT * FROM news WHERE id='$news_id'";
     $result=$conn->query($sql);
     if($row=$result->fetch_assoc()){
          ?>
          <div class="container">
                <div class="card">
                   <div class="card-header" style="background:linear-gradient(45deg,indigo,purple,indigo);color:#fff;">
                       <b> <i class="fa fa-edit"></i> Edit News And Update</b>
                   </div>
                   <div class="card-body" style="background:linear-gradient(45deg,purple,#fff,white,indigo,purple)">
                           <form action="editNewsConfirm.php" method="post" id="editNewsAndUpdate">
                                <input type="hidden" name="news_id" id="news_id" value="<?php echo $row["id"] ?>">
                               <div class="form-group">
                                 <label><i class="fa fa-newspaper-o"></i><b> Today News And Update:<i class="fa fa-asterisk text-danger"></i> </b></label>
                              <textarea name="news" id="news" placeholder="" class="form-control" required style="display:none;"></textarea>
                                <div class="container text-center">
                                      <ul class="list-inline">
                                        <li class="list-inline-item">
                                             <button type="button" class='card btn' onclick="textBold()"><i class="fa fa-bold"></i></button>
                                        </li>
                                        <li class="list-inline-item">
                                             <button type="button" class='card btn' onclick="textItalic()"><i class="fa fa-italic"></i></button>
                                        </li>
                                        <li class="list-inline-item">
                                             <button type="button" class='card btn'onclick="textUnderline()"><i class="fa fa-underline"></i></button>
                                        </li>
                                        <li class="list-inline-item">
                                             <button type="button" class='card btn' onclick="textUorederedList()"><i class="fa fa-list-ul"></i></button>
                                        </li>

                                        <li class="list-inline-item">
                                             <button type="button" class='card btn' onclick="textOrederedList()"><i class="fa fa-list-ol"></i></button>
                                        </li>

                                        <li class="list-inline-item">
                                             <button type="button" class='card btn' onclick="textLink()"><i class="fa fa-link"></i></button>
                                        </li>
                                      </ul>
                                </div><center>
                                <iframe class="Form-control" name="editor" style="max-width:90%;box-shadow:4px 8px 8px #666;border-radius:12px;" accesskey="s" tabindex="5"></iframe>
                                           <script>
                                              window.frames["editor"].document.body.innerHTML="<?php echo addslashes($row["news"]);?>";
                                           </script>
                               </div>
                               <center>
                                     <button type="button" class="btn btn-primary" name="add" onclick="validate()"><i class="fa fa-check-circle"></i> Update</button>
                                     <button type="reset" class="btn btn-danger" onclick="resetForm()"><i class="fa fa-refresh"></i> Reset</button>
                               </center>
                           </form>
                   </div>
                   <div class="card-footer" style="background:linear-gradient(45deg,indigo,purple,indigo);color:#fff;">
                   </div>
                </div>
            </div><!---container--->
          <?php
     }
}

?>

        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
  editor.document.designMode="on";
  function validate(){
    document.getElementById('news').value=window.frames['editor'].document.body.innerHTML;
    let news=document.getElementById("news").value;
    if(news.length<=1){
          alertify.alert("<div class='card'><b><center><i class='fa fa-times-circle text-danger' style='font-size:100px;'></i></center>Please Enter Some News And Update In Box!!!</b></div>");
    }
    else {
               document.getElementById("editNewsAndUpdate").submit();
    }
  }
//validate() end;

function resetForm(){
   window.frames["editor"].document.body.innerHTML="";
}
</script>

<?php
  if((isset($_POST["news"])) && isset($_POST["news_id"])){
     include "db.php";
     $news=$_POST["news"];
     $news_id=$_POST["news_id"];
     $admin_id=$_SESSION["admin_id"];
     $sql="UPDATE news SET news='$news',admin='$admin_id' WHERE id='$news_id'";
     $result=$conn->query($sql);
     if($result==TRUE){
       ?>
       <script>
          window.opener.location.reload(true);
          let msg="<div class='card'><b><center><i class='fa fa-check-circle text-success' style='font-size:100px;'></i></center>News Updated!!!</div>";
          alertify.alert(msg,function(){window.close();});
        </script>
        <?php
     }
     else{
       ?>
       <script>
          let msg="<div class='card'><b><center><i class='fa fa-times-circle text-danger' style='font-size:100px;'></i></center>error!!!...News Not Updated!!!</div>";
          alertify.alert(msg);
        </script>
        <?php
     }
  }
?>
