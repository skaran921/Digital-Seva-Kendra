<style>
    ::-webkit-scrollbar{
          width:10px;
    }
    ::-webkit-scrollbar-track{
          box-shadow: inset 0 0 5px grey;
          border-radius:10px;
    }
    ::-webkit-scrollbar-thumb{
      background:rgba(0,0,0,.3);
          border-radius:10px;
    }
    ::-webkit-scrollbar-thumb:hover{
                background:rgba(0,55,0,.3);
    }
</style>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top  fixed-top" style="background-color:black;box-shadow:1px 1px 1px #999;">
    <a href="index.php" class="text-warning navbar-brand" style="font-family:Comic Sans MS">
	   <i class="fa fa-laptop"></i> Digital Seva Kendra
	</a>
	<button type="butoon" class="card navbar-toggler" style="background-color:black;color:white" aria-expanded="true" data-toggle="collapse" data-target="#navb">
	   <span class="navbar-toggler-icon">
	</button>

	<div class="navbar-collapse collapse hide" id="navb">
	   <ul class="navbar-nav mr-auto">
		 <li class="nav-item">
			   <a href="index.php" class="nav-link <?php if($page_id==1){echo "active";}else{}?>" data-toggle="tooltip" title="Go To Home Page">
			      <i class="fa fa-cogs"></i> Dashboard
			   </a>
		 </li>

       <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle <?php if($page_id==3){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-book"></i> Course</a>
			   <div class="dropdown-menu" id="navdrop1">
				     <a href="add course.php" class="dropdown-item <?php if($course_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Course</a>
				     <a href="edit course.php" class="dropdown-item <?php if($course_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Course</a>
				     <a href="view course.php" class="dropdown-item <?php if($course_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View All Course</a>
				     <a href="delete course.php" class="dropdown-item <?php if($course_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete Course</a>
				 </div>
			</li><!--------------->

      <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle <?php if($page_id==4){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-lightbulb-o"></i> Thought</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="add thought.php" class="dropdown-item <?php if($thought_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Thought</a>
				     <a href="edit thought.php" class="dropdown-item <?php if($thought_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Thought</a>
				     <a href="view thought.php" class="dropdown-item <?php if($thought_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View All Thought</a>
				     <a href="delete thought.php" class="dropdown-item <?php if($thought_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-trash text-danger"></i> Delete Thought</a>
				     <a href="today thought.php" class="dropdown-item <?php if($thought_page_sub_id==5){echo "active";}else{}?>"><i class="fa fa-check-circle text-success"></i> Select Today Thought</a>
				        <hr>
				 </div>
			</li><!------------------>

      <li class="nav-item dropdown" >
			   <a href="#" class="nav-link dropdown-toggle <?php if($page_id==5){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-list-alt"></i> Notification</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="addNewsAndUpdate.php" class="dropdown-item <?php if($news_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add News And Update</a>
				     <a href="editNewsAndUpdate.php" class="dropdown-item <?php if($news_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit News And Update</a>
				     <a href="viewNewsAndUpdate.php" class="dropdown-item <?php if($news_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-eye"></i> View News And Update</a>
				     <a href="deleteNewsAndUpdate.php" class="dropdown-item <?php if($news_page_sub_id==4){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete News And Update</a>
              <hr class="w3-win8-teal">
              <a href="addJobNotification.php" class="dropdown-item <?php if($news_page_sub_id==5){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Job Notification</a>
              <a href="editJobNotification.php" class="dropdown-item <?php if($news_page_sub_id==6){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit Job Notification</a>
              <a href="viewJobNotification.php" class="dropdown-item <?php if($news_page_sub_id==7){echo "active";}else{}?>"><i class="fa fa-eye"></i> View All Job Notification</a>
              <a href="deleteJobNotification.php" class="dropdown-item <?php if($news_page_sub_id==8){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete Job Notification</a>
                   <hr class="w3-win8-indigo">
              <a href="addGeneralNotification.php" class="dropdown-item <?php if($news_page_sub_id==9){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add General Notification</a>
              <a href="editGeneralNotification.php" class="dropdown-item <?php if($news_page_sub_id==10){echo "active";}else{}?>"><i class="fa fa-edit"></i> Edit General Notification</a>
              <a href="viewGeneralNotification.php" class="dropdown-item <?php if($news_page_sub_id==11){echo "active";}else{}?>"><i class="fa fa-eye"></i> View All General Notification</a>
              <a href="deleteGeneralNotification.php" class="dropdown-item <?php if($news_page_sub_id==12){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete General Notification</a>
               <div class="bg-dark" style="border-radius:20px;">&nbsp;</div>
         </div>
			</li><!------------------>

			<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle <?php if($page_id==2){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-wrench"></i> Settings</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="change password.php" class="dropdown-item w3-win8-red <?php if($setting_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-lock"></i> Change Password</a>
             <hr>
				     <a href="addJobGroup.php" class="dropdown-item w3-win8-green <?php if($setting_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-plus"></i> Add Job Notification Group</a>
				     <a href="deleteJobGroup.php" class="dropdown-item w3-win8-green <?php if($setting_page_sub_id==3){echo "active";}else{}?>"><i class="fa fa-trash"></i> Delete Job Notification Group</a>
				        <hr>
				 </div>
			</li>

      <li class="nav-item dropdown">
         <a href="#" class="nav-link dropdown-toggle <?php if($page_id==6){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-envelope"></i> Contact <span class="badge badge-danger"><?php echo  newMessagesForHeader();?></span></a>
           <div class="dropdown-menu" id="navdrop1">
             <a href="inbox.php" class="dropdown-item w3-win8-red <?php if($contact_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-envelope-square"></i> inbox <span class="badge badge-success"><?php echo  newMessagesForHeader();?></span></a>
         </div>
      </li>

      <li class="nav-item dropdown">
         <a href="#" class="nav-link dropdown-toggle <?php if($page_id==7){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-download"></i> Download</a>
           <div class="dropdown-menu" id="navdrop1">
             <a href="add download.php" class="dropdown-item w3-win8-teal <?php if($download_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-plus"></i>  Add Download</a>
             <a href="delete download.php" class="dropdown-item w3-win8-teal <?php if($download_page_sub_id==2){echo "active";}else{}?>"><i class="fa fa-trash"></i>  Delete Download</a>
         </div>
      </li>

      <li class="nav-item dropdown">
         <a href="#" class="nav-link dropdown-toggle <?php if($page_id==8){echo "active";}else{}?>" data-toggle="dropdown"><i class="fa fa-mortar-board"></i> Admission <span class="badge badge-danger"><?php echo  newAdmissionForHeader();?></span></a>
           <div class="dropdown-menu" id="navdrop1">
             <a href="viewAdmission.php" class="dropdown-item w3-win8-indigo <?php if($admission_page_sub_id==1){echo "active";}else{}?>"><i class="fa fa-eye"></i>  View Application For Admission <span class="badge badge-danger"> <?php echo  newAdmissionForHeader();?></span></a>
           </div>
      </li>

           <li class="nav-item">
			   <a href="logout.php" class="nav-link" data-toggle="tooltip" title="Hey!!! Click On me to Logout From Admin Account">
			      <i class="fa fa-sign-out"></i> Logout
			   </a>
		  </li>
		</ul>
	</div>
</nav>

<?php
#newMessages
function newMessagesForHeader(){
 include 'db.php';
 $sql="SELECT count(*) as total_message FROM contact WHERE status=0";
 $result=$conn->query($sql);
 if($row=$result->fetch_assoc())
 {
   return $row['total_message'];
 }
}
#newMessages end;

#newAdmission
function newAdmissionForHeader(){
	include 'db.php';
	$sql="SELECT count(*) as total_admission FROM admission WHERE status=0";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_admission'];
	}
}
#newAdmission end;
?>
