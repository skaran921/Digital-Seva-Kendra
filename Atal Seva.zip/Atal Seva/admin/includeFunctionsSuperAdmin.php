<?php
#get_admin_name
function get_admin_name($admin_id)
{
	include 'db.php';
    $sql="SELECT name FROM admin WHERE id='$admin_id'";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
	    return $row['name'];
	}
}

#total visitors
function total_visitors()
{
   include 'db.php';
   $sql="SELECT total_visitors FROM visitor_counter";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return $row['total_visitors'];
   }
}

#getCourseName
function getCourseName($courseId){
	     include "db.php";
			 $sql="SELECT title FROM course WHERE id='$courseId'";
			 $result=$conn->query($sql);
			 if($row=$result->fetch_assoc()){
            return $row["title"];
			 }else{
				 echo "error".$courseId;
			 }
}
#getCourseName end;

#getSession
function getSession($sessionId){
	     include "db.php";
			 $sql="SELECT * FROM session WHERE id='$sessionId'";
			 $result=$conn->query($sql);
			 if($row=$result->fetch_assoc()){
            return $row["session"];
			 }else{
				 echo "error".$sessionId;
			 }
}
#getSession end;

#getSession
function getSessionById($session){
	     include "db.php";
			 $sql="SELECT id FROM session WHERE session='$session'";
			 $result=$conn->query($sql);
			 if($row=$result->fetch_assoc()){
            return $row["id"];
			 }else{
				 echo "error".$session;
			 }
}
#getSession end;

#getEditStudentInfo
function getEditStudentInfo(){
	 include "db.php";
	 $current_session_selectedId=current_session_selected_id($_SESSION["current_session"]);
	 $sql="SELECT * FROM student WHERE session='$current_session_selectedId' ORDER By id DESC";
	 $result=$conn->query($sql);
	 $sr=1;
	 while($row=$result->fetch_assoc()){
		    ?>
				<tr align="center">
				   <td><?php echo $sr; ?></td>
				   <td><img src="students/<?php echo $row['session']."/".$row['course']."/".$row['image'];?>" class="img-fluid img-circle" style="max-width:70px;max-height: 70px;border-radius:50%;"></td>
				   <td><?php echo $row["name"]; ?></td>
				   <td><?php echo $row["fname"]; ?></td>
				   <td><?php echo date("d-m-y",strtotime($row["dob"])); ?></td>
				   <td><?php echo $row["gender"]; ?></td>
				   <td><?php echo $row["course"]; ?></td>
				   <td><?php echo getSession($row["session"]); ?></td>
					 <td>
						    <button type="button" class="btn bg-info text-light" onclick='window.open("editStudentConfirm.php?studentId="+<?php echo $row["id"];?>,"_blank")' data-toggle="tooltip" title="Click On Me To Edit This Student Info">
                                <i class="fa fa-edit"></i> Edit
								</button>
					 </td>
				 </tr>
				<?php
				$sr++;
	 }
}
#getEditStudentInfo end;

#getStudentInfo
function getStudentInfo(){
	include "db.php";
	$current_session_selectedId=current_session_selected_id($_SESSION["current_session"]);
 $sql="SELECT * FROM student WHERE session='$current_session_selectedId' ORDER By id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while($row=$result->fetch_assoc()){
			?>
			<tr align="center">
				 <td><?php echo $sr; ?></td>
				 <td><img src="students/<?php echo $row['session']."/".$row['course']."/".$row['image'];?>" class="img-fluid img-circle" style="max-width:70px;max-height: 70px;border-radius:50%;"></td>
				 <td><?php echo $row["name"]; ?></td>
				 <td><?php echo $row["fname"]; ?></td>
				 <td><?php echo date("d-m-y",strtotime($row["dob"])); ?></td>
				 <td><?php echo $row["gender"]; ?></td>
				 <td><?php echo $row["course"]; ?></td>
				 <td><?php echo getSession($row["session"]); ?></td>
				 <td>
							<button type="button" class="btn w3-win8-green" onclick='window.open("viewStudentConfirm.php?studentId="+<?php echo $row["id"];?>,"_blank")' data-toggle="tooltip" title="Click On Me To View This Student Info">
															 <i class="fa fa-eye"></i> View
							</button>
				 </td>
			 </tr>
			<?php
			$sr++;
 }
}
#getStudentInfo end;

#getDeleteStudentInfo
function getDeleteStudentInfo(){
	include "db.php";
	$current_session_selectedId=current_session_selected_id($_SESSION["current_session"]);
 $sql="SELECT * FROM student WHERE session='$current_session_selectedId' ORDER By id DESC";
	$result=$conn->query($sql);
	$sr=1;
	while($row=$result->fetch_assoc()){
			?>
			<tr align="center">
				 <td><?php echo $sr; ?></td>
				 <td><img src="students/<?php echo $row['session']."/".$row['course']."/".$row['image'];?>" class="img-fluid img-circle" style="max-width:70px;max-height: 70px;border-radius:50%;"></td>
				 <td><?php echo $row["name"]; ?></td>
				 <td><?php echo $row["fname"]; ?></td>
				 <td><?php echo date("d-m-y",strtotime($row["dob"])); ?></td>
				 <td><?php echo $row["gender"]; ?></td>
				 <td><?php echo $row["course"]; ?></td>
				 <td><?php echo getSession($row["session"]); ?></td>
				 <td>
							<button type="button" class="btn w3-win8-red" onclick='window.open("deleteStudentConfirm.php?studentId="+<?php echo $row["id"];?>,"_blank")' data-toggle="tooltip" title="Click On Me To Delete This Student Info">
															 <i class="fa fa-trash"></i> Delete
							</button>
				 </td>
			 </tr>
			<?php
			$sr++;
	}
}
#getDeleteStudentInfo end;

#getSessionInfo
 function getSessionInfo(){
	 include "db.php";
	 $sql="SELECT * FROM session ORDER By id DESC";
	 $result=$conn->query($sql);
	 $sr=1;
	 while($row=$result->fetch_assoc()){
			 ?>
			 <tr align="center">
					<td><?php echo $sr; ?></td>
					<td><?php echo $row["session"]; ?></td>
					<td><?php echo date("d-m-y",strtotime($row["c_id"])); ?></td>
					<td>
							 <button type="button" class="btn w3-win8-teal" onclick='window.open("selectSessionConfirm.php?session=<?php echo $row["session"];?>","_blank")' data-toggle="tooltip" title="Click On Me To Select This Session">
																<i class="fa fa-calendar-check-o"></i> Select Me
							 </button>
					</td>
				</tr>
			 <?php
			 $sr++;
	 }
 }
#getSessionInfo end;

#current_session_selected_id
$current_session_selected=$_SESSION["current_session"];
function current_session_selected_id($current_session_selected){
     include "db.php";
		 $sql="SELECT id FROM session WHERE session='$current_session_selected'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc()){
			    return $row["id"];
		 }
}
#current_session_selected_id end;

#getQuestionPaperDetailForEdit
function getQuestionPaperDetailForEdit(){
	include "db.php";
 $sql="SELECT * FROM questionPaper ORDER By u_id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while($row=$result->fetch_assoc()){
		 ?>
		 <tr align="center">
				<td><?php echo $sr; ?></td>
				<td><?php echo $row["title"]; ?></td>
				<td><?php echo $row["totalQuestions"]; ?></td>
				<td><?php echo $row["totalMarks"]; ?></td>
				<td><?php echo $row["totalTime"]; ?></td>
				<td>
						 <button type="button" class="btn" onclick='window.open("editQuestionPaperConfirm.php?questionPaperId=<?php echo $row["id"];?>","_blank")' data-toggle="tooltip" title="Click On Me To Edit This Question Paper">
															<i class="fa fa-edit"></i> Edit
						 </button>
				</td>
			</tr>
		 <?php
		 $sr++;
 }
}
#getQuestionPaperDetailForEdit end;

#getQuestionPaperDetailForView
function getQuestionPaperDetailForView(){
	include "db.php";
 $sql="SELECT * FROM questionPaper ORDER By u_id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while($row=$result->fetch_assoc()){
		 ?>
		 <tr align="center">
				<td><?php echo $sr; ?></td>
				<td><?php echo $row["title"]; ?></td>
				<td><?php echo $row["totalQuestions"]; ?></td>
				<td><?php echo $row["totalMarks"]; ?></td>
				<td><?php echo $row["totalTime"]; ?></td>
				<td><?php echo $row["marksPerQuestion"]; ?></td>
				<td><?php echo date("d-m-y",strtotime($row["c_id"])); ?></td>
				<td><?php echo date("d-m-y",strtotime($row["u_id"])); ?></td>
			</tr>
		 <?php
		 $sr++;
 }
}
#getQuestionPaperDetailForView end;

#getQuestionPaperDetailForDelete
function getQuestionPaperDetailForDelete(){
	include "db.php";
 $sql="SELECT * FROM questionPaper ORDER By u_id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while($row=$result->fetch_assoc()){
		 ?>
		 <tr align="center">
				<td><?php echo $sr; ?></td>
				<td><?php echo $row["title"]; ?></td>
				<td><?php echo $row["totalQuestions"]; ?></td>
				<td><?php echo $row["totalMarks"]; ?></td>
				<td><?php echo $row["totalTime"]; ?></td>
				<td>
						 <button type="button" class="btn" onclick='deleteQuestionPaper(<?php echo $row["id"];?>)' data-toggle="tooltip" title="Click On Me To Edit This Question Paper">
															<i class="fa fa-trash"></i> Delete
						 </button>
				</td>
			</tr>
		 <?php
		 $sr++;
 }
}
#getQuestionPaperDetailForDelete end;

#getQuestionPaperNameById
function getQuestionPaperNameById($questionPaperId){
    include "db.php";
		$sql="SELECT title FROM questionPaper WHERE id='$questionPaperId'";
		$result=$conn->query($sql);
		if($row=$result->fetch_assoc()){
            return $row["title"];
		}else{
			  return "error";
		}
}
#getQuestionPaperNameById end;

#getQuestionPaperDetail
function getQuestionPaperDetail(){
	    include "db.php";
      $sql="SELECT * FROM questionPaper ORDER BY u_id DESC";
			$result=$conn->query($sql);
			$sr=1;
			while($row=$result->fetch_assoc()){
						?>
					<tr>
						 <td><?php echo $sr;?></td>
						 <td><?php echo $row["title"];?></td>
						 <td><?php echo $row["totalQuestions"];?></td>
						 <td><?php echo $row["totalMarks"];?></td>
						 <td><?php echo $row["marksPerQuestion"];?></td>
						 <td>
             <button type="button"class="btn" onclick='window.open("editQuestion1.php?questionPaperId=<?php echo $row["id"];?>","_blank")' data-toggle="tooltip" title="Click On Me To Edit Question OF This Question Paper">
							     <i class="fa fa-edit"></i> Edit
						</button>
						 </td>
					</tr>
						<?php
			}
}
#getQuestionPaperDetail end;

#getQuestionsDetail
function getQuestionsDetail(){
	include "db.php";
	$sql="SELECT * FROM questions ORDER BY u_id DESC";
	$result=$conn->query($sql);
	$sr=1;
	while($row=$result->fetch_assoc()){
				?>
			<tr>
				 <td><?php echo $sr;?></td>
				 <td><?php echo getQuestionPaperNameById($row["questionPaperId"]);?></td>
				 <td><?php echo $row["question"];?></td>
				 <td><?php echo $row["option1"];?></td>
				 <td><?php echo $row["option2"];?></td>
				 <td><?php echo $row["option3"];?></td>
				 <td><?php echo $row["option4"];?></td>
				 <td><?php echo $row["answer"];?></td>
				 <td style="padding:12px;">
				 <button type="button"class="btn" onclick='window.open("editQuestionConfirm.php?questionId=<?php echo $row["id"];?>","_blank")' data-toggle="tooltip" title="Click On Me To Edit Question OF This Question Paper">
							 <i class="fa fa-edit"></i> Edit
				</button>
				 </td>

				 <td style="padding:12px;">
				 <button type="button"class="btn1" onclick="deleteQuestion(<?php echo $row["id"];?>)" data-toggle="tooltip" title="Click On Me To Edit Question OF This Question Paper">
							 <i class="fa fa-trash"></i> Delete
				</button>
				 </td>
			</tr>
				<?php
	}
}
#getQuestionsDetail end;

#getQuestionsDetailForView
function getQuestionsDetailForView(){
	include "db.php";
	$sql="SELECT * FROM questions ORDER BY u_id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while($row=$result->fetch_assoc()){
			 ?>
		 <tr>
				<td><?php echo $sr;?></td>
				<td><?php echo getQuestionPaperNameById($row["questionPaperId"]);?></td>
				<td><?php echo $row["question"];?></td>
				<td><?php echo $row["option1"];?></td>
				<td><?php echo $row["option2"];?></td>
				<td><?php echo $row["option3"];?></td>
				<td><?php echo $row["option4"];?></td>
				<td><?php echo $row["answer"];?></td>
				<td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
				<td><?php echo date("d-m-y h:i:s A",strtotime($row["u_id"]));?></td>
		 </tr>
			 <?php
		}
}
#getQuestionsDetailForView end;

#getStudentInfoById()
function getStudentInfoById($studentId){
	include "db.php";
	$sql="SELECT * FROM student WHERE id='$studentId'";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc()){
		   return $row["name"]." S/o ".$row["fname"]." (".$row["course"].") A/c";
	}
}
#getStudentInfoById() end;

#getFeeInfoForEdit
function getFeeInfoForEdit(){
	   include "db.php";
		 $session=$_SESSION["current_session"];
		 $sql="SELECT * FROM fee WHERE session='$session' ORDER BY id DESC";
		 $result=$conn->query($sql);
		 $sr=1;
		 while($row=$result->fetch_assoc()){
			    ?>
					   <tr>
							 <td><?php echo $sr;?></td>
							 <td><?php echo date("d-m-y",strtotime($row["c_id"]));?></td>
							 <td><?php echo getStudentInfoById($row["studentId"]);?></td>
							 <td><?php echo $row["feeReceived"];?></td>
							 <td><?php echo $row["discount"];?></td>
							 <td><?php echo $row["feeReceived"]-$row["discount"];?></td>
							 <td><?php echo date("d-m-y h:i:s A",strtotime($row["u_id"]));?></td>
							 <td>
							 	    <button type="button" id="btn" data-toggle="tooltip" title="Click On Me To Edit This Fee Detail" onclick='window.open("editFeeConfirm.php?feeId=<?php echo $row['id']?>","_blank")'>
											<i class='fa fa-edit'></i> Edit
										</button>
							 </td>
					   </tr>
					<?php
					$sr++;
		 }
}
#getFeeInfoForEdit end;

#getFeeInfoForView
function getFeeInfoForView(){
	include "db.php";
	$session=$_SESSION["current_session"];
	$sql="SELECT * FROM fee WHERE session='$session' ORDER BY id DESC";
	$result=$conn->query($sql);
	$sr=1;
	while($row=$result->fetch_assoc()){
			 ?>
					<tr>
						<td><?php echo $sr;?></td>
						<td><?php echo date("d-m-y",strtotime($row["c_id"]));?></td>
						<td><?php echo getStudentInfoById($row["studentId"]);?></td>
						<td><?php echo $row["feeReceived"];?></td>
						<td><?php echo $row["discount"];?></td>
						<td><?php echo $row["feeReceived"]-$row["discount"];?></td>
						<td><?php echo date("d-m-y h:i:s A",strtotime($row["u_id"]));?></td>
					</tr>
			 <?php
			 $sr++;
	}
}
#getFeeInfoForView end;
