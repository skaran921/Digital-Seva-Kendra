<?php
session_start();
$page_id=4;
$thought_page_sub_id=5;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Today Thought - Digital Seva Kendra</title>

  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
         <div class="container">
             <div class="card">
                 <div class="card-header w3-win8-green">
                         <b><i class="fa fa-check-circle"></i></b>
                 </div>
                 <div class="card-body">
                   <center>
                         <input type="search" id="myInput" class="form-control" placeholder="Search......." style="margin-bottom:2px;" data-toggle="tooltip" title="Enter Value On Me For Search Course" autofocus>
  								 </center>
                         <div class="table-responsive">
                            <table class="table table-striped" id="myTable">
                                 <tr class="thead-dark" align="center">
                                   <th>Sr. No.</th>
                                   <th>Thought</th>
                                   <th><i class="fa fa-check-circle text-success"><i/></th>
                                 </tr>
                                 <?php select_today_thought_detail_in_row();?>
                            </table>
                        </div>
                 </div>
                 <div class="card-footer w3-win8-green">

                 </div>
             </div>
        </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>

	 $(document).ready(function(){
		    $("#myInput").on("keyup",function(){
					let value=$(this).val().toLowerCase();
	 			 $("#myTable tr").filter(function(){
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	 			 });
			});
	 });
</script>

<?php
   if(isset($_POST["set"])){
         $thought_id=$_POST["thought_id"];
         include 'db.php';
         $sql="UPDATE today_thought SET thought='$thought_id'";
         $result=$conn->query($sql);
         if($result==TRUE){
                ?>
                <script>
                  let msg="<div class='card bg-success text-light'><center><i class='fa fa-check-circle' style='font-size:100px;'></i></center>Set This Thought As Today's Thought!!!</div>";

                 alertify.alert(msg);
                   alertify.success(msg);
               </script>
                <?php
         }else {
                  ?>
                  <script>
                    let msg="<div class='card w3-win8-red'><center><i class='fa fa-times-circle' style='font-size:100px;'></i></center>oops!!! error!!!</div>";
                     alertify.alert(msg);
                     alertify.error(msg);
                 </script>
                  <?php
         }
   }
?>
