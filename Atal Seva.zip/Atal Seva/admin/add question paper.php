<?php
session_start();
$super_user_page_id=4;
$exam_page_sub_id=1;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Add Question Paper- Digital Seva Kendra</title>
    <style>
        #main-card{
              background: linear-gradient(-45deg,black,blue,purple);
              color:#fff;
        }
        #card-icon{
             position: relative;
             font-size: 100px;
             top:-60px;
             background: linear-gradient(-45deg,black,blue,purple);
             padding: 16px;
             border-radius: 50%;
             box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        h4{
           position: relative;
           top:-60px;
        }
        form{
              position: relative;
              top:-50px;
              max-width: 400px;
              padding: 10px;
              box-shadow: 0 10px 10px 10px rgba(0,0,0,0.9);
              border-radius: 10px;
        }

        .btn1{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background: #ff0095;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }

        .btn1:hover{
                 transition: 3s;
                 background-color: green;
        }

        .btn2{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background:red;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }

        .btn2:hover{
                 transition: 3s;
                 background-color:whitesmoke;
                 color:#000;
        }

        input,select{
               height: 40px;
               width:260px;
               box-shadow: 0 10px 10px rgba(0,0,0,0.3);
               border-radius:10px;
               border-style: dashed;
               text-transform: capitalize;
               background: cornsilk;
        }
        label{
            width:100px;
        }
    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
           <div class="container mb-4">
                <div class="card" id="main-card">
                    <div class="card-body">
                      <center>
                           <i class="fa fa-graduation-cap" id="card-icon"></i><br>
                            <h4>Add Question Paper</h4>
                      </center>
                      <center>
                             <form action="" method="post" id="questionPaperForm">
                                 <div class="form-group form-inline">
                                     <label><b><i class='fa fa-asterisk'></i> Title:</b></label>&nbsp;&nbsp;&nbsp;
                                      <input type="text" name="title" id="title" placeholder="Name Of Question Paper" required autofocus data-toggle="tooltip" title="Here Comes Title/Name Of Question Paper eg. HTML Paper">
                                 </div>

                                 <div class="form-group form-inline">
                                     <label><b><i class='fa fa-asterisk'></i> Total Question's:</b></label>&nbsp;&nbsp;&nbsp;
                                      <input type="number" name="totalQuestions" id="totalQuestions" placeholder="Total Question In Paper" required data-toggle="tooltip" title="Here Comes Total No. Of Questions in Question Paper eg. 50">
                                 </div>

                                 <div class="form-group form-inline">
                                     <label><b><i class='fa fa-asterisk'></i> Marks:</b></label>&nbsp;&nbsp;&nbsp;
                                      <input type="number" name="marks" id="marks" placeholder="Total Marks OF Question Paper" required data-toggle="tooltip" title="Here Comes Total Marks Of Question Paper eg. 100">
                                 </div>

                                 <div class="form-group form-inline">
                                     <label><b><i class='fa fa-asterisk'></i>Select Time:</b></label>&nbsp;&nbsp;&nbsp;
                                      <select name="time" id="time" required data-toggle="tooltip" title="Here Comes Total Marks Of Question Paper eg. 100">
                                          <option value="">Select Time Of Question Paper</option>
                                          <optgroup label="In Minute">
                                             <option value="5">5 Minute</option>
                                             <option value="10">10 Minute</option>
                                             <option value="15">15 Minute</option>
                                             <option value="20">20 Minute</option>
                                             <option value="30">30 Minute</option>
                                             <option value="40">40 Minute</option>
                                             <option value="50">50 Minute</option>
                                          </optgroup>

                                          <optgroup label="In Hours">
                                            <option value="60">1 Hour</option>
                                            <option value="120">2 Hour</option>
                                            <option value="180">3 Hour</option>
                                          </optgroup>
                                      </select>
                                 </div>
                                    <div class="form-group">
                                         <center>
                                              <button type="button" class="btn1" onclick="validate()" data-toggle="tooltip" title="Click On Me To Save This Question Paper" data-placement="left">
                                                  <i class="fa fa-save"></i> Save
                                              </button>

                                              <button type="reset" class="btn2" onclick="validate()" data-toggle="tooltip" title="Click On Me To Reset Form" data-placement="right">
                                                  <i class="fa fa-refresh"></i> Reset
                                              </button>
                                         </center>
                                    </div>
                             </form>
                      </center>
                    </div>
                </div>
           </div>
    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>

<script>
  function validate(){
     let title=document.getElementById("title").value;
     let totalQuestions=document.getElementById("totalQuestions").value;
     let marks=document.getElementById("marks").value;
     let time=document.getElementById("time").value;
     if(title.length<=1){
          let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px'></i><br>Title Of Question Paper is Not Valid!!!</center></div>"
          alertify.alert(msg);
          alertify.log(msg);
     }else if( (totalQuestions.length<1) || (isNaN(totalQuestions)) ){
          let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px'></i><br>Total Question's is Not Valid!!!</center></div>"
          alertify.alert(msg);
          alertify.log(msg);
     }else if( (marks.length<1) || (isNaN(marks)) ){
          let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px'></i><br>Total Marks is Not Valid!!!</center></div>"
          alertify.alert(msg);
          alertify.log(msg);
     }else if( (time.length<1) ){
          let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px'></i><br>Please Select Time!!!</center></div>"
          alertify.alert(msg);
          alertify.log(msg);
     }else{
          document.getElementById("questionPaperForm").submit();
     }
  }
</script>

<?php
    if( (isset($_POST["title"])) && (isset($_POST["totalQuestions"])) && (isset($_POST["marks"])) && (isset($_POST["time"])) ){
                $title=$_POST["title"];
                $totalQuestions=$_POST["totalQuestions"];
                $totalMarks=$_POST["marks"];
                $time=$_POST["time"];
                $marksPerQuestion=$totalMarks/$totalQuestions;
                include "db.php";
                $sql1="SELECT * FROM  questionPaper WHERE title='$title' AND $totalQuestions='$totalQuestions'";
                $result1=$conn->query($sql1);
                if($row1=$result1->fetch_assoc()){
                    ?>
                      <script>
                       let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px'></i><br>This Question Paper Already Added!!!</center></div>"
                       alertify.alert(msg);
                       alertify.log(msg);
                      </script>
                    <?php
                }else{
                $sql2="INSERT INTO questionPaper(title,totalQuestions,totalMarks,totalTime,marksPerQuestion)VALUES('$title','$totalQuestions','$totalMarks','$time','$marksPerQuestion')";
                       $result2=$conn->query($sql2);
                       if($result2==TRUE){
                              ?>
                              <script>
                               let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:100px'></i><br>Question Paper Added!!!</center></div>"
                               alertify.alert(msg);
                               alertify.log(msg);
                              </script>
                              <?php
                       }else {
                          ?>
                          <script>
                           let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:100px'></i><br>Error...This Question Paper Not Added!!!</center></div>"
                           alertify.alert(msg);
                           alertify.log(msg);
                          </script>
                          <?php
                       }
                }
    }
?>
