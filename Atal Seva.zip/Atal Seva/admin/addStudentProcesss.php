
<?php
  if( (isset($_POST["name"])) && (isset($_POST["fname"])) && (isset($_POST["dob"])) && (isset($_POST["gender"])) && (isset($_POST["city"])) && (isset($_POST["address"])) && (isset($_POST["mobile"])) && (isset($_POST["course"])) ){
    include 'db.php';
    $name=$_POST["name"];
    $fname=$_POST["fname"];
    $dob=$_POST["dob"];
    $gender=$_POST["gender"];
    $city=$_POST["city"];
    $address=$_POST["address"];
    $mobile=$_POST["mobile"];
    $course=$_POST["course"];
    $session=$_POST["session"];
    $image=$_FILES["image"]["name"];
    $imageName=$name.$fname.$dob.$image;
    $date=date("d",strtotime($dob));
    $month=date("m",strtotime($dob));
    $year=date("Y",strtotime($dob));
    $studentEmail=$name.$date.$month.$year."digitalseva".$session.".com";
    $password=date("d/m/Y",strtotime($dob));
    $file_dir="students/".$session."/".$course;
    if(!file_exists($file_dir)){
         mkdir($file_dir,0777,true);
    }
  $sql1="SELECT * FROM student WHERE name='$name' AND fname='$fname' AND dob='$dob' AND course='$course'";
  $result1=$conn->query($sql1);
  if($row1=$result1->fetch_assoc()){
                  ?>
          <script>
              let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center> This Student Record Already Added!!!</div>";
              alertify.alert(msg);
              alertify.error(msg);
          </script>
                  <?php
  }else{
        $sql="INSERT INTO student(name,fname,dob,gender,city,address,mobile,course,session,image,studentEmail,password)VALUES('$name','$fname','$dob','$gender','$city','$address','$mobile','$course','$session','$imageName','$studentEmail','$password')";
        if(move_uploaded_file($_FILES["image"]["tmp_name"],$file_dir."/".$imageName)){
               $result=$conn->query($sql);
               if($result==TRUE){
                        ?>
                        <script>
  let msg="<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:200px;'></i><br>Saved!!!</center></div>";
                             alertify.alert(msg);
                             alertify.error(msg);
                        </script>
                        <?php
               }else{
                 ?>
         <script>
             let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center>error..Student Record Not Saved!!!</div>";
             alertify.alert(msg);
             alertify.error(msg);
         </script>
         <?php
               }
        }else{
          ?>
  <script>
      let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-warning' style='font-size:100px;'></i></center>Image Not Uploaded!!!</div>";
      alertify.alert(msg);
      alertify.error(msg);
  </script>
          <?php
        }#fileupload
  }#else part of fetch_assoc
}#if isset
?>
