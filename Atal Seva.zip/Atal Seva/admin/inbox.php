<?php
session_start();
$page_id=6;
$contact_page_sub_id=1;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>inbox - Digital Seva Kendra</title>
	<style>
	</style>
  </head>
  <body class="text-dark">

    <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
          <div class="container">
              <div class="card">
                 <div class="card-header" style="background:linear-gradient(45deg,#ff0099,red,purple);color:#fff;">
                       <b><i class="fa fa-envelope"></i> inbox</b>
                 </div>
                   <div class="card-body">
                        <div style="overflow-x:auto">
                            <center>
                                <input type="text" id="myInput" autofocus placeholder="Search Messages..........." class="form-control" data-toggle="tooltip" title="Enter Value On Me For Search Something In This Table" data-placement="left">
                            </center>
                            <table class="table table-bordered">
                                 <thead class="sticky-top">
                                   <tr class="thead-dark" align="center">
                                         <th> <i class="fa fa-angle-double-down"></i> Sr. No.</th>
                                         <th><i class="fa fa-user"></i> Name</th>
                                         <th><i class="fa fa-mobile"></i> Mobile No.</th>
                                         <th><i class="fa fa-envelope-square"></i> Messages</th>
                                         <th><i class="fa fa-calendar-check-o"></i> Received On</th>
                                         <th><i class="fa fa-trash"></i></th>
                                   </tr>
                                 </thead>
                                 <tbody id="myTable" style="font-weight:bold">
                                           <?php getMessages();?>
                                </tbody>
                            </table>
                        </div>
                   </div>
                 <div class="card-footer" style="background:linear-gradient(64deg,red,yellow,red);">
                 </div>
              </div>

          </div>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
    <script src="js/textEditor.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());

$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});

         function deleteMeassage(messageId){
           let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-question' style='font-size:100px'></i></center> Are You Sure?</div>";
              alertify.confirm(msg,function(){window.open("deleteMeassageConfirm.php?messageId="+messageId,"_blank")});
         }
</script>
  </body>
</html>
<?php
   include "db.php";
   $sql="UPDATE contact SET status=1 WHERE status=0";
   $result=$conn->query($sql);
?>
