<?php
session_start();
$super_user_page_id=0;
if(isset($_SESSION["admin_id"])){
}else{
    	header("Location: index.php");
}

if(isset($_SESSION["super_admin_id"])){
  	header("Location: superUserMain.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Super Admin Login - Digital Seva Kendra</title>
    <style>
      #login-card{
             background: linear-gradient(-45deg,#24ff72,#9a4eff);
             color:#fff;
      }

      .form-control{
           border-radius:12px;
      }

      .btn{
          border-radius:30px;
          font-size:20px;
      }

      #form-logo{
         position: relative;
          font-size: 50px;
          background: linear-gradient(-45deg,#24ff72,#9a4eff);
           width:100px;
           height:100px;
           line-height: 100px;
           box-shadow:0 10px 10px rgba(0,0,0,0.3);
           border-radius:50%;
           top:-60px;
      }
      form{
          position: relative;
          top:-40px;
      }
    </style>
  </head>
  <body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top  fixed-top" style="background-color:black;box-shadow:1px 1px 1px #999;">
    <a href="index.php" class="text-warning navbar-brand" style="font-family:Comic Sans MS">
	   <i class="fa fa-laptop"></i> Digital Seva Kendra
	</a>
<center>
          	<ul class="navbar-nav mr-auto">
              <li class="nav-item form-inline">
			  <div class="navbar-text text-center">
               <b> Super Admin Login Panel</b>
             </div>
			   <a href="#" class="nav-link"><i class="fa fa-facebook text-light"></i></a>&nbsp;&nbsp;&nbsp;
			   <a href="#" class="nav-link"><i class="fa fa-twitter text-light"></i></a>&nbsp;&nbsp;&nbsp;
			   <a href="#" class="nav-link"><i class="fa fa-instagram text-light"></i></a>&nbsp;&nbsp;&nbsp;
			   <a href="#" class="nav-link"><i class="fa fa-youtube-play text-light" style="overflow:hidden"></i></a>&nbsp;&nbsp;&nbsp;
			   <a href="#" class="nav-link"><i class="fa fa-linkedin text-light" style="overflow:hidden"></i></a>&nbsp;&nbsp;&nbsp;
		     </li>
		  </ul>
</nav>

        <?php
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<center>
  <div class="container-fluid">
		  <div class="card" align="left" style="max-width:400px;" id="login-card">
		   <div class="card-body">
         <center>
            <i class="fa fa-user-secret" id="form-logo"></i>
         </center>
		       <form action="" method="post" id="AdminLoginForm"  name="AdminLoginForm">
	               <label><b><i class="fa fa-user-secret"></i> Super User Email:</b></label>
				   <input type="email" name="email" id="email" class="form-control" placeholder="User Name" required autofocus>
				   <label><b><i class="fa fa-lock"></i> Password:</b></label>
				   <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
				    <br>
				 <center>
			      <button type="button" class="btn btn-success" onclick="validateAdminLogin()"><i class="fa fa-sign-in"></i> Login</button>
                  <button type="reset" class="btn btn-danger"><i class="fa fa-refresh"></i> Reset</button>
				  <div id="error" class="card" style="background-color:red;color:white;margin-top:10px;display:none;"></div>
				</center>
			   </form>
		   </div>
		   <div class="card-footer">
		   </div>
		</div><br>
    <?php include 'footerAdmin.php'; ?>
</div><!--container-fluid  -->

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>

<script>
function validateAdminLogin()
{
	let email=document.getElementById('email').value;
	let pass=document.getElementById('password').value;
   	if(!(email.includes('.com')) || (!email.includes('@')) || (email.length<1))
	{
		let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Username</div>";
		alertify.alert(msg);
		alertify.log(msg);
		document.getElementById('error').innerHTML=msg;
		document.getElementById("error").style.display="block";
	}
   else if(pass.length<1)
   {
	   let msg="<div class='card text-danger font-weight-bold'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center> Not Valid Password</div>";
		alertify.alert(msg);
		alertify.log(msg);
		document.getElementById('error').innerHTML=msg;
		document.getElementById("error").style.display="block";
   }
   else
   {
	    document.getElementById('AdminLoginForm').submit();
   }
}
</script>

<?php
  if((isset($_POST["email"])) && (isset($_POST["password"])) )
  {
	  $email=$_POST["email"];
	  $password=$_POST["password"];
	  include 'db.php';
	  $sql=$conn->prepare("SELECT id FROM superUser WHERE email=? AND password=?");
	  $sql->bind_param("ss",$email,$password);
	  $sql->execute();
	  $result=$sql->get_result();
	  if($row=$result->fetch_assoc())
	  {
	    $_SESSION["super_admin_id"]=$row["id"];
        ?>
		<script>
		 window.location.href="superUserMain.php";
		 </script>
         <?php
      }
	  else
	  {
	   ?>
	   <script>
	       var msg="<div class='card w3-win8-red p-4'><center><i class='fa fa-times-circle' style='font-size:50px'></i></center> Email OR Password Not Matched!!!</div>"
	      alertify.alert(msg);
	      alertify.log(msg);
	   </script>
		 <?php
	 }
  }
?>
