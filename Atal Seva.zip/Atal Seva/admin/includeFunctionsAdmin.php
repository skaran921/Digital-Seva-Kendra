<?php
#get_admin_name
function get_admin_name($admin_id)
{
	include 'db.php';
    $sql="SELECT name FROM admin WHERE id='$admin_id'";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
	    return $row['name'];
	}
}

#total visitors
function total_visitors()
{
   include 'db.php';
   $sql="SELECT total_visitors FROM visitor_counter";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return $row['total_visitors'];
   }
}

#getCourseName
function getCourseName($courseId){
	     include "db.php";
			 $sql="SELECT title FROM course WHERE id='$courseId'";
			 $result=$conn->query($sql);
			 if($row=$result->fetch_assoc()){
            return $row["title"];
			 }else{
				 echo "error".$courseId;
			 }
}
#getCourseName end;
#total_course
function total_course()
{
   include 'db.php';
   $sql="SELECT count(*) as total_course FROM course";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return $row['total_course'];
   }
}

#total_download
function total_download(){
	include 'db.php';
	$sql="SELECT count(*) as total_download FROM download";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_download'];
	}
}
#total_download end;

#total_thought
function total_thought(){
	 include 'db.php';
	 $sql="SELECT count(*) as total_thought FROM thought";
	 $result=$conn->query($sql);
	 if($row=$result->fetch_assoc())
	 {
		 return $row['total_thought'];
	 }
}
#total_download end;

#total_jobNotification
 function total_jobNotification(){
	 include 'db.php';
	 $sql="SELECT count(*) as total_jobNotification FROM jobnotification";
	 $result=$conn->query($sql);
	 if($row=$result->fetch_assoc())
	 {
		 return $row['total_jobNotification'];
	 }
 }
#total_jobNotification end;

#total_jobGroup
function total_jobGroup(){
	include 'db.php';
 $sql="SELECT count(*) as total_jobGroup FROM jobGroup";
 $result=$conn->query($sql);
 if($row=$result->fetch_assoc())
 {
	 return $row['total_jobGroup'];
 }
}
#total_jobGroup end;

#total_generalNotification
 function total_generalNotification(){
	 include 'db.php';
	 $sql="SELECT count(*) as total_generalNotification FROM generalnotification";
	 $result=$conn->query($sql);
	 if($row=$result->fetch_assoc())
	 {
		 return $row['total_generalNotification'];
	 }
 }
#total_generalNotification end;

#messageInfo
function total_message(){
	include 'db.php';
	$sql="SELECT count(*) as total_message FROM contact";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_message'];
	}
 }
#messageInfo end;

#newMessages
function newMessages(){
	include 'db.php';
	$sql="SELECT count(*) as total_message FROM contact WHERE status=0";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_message'];
	}
}
#newMessages end;

#admissionInfo
function total_admission(){
	include 'db.php';
	$sql="SELECT count(*) as total_admission FROM admission";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_admission'];
	}
 }
#messageInfo end;

#newAdmission
function newAdmission(){
	include 'db.php';
	$sql="SELECT count(*) as total_admission FROM admission WHERE status=0";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		return $row['total_admission'];
	}
}
#newAdmission end;

#last_password_update
function last_password_update($admin_id)
{
   include 'db.php';
   $sql="SELECT u_id FROM admin WHERE id='$admin_id'";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return date("d-m-y h:i:s A",strtotime($row['u_id']));
   }
}

#udate_course_detail_in_row
function update_course_detail_in_row()
{
	include 'db.php';
	$sql="SELECT * FROM course ORDER BY title";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		  $sql1="SELECT * FROM course ORDER BY title";
		  $result1=$conn->query($sql1);
			$sr=1;
		  while($row1=$result1->fetch_assoc())
		  {
	            ?>
							   <tr>
									   <td><?php echo $sr; ?></td>
										 <td style="background-color:<?php echo $row1["color"];?>"></td>
									   <td><?php echo $row1["title"]; ?></td>
									   <td><i class="fa fa-money"></i> <?php echo $row1["fee"]; ?></td>
									   <td><i class="fa fa-calendar"></i> <?php echo $row1["duration"]; ?></td>
									   <td><i class="fa fa-book"></i> <?php echo $row1["syllabus"]; ?></td>
									   <td>
                           <form action="edit course.php" method="post">
															 <button type="submit" name="edit" data-toggle="tooltip" title="click me to edit this course" class="btn btn-primary" onclick="editCourse(<?php echo $row1["id"];?>)">
																     <i class="fa fa-edit"></i> Edit
															 </button>
													 </form>
										 </td>
								 </tr>
							<?php
							$sr++;
		  }
	}
	else {
	         	?>
      	<tr><td colspan="6" class="bg-dark display-5"><p class="text-primary font-weight-bold"><i class="fa fa-warning text-danger"></i> Sorry!!! No Record Found!!!</p><td></tr>
					<?php
	}
}#end function update_course_detail_in_row

#course_detail_in_row
function course_detail_in_row(){
		include 'db.php';
		$sql="SELECT * FROM course ORDER BY title";
		$result=$conn->query($sql);
		if($row=$result->fetch_assoc())
		{
				$sql1="SELECT * FROM course ORDER BY title";
				$result1=$conn->query($sql1);
				$sr=1;
				while($row1=$result1->fetch_assoc())
				{
								?>
									 <tr>
											 <td><?php echo $sr; ?></td>
											 <td style="background-color:<?php echo $row1["color"];?>"></td>
											 <td><?php echo $row1["title"]; ?></td>
											 <td><i class="fa fa-money"></i> <?php echo $row1["fee"]; ?></td>
											 <td><i class="fa fa-calendar"></i> <?php echo $row1["duration"]; ?></td>
											 <td><i class="fa fa-book"></i> <?php echo $row1["syllabus"]; ?></td>
											 <td><i class="fa fa-user"></i> <?php echo get_admin_name($row1["admin"]); ?></td>
											 <td><i class="fa fa-calendar-plus-o"></i> <?php echo date("d-m-y h:s:i A",strtotime($row1["c_id"]));?></td>
											 <td><i class="fa fa-calendar-check-o"></i> <?php echo date("d-m-y h:s:i A",strtotime($row1["u_id"]));?></td>
									 </tr>
								<?php
								$sr++;
				}
		}else {
							?>
				<tr><td colspan="8" class="bg-dark display-5"><p class="text-primary font-weight-bold"><i class="fa fa-warning text-danger"></i> Sorry!!! No Record Found!!!</p><td></tr>
						<?php
		}
}#course_detail_in_row end;

#delete_course_detail_in_row
function delete_course_detail_in_row(){
	include 'db.php';
	$sql="SELECT * FROM course ORDER BY title";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
			$sql1="SELECT * FROM course ORDER BY title";
			$result1=$conn->query($sql1);
			$sr=1;
			while($row1=$result1->fetch_assoc())
			{
							?>
								 <tr>
										 <td><?php echo $sr; ?></td>
										 <td style="background-color:<?php echo $row1["color"];?>"></td>
										 <td><?php echo $row1["title"]; ?></td>
										 <td><i class="fa fa-money"></i> <?php echo $row1["fee"]; ?></td>
										 <td><i class="fa fa-calendar"></i> <?php echo $row1["duration"]; ?></td>
										 <td><i class="fa fa-book"></i> <?php echo $row1["syllabus"]; ?></td>
										 <td>
													 <form action="delete course.php" method="post">
															 <button type="submit" name="edit" data-toggle="tooltip" title="click me to delete this course" class="btn w3-win8-red" onclick="deleteCourse(<?php echo $row1["id"];?>)">
																		 <i class="fa fa-trash"></i> Delete
															 </button>
													 </form>
										 </td>
								 </tr>
							<?php
							$sr++;
			}
	}
	else {
						?>
				<tr><td colspan="6" class="bg-dark display-5"><p class="text-primary font-weight-bold"><i class="fa fa-warning text-danger"></i> Sorry!!! No Record Found!!!</p><td></tr>
					<?php
	}
}#delete_course_detail_in_row end;

#edit_thought_detail_in_row
function edit_thought_detail_in_row(){
             include 'db.php';
						 $sql="SELECT * FROM thought ORDER BY thought";
						 $result=$conn->query($sql);
						 $sr=1;
						 while($row=$result->fetch_assoc()){
							     ?>
									  <tr>
									  	  <td><?php echo $sr;?></td>
									  	  <td>
													<div class="container" align="left">
													 <blockquote style="border-width:0px 0px 0px 0px;border-right:10px;border-color:black;padding:10px;border-style:solid;">
															<p class=""><?php echo $row["thought"];?></p>
															<footer class="blockquote-footer"><?php echo $row['author'] ?></footer>
													 </blockquote>
												 </div>
											 </td>
												<td>
	                            <form action="edit thought.php" method="post">
	 															 <button type="submit" name="edit" data-toggle="tooltip" title="click me to edit this course" class="btn w3-win8-orange" onclick="editThought(<?php echo $row["id"];?>)">
	 																     <i class="fa fa-edit"></i> Edit
	 															 </button>
	 													 </form>
	 										 </td>
									  </tr>
									 <?php
									 $sr++;
						 }
}#edit_thought_detail_in_row end

#thought_detail_in_row
function thought_detail_in_row(){
             include 'db.php';
						 $sql="SELECT * FROM thought ORDER BY thought";
						 $result=$conn->query($sql);
						 $sr=1;
						 while($row=$result->fetch_assoc()){
							     ?>
									  <tr>
									  	  <td><?php echo $sr;?></td>
									  	  <td>
													<div class="container" align="left">
													 <blockquote style="border-width:0px 0px 0px 0px;border-left:10px;border-color:white;padding:10px;border-style:solid;">
															<p class=""><?php echo $row["thought"];?></p>
															<footer class="blockquote-footer"><?php echo $row['author'] ?></footer>
													 </blockquote>
												 </div>
											 </td>
											 <td>
												    <?php echo get_admin_name($row["admin"])?>
											 </td>
											 <td>
												   <?php echo date("d-m-y h:i:s A",strtotime($row['c_id']));?>
											  </td>
												<td>
 												   <?php echo date("d-m-y h:i:s A",strtotime($row['u_id']));?>
 											  </td>
									  </tr>
									 <?php
									 $sr++;
						 }
}#thought_detail_in_row end

#delete_thought_detail_in_row
function delete_thought_detail_in_row(){
             include 'db.php';
						 $sql="SELECT * FROM thought ORDER BY thought";
						 $result=$conn->query($sql);
						 $sr=1;
						 while($row=$result->fetch_assoc()){
							     ?>
									  <tr>
									  	  <td><?php echo $sr;?></td>
									  	  <td>
													<div class="container" align="left">
													 <blockquote style="border-width:0px 0px 0px 0px;border-right:10px;border-color:black;padding:10px;border-style:solid;">
															<p class=""><?php echo $row["thought"];?></p>
															<footer class="blockquote-footer"><?php echo $row['author'] ?></footer>
													 </blockquote>
												 </div>
											 </td>
												<td>
	                            <form action="delete thought.php" method="post">
	 															 <button type="submit" name="edit" data-toggle="tooltip" title="click me to Delete this Thought" class="btn w3-win8-red" onclick="deleteThought(<?php echo $row["id"];?>)">
	 																     <i class="fa fa-trash"></i> Delete
	 															 </button>
	 													 </form>
	 										 </td>
									  </tr>
									 <?php
									 $sr++;
						 }
}#delete_thought_detail_in_row end

#select_today_thought_detail_in_row
function select_today_thought_detail_in_row(){
             include 'db.php';
						 $sql="SELECT * FROM thought ORDER BY thought";
						 $result=$conn->query($sql);
						 $sr=1;
						 while($row=$result->fetch_assoc()){
							     ?>
									  <tr>
									  	  <td><?php echo $sr;?></td>
									  	  <td>
													<div class="container" align="left">
													 <blockquote style="border-width:0px 0px 0px 0px;border-right:10px;border-color:black;padding:10px;border-style:solid;">
															<p class=""><?php echo $row["thought"];?></p>
															<footer class="blockquote-footer"><?php echo $row['author'] ?></footer>
													 </blockquote>
												 </div>
											 </td>
												<td>
	                            <form action="today thought.php" method="post">
																  <input type="hidden" name="thought_id" id="thought_id" value="<?php echo $row["id"];?>" required>
	 															 <button type="submit" name="set" data-toggle="tooltip" title="click me to Set this thought as today's thought" class="btn w3-win8-green">
	 																     <i class="fa fa-check-circle"></i> Set This Thought
	 															 </button>
	 													 </form>
	 										 </td>
									  </tr>
									 <?php
									 $sr++;
						 }
}#select_today_thought_detail_in_row end

#getNewsForUpdateTable
function getNewsForUpdateTable(){
    include "db.php";
		$sql="SELECT * FROM news ORDER BY u_id DESC";
		$result=$conn->query($sql);
		$sr=1;
		while ($row=$result->fetch_assoc()) {
	  	    ?>
					   <tr align="center">
							   <td><?php echo $sr;?></td>
							     <td><?php echo addslashes($row["news"]);?></td>
							   <td>
                       <form action="editNewsAndUpdate.php" method="post">
												   <button type="button" name="button" class="btn w3-win8-blue" onclick="editNews(<?php echo $row["id"];?>)" data-placement="left" data-toggle="tooltip" title="Click On Me To Edit This News And Content">
														 <i class="fa fa-edit"></i> Edit
													 </button>
											 </form>
								 </td>
						 </tr>
					<?php
					$sr++;
	  }
}#getNewsForUpdateTable end;

#viewNewsForUpdateTable
function viewNewsForUpdateTable(){
      include 'db.php';
			$sql="SELECT * FROM news ORDER BY u_id DESC";
			$result=$conn->query($sql);
			$sr=1;
			while ($row=$result->fetch_assoc()) {
		  	    ?>
						   <tr align="center">
								   <td><?php echo $sr;?></td>
								   <td><?php echo addslashes($row["news"]);?></td>
								   <td><?php echo get_admin_name($row["admin"]);?></td>
								   <td><?php echo date("d-m-y h:i:s a",strtotime($row["c_id"]));?></td>
								   <td><?php echo date("d-m-y h:i:s a",strtotime($row["u_id"]));?></td>
							 </tr>
						<?php
						$sr++;
		  }
}#viewNewsForUpdateTable end;

#getNewsForDeleteTable
function   getNewsForDeleteTable(){
	include "db.php";
 $sql="SELECT * FROM news ORDER BY u_id DESC";
 $result=$conn->query($sql);
 $sr=1;
 while ($row=$result->fetch_assoc()) {
			 ?>
					<tr align="center">
							<td><?php echo $sr;?></td>
							<td><?php echo $row["news"];?></td>
							<td>
										 <form action="deleteNewsAndUpdate.php" method="post">
												<button type="button" name="button" class="btn w3-win8-red" onclick="deleteNews(<?php echo $row["id"];?>)" data-placement="left" data-toggle="tooltip" title="Click On Me To Delete This News And Content">
													<i class="fa fa-trash"></i> Delete
												</button>
										</form>
							</td>
					</tr>
			 <?php
			 $sr++;
 }
}#  getNewsForDeleteTable end;

#getJobGroupDetail
function getJobGroupDetail(){
	  include "db.php";
		$sql="SELECT * FROM jobGroup ORDER BY u_id DESC";
		$result=$conn->query($sql);
		$sr=1;
		while($row=$result->fetch_assoc()) {
			    ?>
					   <tr align="center">
                 <td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
                 <td style="font-weight:bold;"><?php echo $row["name"];?></td>
                 <td><?php echo get_admin_name($row["admin"]);?></td>
                 <td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
                 <td>
                       <button type="button" name="button" onclick="deleteJobGroup(<?php echo $row["id"]?>)" class="btn w3-win8-red" data-toggle="tooltip" title="Click On Me To Delete This Job Group" data-placement="left">
												   <i class="fa fa-trash"></i> Delete
											</button>
								 </td>
						 </tr>
					<?php
					$sr++;
		}

}#getJobGroupDetail end;

#getJobNotification
function getJobNotification(){
	  include 'db.php';
		$sql="SELECT * FROM jobNotification";
		$result=$conn->query($sql);
		$sr=1;
	while($row=$result->fetch_assoc()){
          ?>
					   <tr align="center">
                 <td><?php echo $sr;?></td>
                 <td><?php echo $row["notification"];?></td>
                 <td><?php echo $row["jobGroup"]; ?></td>
                 <td>
                         <form action="" method="post">
													    <button type="button" class="btn w3-win8-indigo" onclick="editJobNotification(<?php echo $row["id"];?>)">
																  <i class="fa fa-edit"></i> Edit
															</button>
												 </form>
								 </td>
						 </tr>
					<?php
					$sr++;
		}
}
#getJobNotification end;

#viewJobNotification
function viewJobNotification(){
	include 'db.php';
 $sql="SELECT * FROM jobNotification";
 $result=$conn->query($sql);
 $sr=1;
while($row=$result->fetch_assoc()){
				?>
					<tr align="center">
							 <td><?php echo $sr;?></td>
							 <td><?php echo $row["notification"];?></td>
							 <td><?php echo $row["jobGroup"]; ?></td>
							 <td><?php echo get_admin_name($row["admin"]);?></td>
							 <td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
							 <td><?php echo date("d-m-y h:i:s A",strtotime($row["u_id"]));?></td>

					</tr>
			 <?php
			 $sr++;
 }
}
#viewJobNotification end;

#getJobNotificationForDelete
function getJobNotificationForDelete(){
	include 'db.php';
	$sql="SELECT * FROM jobNotification";
	$result=$conn->query($sql);
	$sr=1;
while($row=$result->fetch_assoc()){
				?>
					 <tr align="center">
							 <td><?php echo $sr;?></td>
							 <td><?php echo $row["notification"];?></td>
							 <td><?php echo $row["jobGroup"]; ?></td>
							 <td>
											 <form action="" method="post">
														<button type="button" class="btn w3-win8-red" onclick="deleteJobNotification(<?php echo $row["id"];?>)" data-toggle="tooltip" title="Click On Me To Delete This Job Notification">
																<i class="fa fa-trash"></i> Delete
														</button>
											 </form>
							 </td>
					 </tr>
				<?php
				$sr++;
	}
}
#getJobNotificationForDelete end;

#getGeneralNotificationForEdit
function getGeneralNotificationForEdit(){
	include 'db.php';
	$sql="SELECT * FROM generalNotification";
	$result=$conn->query($sql);
	$sr=1;
while($row=$result->fetch_assoc()){
				?>
					 <tr align="center">
							 <td><?php echo $sr;?></td>
							 <td><?php echo $row["notification"];?></td>
							 <td>
											 <form action="" method="post">
														<button type="button" class="btn w3-win8-indigo" onclick="editGeneralNotification(<?php echo $row["id"];?>)">
																<i class="fa fa-edit"></i> Edit
														</button>
											 </form>
							 </td>
					 </tr>
				<?php
				$sr++;
	}
}
#getGeneralNotificationForEdit end;

#getAllGeneralNotification
function getAllGeneralNotification(){
	include 'db.php';
 $sql="SELECT * FROM generalNotification";
 $result=$conn->query($sql);
 $sr=1;
while($row=$result->fetch_assoc()){
			 ?>
					<tr align="center">
							<td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
							<td><?php echo $row["notification"];?></td>
							<td><?php echo get_admin_name($row["admin"]);?></td>
							<td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
							<td><?php echo date("d-m-y h:i:s A",strtotime($row["u_id"]));?></td>
					</tr>
			 <?php
			 $sr++;
	 }
}
#getAllGeneralNotification end;

#getGeneralNotificationForDelete
function getGeneralNotificationForDelete(){
	include 'db.php';
 $sql="SELECT * FROM generalNotification";
 $result=$conn->query($sql);
 $sr=1;
while($row=$result->fetch_assoc()){
			 ?>
					<tr align="center">
							<td><?php echo $sr;?></td>
							<td><?php echo $row["notification"];?></td>
							<td>
											<form action="" method="post">
													 <button type="button" class="btn w3-win8-red" onclick="deleteGeneralNotification(<?php echo $row["id"];?>)">
															 <i class="fa fa-trash"></i> Delete
													 </button>
											</form>
							</td>
					</tr>
			 <?php
			 $sr++;
   }
}
#getGeneralNotificationForDelete end;

#getMessages
function getMessages(){
	include 'db.php';
 $sql="SELECT * FROM contact ORDER BY id DESC";
 $result=$conn->query($sql);
 $sr=1;
while($row=$result->fetch_assoc()){
			 ?>
					<tr align="center">
							<td class="text-light font-weight-bold" style="background:linear-gradient(45deg,#ff0095,red)"><?php echo $sr;?></td>
							<td><?php echo $row["name"];?></td>
							<td><?php echo $row["mobile"];?></td>
							<td><?php echo $row["message"];?></td>
							<td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
							<td>
											<form action="" method="post">
													 <button type="button" class="btn w3-win8-red" onclick="deleteMeassage(<?php echo $row["id"];?>)">
															 <i class="fa fa-trash"></i> Delete
													 </button>
											</form>
							</td>
					</tr>
			 <?php
			 $sr++;
	 }
}
#getMessages end;

#getDownloadFile
function getDownloadFile(){
	include 'db.php';
 $sql="SELECT * FROM Download ORDER BY id DESC";
 $result=$conn->query($sql);
 $sr=1;
while($row=$result->fetch_assoc()){
			 ?>
					<tr align="center" class="font-weight-bold">
							<td class="text-light font-weight-bold" style="background:linear-gradient(45deg,#ff0095,red)"><?php echo $sr;?></td>
							<td><?php echo $row["title"];?></td>
							<td><?php echo $row["downloadGroup"];?></td>
							<td>
								<?php
								   $fileSize=$row["fileSize"];
									 if($fileSize<=1023){
										   echo round($fileSize,2).	"bytes";
									 }else if($fileSize>=1024){
										         $fileSizeAfterDivide=$fileSize/1024;
														 if($fileSizeAfterDivide<1023){
															     echo round($fileSizeAfterDivide,2)."KB";
														 }else{
															        $fileSizeAfterDivide=$fileSize/(1024*1024);
																			 echo round($fileSizeAfterDivide,2)."MB";
														 }
									 }
								?>
							</td>
							<td><?php echo get_admin_name($row["admin"]);?></td>
							<td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
							<td>
											<form action="" method="post">
													 <button type="button" class="btn w3-win8-red" onclick="deleteDownloadFile(<?php echo $row["id"];?>,'<?php echo $row["fileName"];?>')">
															 <i class="fa fa-trash"></i> Delete
													 </button>
											</form>
							</td>
					</tr>
			 <?php
			 $sr++;
	 }
}
#getDownloadFile end;

#getAllAdmissionDetail
function getAllAdmissionDetail(){
         include 'db.php';
         $sql="SELECT * FROM admission ORDER BY id DESC";
         $result=$conn->query($sql);
         $sr=1;
         while($row=$result->fetch_assoc()){
		         ?>
			          <tr align="center" style="font-weight:bold">
					          <td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
					          <td><?php echo getCourseName($row["course"]);?></td>
					          <td><?php echo $row["name"]?></td>
					          <td><?php echo $row["fname"]?></td>
					          <td><?php echo date("d-m-y",strtotime($row["dob"]));?></td>
					          <td><?php echo $row["mobile"]?></td>
					          <td><?php echo $row["address"]?></td>
					          <td><?php echo date("d-m-y h:i:s A",strtotime($row["c_id"]));?></td>
			          </tr>
		         <?php
		         $sr++;
        }
}
#getAllAdmissionDetail end;
#end php;
?>
