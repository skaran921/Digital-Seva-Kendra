<?php
session_start();
$page_id=1;

if(isset($_SESSION["admin_id"]))
{

}
else
{
	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/highcharts.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpg" type="img/jpg">
    <title>Dashboard - Digital Seva Kendra</title>
	<style>
	    body
		{
		     background:linear-gradient(45deg,green,blue,red);
		}

	  #total_course
		{
			font-size:28px;
			border-radius:50%;
			padding-left:10px;
			padding-right:10px;
			font-family: Comic Sans MS;
			box-shadow:0 10px 10px rgba(0,0,0,.6);
		}
		.card
		{
			box-shadow:4px 4px 8px #666;
		}

		.col-sm-3 .card{
			  transition: 5s;
				border-radius: 10px;
				line-height: 20px;
		}

	</style>
	<script src="js/highcharts.js"></script>
	<script src="js/highcharts-3d.js"></script>
	<script src="js/highcharts-more	.js"></script>
	 <script>
  function time()
  {
      let d=new Date();
	  document.getElementById('time').innerHTML=d.toLocaleTimeString();
	  setTimeout(time,1000);
  }
  </script>
  </head>
  <body onload="time();">



        <?php
      		include 'headerAdmin.php';
      		include 'includeFunctionsAdmin.php';
		?>
		<br>
		<br>
		<br>
<div class="container-fluid content" id="my-card">
		 <div class="row p-4"><!---------row----------->

		 <div class="col-sm-3 card-deck mb-2">
			      <div class="card w3-win8-blue">
				       <center><b><i class="fa fa-clock-o"></i> Time:</b></center>
				     <div class="card-body">
					    <div class="card-text">
						     <center><b id="time" class="border p-1"></b></center>
						</div>
					 </div>
				  </div>
			</div><!--------------------col1--------------->

            <div class="col-sm-3 card-deck mb-2">
			      <div class="card w3-win8-green">
				       <center><b><i class="fa fa-user"></i> Current Admin:</b></center>
				     <div class="card-body">
					    <div class="card-text">
						     <center><b>Welcome, <?php echo get_admin_name($_SESSION["admin_id"]);?></b></center>
						</div>
					 </div>
				  </div>
			</div><!--------------------col2--------------->

			<div class="col-sm-3 card-deck mb-2">
			      <div class="card w3-win8-red">
				       <center><b><i class="fa fa-book"></i> Total Course:</b></center>
				     <div class="card-body">
					    <div class="card-text">
						     <center><b id="total_course"><?php echo total_course();?></b></center>
						</div>
					 </div>
				  </div>
			</div><!---col-3--->

			<div class="col-sm-3 card-deck mb-2">
						<div class="card" style="background:linear-gradient(45deg,#ff0095,red);color:#fff;">
							 <center><b><i class="fa fa-download"></i> Total Download:</b></center>
						 <div class="card-body">
							<div class="card-text">
								 <center><b id="total_course"><?php echo total_download();?></b></center>
						</div>
					 </div>
					</div>
			</div><!---col-3--->


						<div class="col-sm-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(45deg,indigo,teal,orange);color:#fff;">
										 <center><b><i class="fa fa-lightbulb-o"></i> Total Thought Added:</b></center>
									 <div class="card-body">
										<div class="card-text">
											 <center><b id="total_course"><?php echo total_thought();?></b></center>
									</div>
								 </div>
								</div>
						</div><!---col-3--->

						<div class="col-sm-3 card-deck mb-2">
 		 						<div class="card" style="background:linear-gradient(45deg,red,blue,orange);color:#fff;">
 		 							 <center><b><i class="fa fa-star"></i> Total Job Group:</b></center>
 		 						 <div class="card-body">
 		 							<div class="card-text">
 		 								 <center><b id="total_course"><?php echo total_jobGroup();?></b></center>
 		 						 </div>
 		 					  </div>
 		 					</div>
 		 			</div><!---col-3--->

						<div class="col-sm-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(45deg,blue,#ff0095,indigo);color:#fff;">
										 <center><b><i class="fa fa-newspaper-o"></i> Total Job Notification:</b></center>
									 <div class="card-body">
										<div class="card-text">
											 <center><b id="total_course"><?php echo total_jobNotification();?></b></center>
									 </div>
								  </div>
								</div>
						</div><!---col-3--->


						<div class="col-sm-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(55deg,blue,red,#ff0095,indigo);color:#fff;">
										 <center><b><i class="fa fa-newspaper-o"></i> Total General  Notification:</b></center>
									 <div class="card-body">
										<div class="card-text">
											 <center><b id="total_course"><?php echo total_generalNotification();?></b></center>
									 </div>
								  </div>
								</div>
						</div><!---col-3--->

						<div class="col-sm-3 card-deck mb-2">
									<div class="card">
										 <center><b><i class="fa fa-refresh"></i> Last Password Changed:</b></center>
									 <div class="card-body">
										<div class="card-text">
											 <center><b class="text-success"><?php echo last_password_update($_SESSION['admin_id']);?></b></center>
									</div>
								 </div>
								</div>
						</div><!-------------------col-4---------------->

						<div class="col-md-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(45deg,yellow,#ff0095,red);color:#fff;">
										 <center><b><i class="fa fa-envelope"></i> Messages Info:</b></center>
									 <div class="card-body">
										<div class="card-text">
											<center>
												<div class="card text-dark mb-1" style="font-family:Comic Sans MS">
																 <b>New Messages: <span class="badge badge-danger"><?php echo  newMessages();?></span></b>
												</div>
												  <div class="card text-dark mb-1" style="font-family:Comic Sans MS">
														  <b>Total Messages: <span class="badge badge-danger"><?php echo total_message();?></span></b>
													</div>

											</center>
									 </div>
									</div>
								</div>
						</div><!---col-3--->

						<div class="col-md-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(35deg,skyblue,#ff0,blue,red);color:#fff;">
										 <center><b><i class="fa fa-mortar-board"></i> Admission Info:</b></center>
									 <div class="card-body">
										<div class="card-text">
											<center>
											<div class="card text-dark mb-1" style="font-family:Comic Sans MS">
															 <b>New Application: <span class="badge badge-success"><?php echo  newAdmission();?></span></b>
											</div>
												<div class="card text-dark mb-1" style="font-family:Comic Sans MS">
														<b>Total Applications: <span class="badge badge-success"><?php echo total_admission();?></span></b>
												</div>
											</center>
									 </div>
									</div>
								</div>
						</div><!---col-3--->

						<div class="col-md-3 card-deck mb-2">
									<div class="card" style="background:linear-gradient(45deg,skyblue,#ff0095,red);color:#fff;">
										 <center><b><i class="fa fa-mortar-board"></i> Student Info:</b></center>
									 <div class="card-body">
										<div class="card-text">
											 <center><b id="total_course"><?php echo total_generalNotification();?></b></center>
									 </div>
									</div>
								</div>
						</div><!---col-3--->


		 </div>		<!------------row------------>
</div><!--------------------Container------------>

	 <center>
		     <div class="container mb-2" >
					<a href="superUser.php" data-toggle="tooltip" title="Click On Me To Login As a Super User">
		     	   <button type="button" class="btn w3-win8-indigo"  style="font-size:20px;">
							   <i class="fa fa-hand-o-right"></i> <i class="fa fa-user-secret"></i> Super Admin
						</button>
					</a>
		     </div>
	 </center>
        <?php include 'footerAdmin.php'; ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>

<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
</script>
  </body>
</html>
