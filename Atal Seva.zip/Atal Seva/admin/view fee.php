<?php
session_start();
$super_user_page_id=5;
$fee_page_sub_id=3;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>View Fee - Digital Seva Kendra</title>
    <style>
          #icon{
                font-size: 70px;
                position: relative;
                width: 100px;
                height: 100px;
                line-height: 100px;
                box-shadow: 0 10px 10px rgba(0,0,0,0.3);
                border-radius: 50%;
                background: linear-gradient(45deg,#FF0095,#12d8fa,#FF0095);
                top:-60px;
                color:#fff;
          }

          h3{
            position: relative;
            top:-50px;
            color:#fff;
          }

          #main-card{
            position: relative;
            background: linear-gradient(45deg,#FF0095,#12d8fa,#FF0095);
          }
          table{
            width:100%;
          }
          thead{
            background: linear-gradient(45deg,RED,#FF0095,#0033cc);
            box-shadow: 0 10px 10px rgba(0,0,0,0.3);
            font-size: 18px;
            color:#fff;
            text-align: center;
            font-family: cursive;
            line-height: 45px;
          }

          tbody{
              text-align: center;
          }
          tbody tr{
              box-shadow: 0 10px 10px rgba(0, 0, 0, 0.5);
              font-size: 16px;
              font-weight: bold;
              line-height: 40px;
          }

          tr:nth-child(even){
                background: whitesmoke;
          }

          tbody tr:nth-child(odd){
                background: #e6e6e6;
          }
          #btn{
                background: linear-gradient(-45deg,cyan,indigo,purple);
                color: white;
                font-family: cursive;
                border-radius: 17px;
                cursor:pointer;
                box-shadow: 0 10px 10px rgba(0,0,0,0.3);
          }

          #btn:hover{
                   transition: 5s;
                   background: indigo;
          }
    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
        <div class="container-fluid">
             <div class="card"id="main-card">
                 <div class="card-body">
                   <center>
                        <i class='fa fa-rupee' id='icon'></i>
                        <h3><i class='fa fa-eye'></i> View Fee For Session <?php echo "string"; $_SESSION["current_session"];?></h3>
                  </center>
             <div style="overflow-x:auto;position:relative;top:-40px;">
                   <table>
                        <thead>
                            <tr>
                              <th>Sr. No.</th>
                              <th>Date</th>
                              <th>Student Account</th>
                              <th>Fee Received</th>
                              <th>Discount</th>
                              <th>Total Fee</th>
                              <th>Updated On</th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php echo getFeeInfoForView(); ?>
                        </tbody>
                   </table>
              </div>
                 </div>
             </div>
        </div>
    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>
