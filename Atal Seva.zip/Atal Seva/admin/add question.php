<?php
session_start();
$super_user_page_id=4;
$exam_page_sub_id=5;
if(isset($_SESSION["admin_id"])){
        if(isset($_SESSION["super_admin_id"])){
        }else {
          header("Location: superUser.php");
        }
}else{
    	header("Location: index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Atal Seva Kendra Ellenabad">
    <meta name="keywords" content="skaran921,karan soni,">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/w3-colors-win8.css">
    <link rel="icon" href="images/logo.jpeg" type="img/jpeg">
    <title>Add Question Paper- Digital Seva Kendra</title>
    <style>
        #main-card{
              background: linear-gradient(-45deg,mediumslateblue,teal,darkmagenta);
              color:#fff;
              border-radius: 10px;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        #card-icon{
             position: relative;
             font-size: 100px;
             line-height: 80px;
             top:-60px;
             background: linear-gradient(-45deg,mediumslateblue,teal,darkmagenta);
             padding: 16px;
             border-radius: 50%;
             box-shadow: 0 10px 10px rgba(0,0,0,0.3);
        }
        h4{
           position: relative;
           top:-60px;
        }
        form{
              position: relative;
              top:-50px;
              max-width: 500px;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              padding: 30px;
        }
        label{
              max-width: 100px;
              text-align: left;
        }
        input,select{
                 background: whitesmoke;
                font-size:18px;
                border: 0;
                border-radius: 4px;
                width:300px;
                border-style: none;
                padding: 4px;
                text-transform: capitalize;
        }

        .btn1{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background: linear-gradient(-45deg,red,#ff0095);
              margin-top:4px;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }
        .btn1:hover{
                 transition: 2s;
                 background: green;
        }

        .btn2{
              font-size: 20px;
              width:100px;
              position: relative;
              border-radius: 20px;
              background: linear-gradient(-45deg,indigo,blue);
              margin-top:4px;
              padding: 6px;
              color:#fff;
              box-shadow: 0 10px 10px rgba(0,0,0,0.3);
              cursor: pointer;
        }
        .btn2:hover{
                 transition: 2s;
                 background: navy;
        }

    </style>
  </head>
  <body>
    <?php include 'includeFunctionsSuperAdmin.php';?>
    <?php  include 'headerSuperAdmin.php';?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
           <div class="container mb-4">
                <div class="card" id="main-card">
                    <div class="card-body">
                      <center>
                           <i class="fa fa-question-circle" id="card-icon"></i><br>
                            <h4><i class="fa fa-plus"></i> Add Question's</h4>
                      </center>
                    <center>
                       <form action="" method="post" id="questionForm">
                         <div class="form-group form-inline">
                              <label> <b> <i class="fa fa-asterisk"></i> Question Paper:&nbsp;</b> </label>
                              <select name="questionPaperId" id="questionPaperId" data-toggle="tooltip" title="Select Question Paper...eg HTML Quiz" required autofocus>
                                  <option value="">Select Question Paper</option>
                                   <?php
                                      include "db.php";
                                      $sql="SELECT id,title FROM questionPaper";
                                      $result=$conn->query($sql);
                                      while($row=$result->fetch_assoc()){
                                           ?>
                                            <option value="<?php echo $row['id'];?>"><?php echo $row["title"];?></option>
                                           <?php
                                      }
                                    ?>
                              </select>
                         </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk"></i> Question:&nbsp;</b> </label>
                               <input type="text" name="question" id="question" placeholder="Write Question...eg What is HTML" data-toggle="tooltip" title="Write Question...eg What is HTML? Note:- Don't Enter '?' sign in Question" required autofocus>
                          </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk "></i> Option 1:&nbsp;</b> </label>
                               <input type="text" name="option1" id="option1" placeholder="Option 1" data-toggle="tooltip" title="Here Come 1st Option OF Question...eg HYPER TEXT Modern Language" required autofocus>
                          </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk "></i> Option 2:&nbsp;</b> </label>
                               <input type="text" name="option2" id="option2" placeholder="Option 2" data-toggle="tooltip" title="Here Come 2nd Option OF Question...eg High TEXT Modern Language" required>
                          </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk "></i> Option 3:&nbsp;</b> </label>
                               <input type="text" name="option3" id="option3" placeholder="Option 3" data-toggle="tooltip" title="Here Come 3rd Option OF Question...eg HYPER TEXT MY Language" required>
                          </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk "></i> Option 4:&nbsp;</b> </label>
                               <input type="text" name="option4" id="option4" placeholder="Option 4" data-toggle="tooltip" title="Here Come 4th Option OF Question...eg HYPER TEXT MARKUP Language" required>
                          </div>

                          <div class="form-group form-inline">
                               <label> <b> <i class="fa fa-asterisk "></i> Answer:&nbsp;&nbsp;&nbsp;</b> </label>
                               <select type="text" name="answer" id="answer" data-toggle="tooltip" title="Here Select Right Option OF Question eg. Option 4" required>
                                     <option value="">Select Right Option</option>
                                     <option>Option1</option>
                                     <option>Option2</option>
                                     <option>Option3</option>
                                     <option>Option4</option>
                               </select>
                          </div>
                          <div class="form-group">
                               <center>
                                    <button type="button" onclick="validate()" class="btn1" data-toggle="tooltip" title="Click On Me Save question" data-placement="left">
                                           <i class="fa fa-save"></i> Save
                                    </button>
                                    <button type="reset" class="btn2" data-toggle="tooltip" title="Click On Me  To Reset Form" data-placement="right">
                                           <i class="fa fa-refresh"></i> Reset
                                    </button>
                               </center>
                          </div>
                       </form>
                    </center>
                    </div>
                  </div>
           </div>


    <?php include 'footerAdmin.php'; ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="alertify/js/alertify.js"></script>
<script src="js/textEditor.js"></script>
  </body>
  </html>
<script>
$(document).ready(()=>$('[data-toggle="tooltip"]').tooltip());
$(document).ready(function(){
     $("#myInput").on("keyup",function(){
       let value=$(this).val().toLowerCase();
      $("#myTable tr").filter(function(){
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
   });
});
</script>

<script>
function showMsg(inputMsg){
      let msg="<div class='card font-weight-bold text-danger'><center><i class='fa fa-warning' style='font-size:100px;'></i><br>"+inputMsg+"</center></div>";
      alertify.alert(msg);
      alertify.log(msg);
}
  function validate(){
     let questionPaperId=document.getElementById("questionPaperId").value;
     let question=document.getElementById("question").value;
     let option1=document.getElementById("option1").value;
     let option2=document.getElementById("option2").value;
     let option3=document.getElementById("option3").value;
     let option4=document.getElementById("option4").value;
     let answer=document.getElementById("answer").value;
     if(questionPaperId.length<1){
         showMsg("Please Select Question Paper First!!!");
     }else if(question.length<=1 || question.includes("?")){
          showMsg("Please Enter Valid Question!!!");
     }else if(option1.length<1){
          showMsg("Please Enter Option1 !!!");
     }else if(option2.length<1){
          showMsg("Please Enter Option2 !!!");
     }else if(option3.length<1){
          showMsg("Please Enter Option3 !!!");
     }else if(option4.length<1){
          showMsg("Please Enter Option4 !!!");
     }else if(answer.length<1){
          showMsg("Please Select Answer !!!");
     }else{
          document.getElementById("questionForm").submit();
     }
  }
</script>

<?php
   if( (isset($_POST["questionPaperId"])) && (isset($_POST["question"])) && (isset($_POST["option1"])) && (isset($_POST["option2"])) && (isset($_POST["option3"])) && (isset($_POST["option4"])) && (isset($_POST["answer"]))  ){
          $questionPaperId=$_POST["questionPaperId"];
          $question=$_POST["question"];
          $option1=$_POST["option1"];
          $option2=$_POST["option2"];
          $option3=$_POST["option3"];
          $option4=$_POST["option4"];
          $answer=$_POST["answer"];
          include "db.php";
          $_SESSION["questionPaperId"]=$questionPaperId;
    $sql1="SELECT * FROM questions WHERE questionPaperId='$questionPaperId' AND question='$question'";
    $result1=$conn->query($sql1);
    if($row1=$result1->fetch_assoc()){
      ?>
    <script>
        let msg="<div class='card font-weight-bold text-info'><center><i class='fa fa-times-circle' style='font-size:100px;'></i><br>Sorry...Question Already Exist!!!</center></div>";
        alertify.alert(msg);
        alertify.log(msg);
    </script>
      <?php
    }else{
          $sql="INSERT INTO questions(questionPaperId,question,option1,option2,option3,option4,answer)VALUES('$questionPaperId','$question','$option1','$option2','$option3','$option4','$answer')";
          $result=$conn->query($sql);
          if($result==TRUE){
                     ?>
                  <script>
                     let msg="<div class='card font-weight-bold text-success'><center><i class='fa fa-check-circle' style='font-size:100px;'></i><br> Question Saved!!!</center></div>";
                     alertify.alert(msg);
                     alertify.log(msg);
                  </script>
                     <?php
          }else{
            ?>
          <script>
              let msg="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-size:100px;'></i><br>error...Question Not Added!!!</center></div>";
              alertify.alert(msg);
              alertify.log(msg);
          </script>
            <?php
          }#$result
      }#else part of fetch_assoc();
   }#if isset
 ?>
