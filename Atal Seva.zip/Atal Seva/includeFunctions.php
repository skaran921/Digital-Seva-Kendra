<?php 
#total visitors
function total_visitors()
{
   include 'db.php';
   $sql="SELECT total_visitors FROM visitor_counter";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return $row['total_visitors'];
   }	
}
 
#update visitors
function update_visitors()
{
	include 'db.php';
	$total_visitors_now=total_visitors();
	$total_visitors=$total_visitors_now+1;
	$sql="UPDATE visitor_counter SET total_visitors='$total_visitors'";
	$result=$conn->query($sql);		
}

#get thought by id
function get_thought_by_id($thought_id){
	include 'db.php';	
	$sql="SELECT *FROM thought WHERE id='$thought_id'";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc()){
		?>
		<blockquote class="quote-box">
		  <i class="fa fa-lightbulb-o text-warning" style="font-size:30px;"></i>
		  <p class="quote-mark"></p>
		   <p class="quote-text"> <?php echo $row["thought"];?></p>
		   <hr>
			<div class="blockquote-footer">
			   <?php echo $row["author"];?>
			</div>			
		</blockquote>	
		<?php 
	}
}
#get today thought
function get_today_thought()
{
	include 'db.php';
   $sql="SELECT thought FROM today_thought";
   $result=$conn->query($sql);
   if($row=$result->fetch_assoc())
   {
	   return get_thought_by_id($row['thought']);
   }
}

#get news
function get_news()
{
	include 'db.php';
   $sql="SELECT news FROM news ORDER BY u_id DESC";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc())
   {
	   ?>
	     <li class="list-group-item"><i class="fa fa-hand-o-right"></i> <?php echo $row['news']; ?></li>
	   <?php
   }
}

#get course name
function get_course_name()
{
	include 'db.php';
   $sql="SELECT id,title FROM course ORDER BY title";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc())
   {
	   ?>
	     <option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
	   <?php
   }
}
#get course name from id
function get_course_name_from_id($course_id)
{
	include 'db.php';
   $sql="SELECT title FROM course WHERE id='$course_id'";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc())
   {
	   return $row['title'];  
   }
}

#get_all_course
function get_all_course(){
    include 'db.php';
	$sql="SELECT * FROM course";
	$result=$conn->query($sql);	
	while($row=$result->fetch_assoc()){		  
		  ?>
		    <div class="card-deck col-sm-4" id="course">
			   <div class="card">
			      <div class="card-header text-light font-weight-bold" style="background-color:<?php echo $row["color"];?>">
				    <i class="fa fa-book"></i> <?php echo $row["title"];?>
				  </div>
				  <div class="card-body">
				         <center>Detail's</center>
									  <center><i class="fa fa-hand-o-down" style="font-size:50px;color:rgba(51,205,255,0.9)"></i></center>
									     <ul class="list-group" style="margin-top:6px;">
										    <li class="list-group-item"><b><i class="fa fa-calendar"></i> Duration:</b> <?php echo $row["duration"];?></li>
										    <li class="list-group-item"><b><i class="fa fa-money"></i> Fee:</b> Rs. <?php echo $row["fee"];?>/-</li>
										    <li class="list-group-item"><b><i class="fa fa-book"></i> Syllabus:</b> <?php echo $row["syllabus"];?></li>
											
											<center>
											  <a href="admission.php" data-toggle="tooltip" title="Click On Me To Get Admission">
											     <button type="button" class="btn btn-success btn-block" style="margin-top:6px;">
												     <i class="fa fa-mortar-board"></i>  Get Addmission
												 </button>
											  </a>	 
											   </center>
											
										 </ul>   
				  </div>
				  <div class="card-footer" style="background-color:<?php echo $row["color"];?>">
				  </div>
			   </div>
			</div>
		  <?php 
	}
}#get_all_course end;

#get_last_added_three_course
function get_last_added_three_course(){
	include 'db.php';
	$sql="SELECT * FROM course ORDER BY u_id DESC LIMIT 3";
	$result=$conn->query($sql);	
	while($row=$result->fetch_assoc()){		  
		  ?>
		    <div class="card-deck col-sm-4" id="course">
			   <div class="card">
			      <div class="card-header text-light font-weight-bold" style="background-color:<?php echo $row["color"];?>">
				    <i class="fa fa-book"></i> <?php echo $row["title"];?>
				  </div>
				  <div class="card-body">
				         <center>Detail's</center>
									  <center><i class="fa fa-hand-o-down" style="font-size:50px;color:rgba(51,205,255,0.9)"></i></center>
									     <ul class="list-group" style="margin-top:6px;">
										    <li class="list-group-item"><b><i class="fa fa-calendar"></i> Duration:</b> <?php echo $row["duration"];?></li>
										    <li class="list-group-item"><b><i class="fa fa-money"></i> Fee:</b> Rs. <?php echo $row["fee"];?>/-</li>
										    <li class="list-group-item"><b><i class="fa fa-book"></i> Syllabus:</b> <?php echo $row["syllabus"];?></li>
											
											<center>
											 <a href="admission.php" data-toggle="tooltip" title="Click On Me To Get Admission">
											     <button type="button" class="btn btn-success btn-block" style="margin-top:6px;">
												     <i class="fa fa-mortar-board"></i>  Get Addmission
												 </button>
											  </a>	 
											   </center>
											
										 </ul>   
				  </div>
				  <div class="card-footer" style="background-color:<?php echo $row["color"];?>">
				  </div>
			   </div>
			</div>
		  <?php 
	}
}#get_last_added_three_course end;

?>