	
<footer class="bg-dark" style="color:rgb(51, 204, 255);">
   <div class="row" style="padding:10px;">
     
	      <div class="card-deck col-sm-4">
		     <div class="card bg-dark">
			    <div class="card-body text-center">
				   <b>Follow us.</b>
				   <p class="card-text">
				        &nbsp;<a href="#" class="text-light"><i class="fa fa-twitter-square"></i></a>
						&nbsp;<a href="#" class="text-light"><i class="fa fa-facebook-square"></i></a>
						&nbsp;<a href="#" class="text-light"><i class="fa fa-linkedin-square"></i></a>
						 &nbsp;<a href="#" class="text-light"><i class="fa fa-google-plus-square"></i></a>
						&nbsp;<a href="#" class="text-light"><i class="fa fa-youtube-play"></i></a>
		                &nbsp;<a href="#" class="text-light"><i class="fa fa-instagram"></i></a>
		               
				   </p>
				      <b>Contact Us.</b>
					  <p class="card-text">
					     <i class="fa fa-mobile"></i> 98968-31507<br>
					     <i class="fa fa-envelope"></i> digitalsevadhanilakhji@gmail.com
					  </p>
				</div>
			 </div>
		  </div>		   
	   
	   <!------------------> 
    
	       <div class="card-deck col-sm-4">
	     <div class="card bg-dark">
		      
		     <div class="card-body text-center" id="contact">			
					  <p class="card-text">
					     <i class="fa fa-map-marker"></i> Near Gram Panchyet Dhani Lakhji, Sureran Road Ellenabad, Sirsa(Haryana)125-102
					     
					  </p>
			  <b>Visitor Counter:</b>
			    <p class="card-text" style="text-shadow:0px 1px 1px #999;padding:3px 0px 3px 0px">				  
				      <mark> 
					  <?php  echo total_visitors();?></mark>
				</p>
			 </div>
		 </div>
       </div>	
	    
	   <!------------------>  
   
	 
	  <div class="card-deck col-sm-4">
	     <div class="card bg-dark">
		     <div class="card-body text-center">
			  <b> &copy;2018 Designed And Developed By skaran<sup>921</sup></b>
			    <div class="card-text">
				   <p>For Best Experiance Open in</p>
				   <i class="fa fa-chrome"></i>
				   <i class="fa fa-opera"></i>
				   <i class="fa fa-firefox"></i>
				   <i class="fa fa-edge"></i>
				</div>
				
				
			 </div>
		 </div>
       </div>	 
	
	 <!-------------->
   </div>
</footer>
  
  <!------------------------PHP Function-------------------->